#ifndef _acp_h
#define _acp_h

extern  void    ACPInitialise(void);
extern  void    ACPService(void);

extern  U8      ACPGetCommand(void);
extern  void    ACPSetDisk(U8 disk);
extern  void    ACPSetTrack(U8 track);
extern  void    ACPSetDiskTime(U8 mins,U8 secs);
extern  U8      ACPGetMode(void);
extern  void    ACPSetStatus(U8 status) ;

// ACP commands
#define ACP_COMMAND_NONE        0x00
#define ACP_COMMAND_NEXTTRACK   0x01
#define ACP_COMMAND_PREVTRACK   0x02

#define ACP_COMMAND_SELDISK     0x10    // LSB = disk number

// ACP status bits
#define ACP_ST_STANDBY          BIT(7)
#define ACP_ST_NOMAG            BIT(2)
#define ACP_ST_NOCD             BIT(0)

// ACP mode bits
#define ACP_MD_ON               BIT(6)
#define ACP_MD_COMP             BIT(5)
#define ACP_MD_SHUFF            BIT(4)
#define ACP_MD_REWIND           BIT(2)
#define ACP_MD_FASTFORWARD      BIT(1)
#define ACP_MD_JOG              BIT(0)

#endif
