/*------------------------------------------------------------------------
      Copyright (c) 2003
      Copyright (c) LS Design (UK) Ltd
  ------------------------------------------------------------------------
 
        Project :
     Module Name: main.c
        $Archive: /MP3 Player/ACP interface/main.c $
       $Revision: 11 $
         $Author: Simon $
           $Date: 28/08/03 9:21 $
    Description : main module
                :
  ----------------------------------------------------------------------*/

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\signal.h>
#include <avr\pgmspace.h>
#include <avr\ina90.h>
#include <avr\wdt.h>

#include "types.h"
#include "defines.h"
#include "uart.h"
#include "version.h"
#include "modelid.h"
#include "iodefs.h"
#include "timer.h"
#include "acp.h"

const char PROGMEM TitleString[] = "ACP Data Logger " ;
const char PROGMEM SOFTWARE_VERSION[] = { 'V' , SOFTWARE_VERSION_MAJOR , '.' , SOFTWARE_VERSION_MINOR , 0 } ;
const char PROGMEM CRLFString[] = "\r\n" ;

U8  disk ;
U8  track ;
U8  seconds ;
U8  minutes ;

#define NUMDISKS    30
#define NUMTRACKS   50

void
ClearTimer(void)
{
    minutes = 0 ;
    seconds = 0 ;
    ACPSetDiskTime(0,0);
}

static  void
NextTrack(void)
{
    if (track < NUMTRACKS)
    {
        track ++ ;
    }
    else
    {
        track = 1 ;
        if (disk < NUMDISKS) disk ++ ;
        ACPSetDisk(disk) ;
    }
    ACPSetTrack(track) ;
    ClearTimer();
}

/*------------------------------------------------------------------------
  Function Name : main
  Description   : main function
  Parameters    : None
  Inputs        : None
  Outputs       : None
  Return Value  : None
  Remarks       :
  ----------------------------------------------------------------------*/

int main(void)
{
    U8  ledtimer ;
    U8  event ;
    U8  timer ;

    outb(DDRB,PORTB_INITDDR);
    outb(PORTB,PORTB_INITVALUE);

    outb(DDRD,PORTD_INITDDR);
    outb(PORTD,PORTD_INITVALUE);

    TIMERInitialise() ;		// start timer interrupt
    UARTInitialise();	// init the UART
    ACPInitialise();

    sei(); // Enable all interrupts

    UARTOutputConstString((char *)CRLFString) ;
    UARTOutputConstString((char *)CRLFString) ;
    UARTOutputConstString((char *)TitleString) ;
    UARTOutputConstString((char *)SOFTWARE_VERSION);
    UARTOutputConstString((char *)CRLFString) ;

    while (TRUE)
    {
        ACPService();

        event = ACPGetCommand() ;
         	        
        if (event == ACP_COMMAND_PREVTRACK)
        {
            if (track > 1)
            {
                track -- ;
            }
            else
            {
                track = NUMTRACKS ;
                if (disk > 1) disk -- ;
                ACPSetDisk(disk) ;
            }
            ACPSetTrack(track) ;
            ClearTimer();
    	}
        else if (event == ACP_COMMAND_NEXTTRACK)
        {
            NextTrack();
	    }
        else if ((event & 0xf0) == ACP_COMMAND_SELDISK)
        {
            disk = event & 0x0f ;
            ACPSetDisk(disk) ;
            track = 1 ;
            ACPSetTrack(track) ;
            ClearTimer();
        }

        if (TIMERHasTickTimeElapsed())
        {
            if (++ledtimer == TIMERMILLISECONDS2TICKS(400))
            {
                ledtimer = 0 ;

                IO_SETBOOTLED(!IO_GETBOOTLED());
            }
            if (++timer == TIMERMILLISECONDS2TICKS(1000))
            {
                timer = 0 ;
                if (++seconds == 60)
                {
                    seconds = 0 ;
                    if (++minutes == 4)
                    {
                        NextTrack();
                    }
                }
                ACPSetDiskTime(minutes,seconds);
            }
        }
 	}
}
