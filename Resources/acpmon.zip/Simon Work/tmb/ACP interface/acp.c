/*------------------------------------------------------------------------
      Copyright (c) 2003
      Copyright (c) LS Design (UK) Ltd (www.ls-design.co.uk)
  ------------------------------------------------------------------------
 
        Project : MP3 Player
     Module Name: acp.c
        $Archive: /MP3 Player/ACP interface/acp.c $
       $Revision: 18 $
         $Author: Simon $
           $Date: 10/09/03 10:43 $
    Description : ACP interface module.
                :
  ----------------------------------------------------------------------*/

#include <avr\io.h>
#include <avr\signal.h>
#include <avr\interrupt.h>

#include "types.h"
#include "defines.h"
#include "acp.h"

#define PRESCALER           8 	// Prescaler value
#define PRESCALER_SELECT    2 	// Value loaded into TCCR to select prescaler

#define ACP_BAUDRATE        9600L
#define ACP_BITTIME	        (U16)(((U32)OSCILLATOR_FREQ/((U32)PRESCALER*ACP_BAUDRATE))-1)
#define ACP_STARTBITTIME    (ACP_BITTIME/2)

#define ACP_ACKWAITTIME     ((ACP_BAUDRATE * 20)/1000)      // 20ms
#define ACP_RETRIES_MAX     5

U8      ACPBitCount ;
U8      ACPShiftRegister ;
U8      ACPUartFlags;
U8      ACPTxMessageBuffer[12];
U8      ACPRxMessageBuffer[12];
U8      ACPTxMessageCount ;
U8      ACPRxMessageCount ;
U8      ACPRxChecksum ;
U8      ACPTxOutCount ;
U8      ACPMessageFlags ;
U8      ACPCommand ;
U8      ACPModeBits ;
U8      ACPStatus ;
U8      ACPRetryCount ;
U8      ACPRetryTimer ;

U8      ACPCurrentDisk ;
U8      ACPCurrentTrack ;
U8      ACPTimeMins ;
U8      ACPTimeSeconds ;
U8      ACPDiskStatus ;

U8      ACPFCValue;
U8      ACPC8Value;

// flags byte
#define ACP_F_MSGRX         ((U8)0x01)
#define ACP_F_MSGREADY      ((U8)0x02)
#define ACP_F_SENDACK       ((U8)0x04)
#define ACP_F_TXACTIVE      ((U8)0x10)
#define ACP_F_RXACTIVE      ((U8)0x20)
#define ACP_F_CSUMOK        ((U8)0x40)
#define ACP_F_RXACK         ((U8)0x80)

// message flags
#define ACP_MF_SENDSTATUS   0x01
#define ACP_MF_SENDDISK     0x02
#define ACP_MF_SENDTRACK    0x04
#define ACP_MF_SENDMODEBITS 0x08
#define ACP_MF_SENDDISKINFO 0x10
#define ACP_MF_SENDC8       0x20
#define ACP_MF_SENDE0       0x40
#define ACP_MF_SENDFC       0x80

// ACP status flags
#define ACP_SF_WAITFORACK   0x80

#define ACP_RXIDLE_TIME     20      // number of bits of idle to discard last message
#define ACP_TXIDLE_TIME     40      // number of bits of idle to start new message
#define ACP_ACK_WAIT_TIME   15

#define ACP_RXD()       bit_is_set(ACSR,ACO)

#ifdef __AVR_AT90S8515__
#define ACP_SETPBBITS() cbi(PORTB,2);sbi(PORTB,3)
#define ACP_SETTXD(x)   { if (x) { cbi(DDRB,2); cbi(DDRB,3); } else { sbi(DDRB,2); sbi(DDRB,3); ; }}
//#define ACP_SETTXD(x)   { if (x) { DDRB &= ~0x0c ; } else { DDRB |= 0x0c ; }}
#define ACP_GETTXD()    bit_is_clear(DDRB,2)
#endif

#ifdef __AVR_AT90S2313__
#define ACP_SETPBBITS() cbi(PORTB,0);sbi(PORTB,1)
#define ACP_SETTXD(x)   { if (x) { DDRB &= ~0x03 ; } else { DDRB |= 0x03 ; }}
#define ACP_GETTXD()    bit_is_clear(DDRB,0)
#endif
      
#define DEBUG_ACP       // comment out if not required

#ifdef DEBUG_ACP
#include "uart.h"

/*------------------------------------------------------------------------
  Function Name : ACPDebugData
  Description   : Outputs debug data if DEBUG_ACP is defined
  Parameters    : ptr - data pointer, count - number of bytes
  Inputs        : None
  Outputs       : outputs the data via the UART
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  void
ACPDebugData(U8 *ptr,U8 count)
{
    while (count--)
    {
        UARTOutput8Bits(*(ptr++)) ;
    }
    UARTSendByte('\r');
    UARTSendByte('\n');
}
#else
#define ACPDebugData(a,b)
#endif

/*------------------------------------------------------------------------
  Function Name : ACPPrepareForStartBit
  Description   : Enables comparator interrupt, clearing int flag if set
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  inline void
ACPPrepareForStartBit(void)
{
    sbi(ACSR,ACI);                    // clear int flag
    sbi(ACSR,ACIE);                    // enable int for start bit
}

/*------------------------------------------------------------------------
  Function Name : ACPRxReset
  Description   : Clears previous recieved message fragment
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  inline void
ACPRxReset(void)
{
    ACPRxMessageCount = 0 ;
}

/*------------------------------------------------------------------------
  Function Name : ACPSendStartBit
  Description   : Sends start bit of ACP byte
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  inline void
ACPSendStartBit(void)
{
    cbi(ACSR,ACIE);                         // disable start bit interrupt
    ACP_SETTXD(FALSE) ;                     // start bit
    ACPBitCount = 0 ;                       // transmit active
}

/*------------------------------------------------------------------------
  Function Name : SIG_OUTPUT_COMPARE1A
  Description   : Output Compare1(A) Interrupt Function
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	U16 reload ;
    U8  byte ;
    U8  flags;
    U8  bctemp ;

    reload = inw(OCR1AL) ;
    reload += ACP_BITTIME ;
    outw(OCR1AL,reload) ;

    flags = ACPUartFlags ;
    bctemp = ++ACPBitCount ;
    byte = ACPShiftRegister ;

    if (flags & ACP_F_TXACTIVE)
    {
        if (bctemp < 9)
        {
            if (ACP_GETTXD() && !ACP_RXD())     // collision
            {
                flags &= ~ACP_F_TXACTIVE ;      // wait till next opportunity
                ACPPrepareForStartBit();           // enable int
            }
            else
            {
                ACP_SETTXD(byte & BV(0)) ;
                byte >>= 1 ;
            }
        }
        else if (bctemp == 9)  // EOD bit
        {
            ACPTxOutCount ++ ;
            if (flags & ACP_F_SENDACK)
            {
                ACP_SETTXD(FALSE);
            }
            else if (ACPTxOutCount == ACPTxMessageCount)
            {
                ACP_SETTXD(TRUE);     // set EOD
            }
            else
            {
                ACP_SETTXD(FALSE);
            }
        }
        else    // stop bit/end of stop bit
        {
            ACP_SETTXD(TRUE);

            // after sending ack or the last byte, start looking for start bit straight away
            // if more data, we must wait for the end of the stop bit
            if (flags & ACP_F_SENDACK)
            {
                flags &= ~(ACP_F_SENDACK|ACP_F_TXACTIVE|ACP_F_RXACTIVE) ;
                ACPPrepareForStartBit();           // enable int
                ACPRxReset();                       // enable reception
            }
            else if (ACPTxOutCount == ACPTxMessageCount)    // all bytes gone
            {
                flags &= ~(ACP_F_MSGREADY|ACP_F_TXACTIVE|ACP_F_RXACTIVE) ;
                ACPPrepareForStartBit();           // enable int (should be ack byte)
                ACPRxReset();                       // enable reception
            }
            else if (bctemp >= 11)
            {
                // send next message byte
                ACPSendStartBit();
                byte = ACPTxMessageBuffer[ACPTxOutCount];
            }
        }
    }
    else if (flags & ACP_F_SENDACK)   // if waiting to send ack
    {
    	if (bctemp >= ACP_ACK_WAIT_TIME)
        {
        	ACPSendStartBit();
        	byte = 0x06 ;
        	flags |= ACP_F_TXACTIVE ;
        }
    }
    else if (flags & ACP_F_RXACTIVE)
    {
        if (bctemp == 1)       // start bit centre
        {
            if (ACP_RXD()) // start bit is not low
            {
                flags &= ~ACP_F_RXACTIVE ;
                ACPPrepareForStartBit();    // abort reception, wait for a new start bit
            }
        }
        else if (bctemp < 10)    // data bits
        {
            byte >>= 1 ;
            if (ACP_RXD())
            {
                byte |= BV(7) ;
            }
            if (bctemp == 9)     // if we have all the data bits
            {
                if (!ACPRxMessageCount)
                {
                    if (byte == 0x06)
                    {
                        flags |= ACP_F_RXACK ;
                    }
                    else if ((byte & 0x0f) == 0x01)
                    {
                        ACPRxChecksum = byte ;
                        ACPRxMessageBuffer[0] = byte;
                        ACPRxMessageCount = 1 ;
                    }
                }
                else
                {
                    if (ACPRxChecksum == byte)
                    {
                        flags |= ACP_F_CSUMOK ;
                    }
                    ACPRxChecksum += byte ;     // add to checksum
                
                    // add byte to message
                    if (ACPRxMessageCount < sizeof(ACPRxMessageBuffer))
                    {
                        ACPRxMessageBuffer[ACPRxMessageCount++] = byte;
                    }
                }
            }
        }
        else     // EOD bit
        {
            if ((bctemp == 10) && ACP_RXD() && (flags & ACP_F_CSUMOK))  // if EOD is high and checksum OK
            {
                if (ACPRxMessageCount > 4)
                {
                    flags |= (ACP_F_MSGRX|ACP_F_SENDACK);  // send ack
                }
            }
            ACPPrepareForStartBit();                    // prepare for new start bit
            flags &= ~(ACP_F_RXACTIVE|ACP_F_CSUMOK) ;   // no longer active
        }
    }
    else if (bctemp == ACP_RXIDLE_TIME)  // idle
    {
        ACPRxReset();
    }
    else if (bctemp >= ACP_TXIDLE_TIME)  // idle
    {
        ACPBitCount = ACP_TXIDLE_TIME ;

        if (ACP_RXD())      // if line is idle
        {
            if (flags & ACP_F_MSGREADY)     // if we have a message to go
            {
                ACPTxOutCount = 0;
                ACPSendStartBit();
                byte = ACPTxMessageBuffer[0] ;
                flags |= ACP_F_TXACTIVE ;   // start it off
            }
            else
            {
                if (ACPRetryTimer) ACPRetryTimer -- ;
            }
        }
    }
    ACPShiftRegister = byte ;
    ACPUartFlags = flags ;
}

/*------------------------------------------------------------------------
  Function Name : SIG_COMPARATOR
  Description   : ACP start bit interrupt
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

SIGNAL(SIG_COMPARATOR)
{
    // reset timer 0
    outw(TCNT1L,0) ;
    outw(OCR1AL,ACP_STARTBITTIME) ;  	// set TCNT1 for start bit
    ACPBitCount = 0 ;
    cbi(ACSR,ACIE);                     // disable int
   	sbi(TIFR,OCF1A);					// clear timer 1 compare flag
    ACPUartFlags |= ACP_F_RXACTIVE ;
}

/*------------------------------------------------------------------------
  Function Name : ACPInitialise
  Description   : Initialise function
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

void
ACPInitialise(void)
{
    ACP_SETPBBITS();                    // initial state of comparator pins
  	outp(PRESCALER_SELECT, TCCR1B);	    // start timer1
    sbi(TIMSK,OCIE1A) ;		            // compare interrupt enable
    outb(ACSR,BIT(ACIS1));              // raise comparator int on falling edge
    ACPPrepareForStartBit();
}

/*------------------------------------------------------------------------
  Function Name : ACPSetUartFlags
  Description   : Sets bits in ACPUartFlags with interrupt disable
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  void
ACPSetUartFlags(U8 mask)
{
    cli();
    ACPUartFlags |= mask;
    sei();
}

/*------------------------------------------------------------------------
  Function Name : ACPClearUartFlags
  Description   : Clears bits in ACPUartFlags with interrupt disable
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  void
ACPClearUartFlags(U8 mask)
{
    cli();
    ACPUartFlags &= ~mask;
    sei();
}

/*------------------------------------------------------------------------
  Function Name : ACPSendMessage
  Description   : Signals ACP message ready to transmit/retransmit
  Parameters    : none
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  void
ACPSendMessage(void)
{
    ACPRetryTimer = ACP_ACKWAITTIME;
    ACPSetUartFlags(ACP_F_MSGREADY);
    ACPStatus |= ACP_SF_WAITFORACK ;
    ACPDebugData(ACPTxMessageBuffer,ACPTxMessageCount);
}

/*------------------------------------------------------------------------
  Function Name : ACPAddChecksumAndSend
  Description   : Adds checksum and signals ACP message ready to transmit
  Parameters    : length - length of message to go (not incl. checksum)
  Inputs        : None
  Outputs       : 
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

static  void
ACPAddChecksumAndSend(U8 length)
{
    U8 *ptr = ACPTxMessageBuffer ;
    U8 count = length ;
    U8 checksum = 0 ;

    do
    {
        checksum += *(ptr++) ;
    } while (--count);

    *ptr = checksum ;
    ACPTxMessageCount = length + 1 ;
    ACPRetryCount = 0 ;
    ACPSendMessage();
}

/*------------------------------------------------------------------------
  Function Name : ACPBin2BCD
  Description   : Does binary to BCD conversion, used for track/time values
  Parameters    : toconv - value to convert
  Inputs        : None
  Outputs       : 
  Return Value  : converted BCD value
  Remarks       : 
  ----------------------------------------------------------------------*/

static  U8
ACPBin2BCD(U8 toconv)
{
    return ((toconv/10)*16) + (toconv % 10) ;
}

/*------------------------------------------------------------------------
  Function Name : ACPCheckSendBits
  Description   : Checks and clears bits in ACPMessageFlags
  Parameters    : toconv - value to convert
  Inputs        : None
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

static  inline BOOL
ACPCheckSendBits(U8 mask)
{
    if (ACPMessageFlags & mask)
    {
        ACPMessageFlags &= ~mask ;
        return TRUE ;
    }
    return FALSE ;
}

/*------------------------------------------------------------------------
  Function Name : ACPService
  Description   : Background task for ACP handler
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

void
ACPService(void)
{
    if (ACPUartFlags & ACP_F_MSGRX)     // we have a message
    {
        ACPClearUartFlags(ACP_F_MSGRX) ;

        ACPDebugData(ACPRxMessageBuffer,ACPRxMessageCount);

        if (ACPRxMessageBuffer[2] == 0x80)  // from the stereo
        {
            if (ACPRxMessageBuffer[1] == 0x9a)  // commands
            {
                if (ACPRxMessageBuffer[3] == 0xc1)
                {
                    ACPModeBits = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDMODEBITS ;
                }
                else if (ACPRxMessageBuffer[3] == 0xc2)
                {
                    ACPCommand = ACP_COMMAND_SELDISK | ACPRxMessageBuffer[4];
                }
                else if (ACPRxMessageBuffer[3] == 0xc3)
                {
                    ACPCommand = ACP_COMMAND_NEXTTRACK ;
                }
                else if (ACPRxMessageBuffer[3] == 0x43)
                {
                    ACPCommand = ACP_COMMAND_PREVTRACK ;
                }
                else if (ACPRxMessageBuffer[3] == 0xfc)
                {
                    ACPFCValue = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDFC ;
                }
                else if (ACPRxMessageBuffer[3] == 0xc8)
                {
                    ACPC8Value = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDC8 ;
                }
            }
            else if (ACPRxMessageBuffer[1] == 0x9b)     // requests
            {
                if (ACPRxMessageBuffer[3] == 0xc2)
                {
                    ACPMessageFlags |= ACP_MF_SENDDISK ;
                }
                else if (ACPRxMessageBuffer[3] == 0xff)
                {
                    ACPMessageFlags |= ACP_MF_SENDSTATUS ;
                }
                else if (ACPRxMessageBuffer[3] == 0xe0)
                {
                    ACPMessageFlags |= ACP_MF_SENDE0 ;
                }
            }
        }
    }

    if (ACPStatus & ACP_SF_WAITFORACK)  // if we're waiting for acknowledge
    {
        if (ACPUartFlags & ACP_F_RXACK)      // if we have it
        {
            ACPClearUartFlags(ACP_F_RXACK) ;
            ACPStatus &= ~ACP_SF_WAITFORACK ;   // no longer waiting
            UARTOutput8Bits(0x06);
        }
        else if (!ACPRetryTimer)    // timeout
        {
            if (++ACPRetryCount == ACP_RETRIES_MAX) // if max retries
            {
                ACPStatus &= ~ACP_SF_WAITFORACK ;   // give up
            }
            else
            {
                ACPSendMessage();                   // retry
            }
        }
    }
    else
    {
        // see if we need to send something
        ACPTxMessageBuffer[0] = 0x71 ;      // may be changed below
        ACPTxMessageBuffer[1] = 0x9b ;
        ACPTxMessageBuffer[2] = 0x82;       // CD changer ID

        if (ACPCheckSendBits(ACP_MF_SENDDISK))
        {
            ACPTxMessageBuffer[3] = 0xc2 ;
            ACPTxMessageBuffer[4] = ACPCurrentDisk ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDTRACK))
        {
            ACPTxMessageBuffer[3] = 0xc3 ;
            ACPTxMessageBuffer[4] = ACPBin2BCD(ACPCurrentTrack) ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDSTATUS))
        {
            ACPTxMessageBuffer[3] = 0xff ;
            ACPTxMessageBuffer[4] = ACPDiskStatus ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDMODEBITS))
        {
            ACPTxMessageBuffer[3] = 0xc1 ;
            ACPTxMessageBuffer[4] = ACPModeBits ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDE0))
        {
            ACPTxMessageBuffer[3] = 0xe0 ;
            ACPTxMessageBuffer[4] = 0x04 ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDFC))
        {
            ACPTxMessageBuffer[3] = 0xfc ;
            ACPTxMessageBuffer[4] = ACPFCValue ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDC8))
        {
            ACPTxMessageBuffer[3] = 0xc8 ;
            ACPTxMessageBuffer[4] = ACPC8Value ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDDISKINFO))
        {
            ACPTxMessageBuffer[3] = 0xd0 ;
            ACPTxMessageBuffer[4] = ACPCurrentDisk ;
            ACPTxMessageBuffer[5] = ACPBin2BCD(ACPCurrentTrack) ;
            ACPTxMessageBuffer[6] = ACPBin2BCD(ACPTimeMins) ;
            ACPTxMessageBuffer[7] = ACPBin2BCD(ACPTimeSeconds)|BIT(7) ;
            ACPAddChecksumAndSend(8);
        }
    }
}

/*------------------------------------------------------------------------
  Function Name : ACPGetCommand
  Description   : Query function for recieved ACP command
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

U8      
ACPGetCommand(void)
{
    U8 cmd = ACPCommand ;

    ACPCommand = ACP_COMMAND_NONE ;

    return cmd ;
}

/*------------------------------------------------------------------------
  Function Name : ACPSetDisk
  Description   : Causes a disk number message to be sent to the head
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

void    
ACPSetDisk(U8 disk)
{
    ACPCurrentDisk = disk ;
    ACPMessageFlags |= ACP_MF_SENDDISK ;
}

/*------------------------------------------------------------------------
  Function Name : ACPSetTrack
  Description   : Causes a track number message to be sent to the head
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

void    
ACPSetTrack(U8 track)
{
    ACPCurrentTrack = track ;
    ACPMessageFlags |= ACP_MF_SENDTRACK ;
}

/*------------------------------------------------------------------------
  Function Name : ACPSetDiskTime
  Description   : Causes a time message to be sent to the head
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

void    
ACPSetDiskTime(U8 mins,U8 secs)
{
    ACPTimeMins = mins ;
    ACPTimeSeconds = secs ;
    ACPMessageFlags |= ACP_MF_SENDDISKINFO ;
}

/*------------------------------------------------------------------------
  Function Name : ACPGetMode
  Description   : Returns the recieved mode bits from the head
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

U8      
ACPGetMode(void)
{
    return ACPModeBits ;
}

/*------------------------------------------------------------------------
  Function Name : ACPSetStatus
  Description   : Causes a status message to be sent to the head
  Parameters    : 
  Inputs        : 
  Outputs       : 
  Return Value  : 
  Remarks       : 
  ----------------------------------------------------------------------*/

void
ACPSetStatus(U8 status)
{
    ACPDiskStatus = status ;
    ACPMessageFlags |= ACP_MF_SENDSTATUS ;
}

