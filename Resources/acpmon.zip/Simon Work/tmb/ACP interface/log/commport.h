#ifndef _commport_h
#define _commport_h

#include "windows.h"

class COMMPORT
{
protected:
	_DCB	dcb;
	HANDLE	handle ;
	char 	formatstring[20] ;
	COMSTAT	state ;

public:
	BOOL	SetState() { return SetCommState(handle,&dcb) ; } ;
    BOOL	SetBreak() { return IsOK() ? SetCommBreak(handle) : FALSE ; } ;
    BOOL	ClearBreak() { return IsOK() ? ClearCommBreak(handle) : FALSE ; } ;

	BOOL	SetBaudRate(DWORD br) { dcb.BaudRate = br ; return SetState() ; } ;
	DWORD	GetBaudRate() { return dcb.BaudRate ; } ;

	BOOL	SetBinary() { dcb.fBinary = TRUE ; return SetState() ; } ;
	BOOL 	IsPortAvl(int) { return TRUE ; } ;
	int 	GetPort() { return formatstring[3] - '1' ; } ;
	virtual BOOL SetPort(int newport) { Close() ; formatstring[3] = '1' + newport ; return Open(formatstring) ; } ;
    BOOL	ReOpen() { return SetPort(GetPort()) ; } ;

	int		TxByte(BYTE tosend) { return Write(&tosend,1) ; } ;
   	int		RxByte() { BYTE b ; Read(&b,1) ; return b ; } ;

  	DWORD		Write(void *data,int num)
   	{
   		DWORD numwritten ;

   		if (!IsOK()) return FALSE ;

      	WriteFile(handle,data,num,&numwritten, NULL) ;

      	return numwritten ;
   	} ;

	DWORD		Read(void *data,int num)
   	{
   		DWORD numread ;

   		if (!IsOK()) return FALSE ;

      	ReadFile(handle,data,num,&numread,NULL) ;

      	return numread ;
    } ;

	DWORD	GetError() { DWORD error ; ClearCommError(handle,&error,&state) ; return error ; } ;
	BOOL	IsOK() { return (handle != INVALID_HANDLE_VALUE) ; } ;
	void	Close()
    {
    	if (IsOK())
        {
        	CloseHandle(handle) ;
            handle = INVALID_HANDLE_VALUE ;
    	}
    } ;
    COMMPORT() { handle = INVALID_HANDLE_VALUE ; } ;
	BOOL	TxEmpty() { GetError() ; return IsOK() ? ((state.cbOutQue)?FALSE:TRUE) : FALSE ; } ;
    UINT	GetRxCount() { GetError() ; return IsOK() ? state.cbInQue : 0 ; } ;

	BOOL	RxAvl() { return ( GetRxCount() ? TRUE : FALSE ) ; } ;
	BOOL	TxAvl() { GetError() ; return IsOK() ? ((state.cbOutQue > 500)?FALSE:TRUE) : FALSE ; } ;

    void	RxFlush() { PurgeComm(handle,PURGE_TXCLEAR|PURGE_RXCLEAR); } ;
	BOOL	Open(char *name) ;
	COMMPORT(char *name) { Open(name) ; } ;
	~COMMPORT() { Close() ; } ;
} ;

#endif
