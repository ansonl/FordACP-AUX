//---------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#pragma hdrstop

#include "utils.h"
#include "memalloc.h"
#include "commport.h"

//---------------------------------------------------------------------------

BYTE buffer[500] ;
BYTE lasttimestamp[500];
BOOL    reversed = FALSE ;
FILE *logfile = NULL;
BOOL    fixeod = FALSE;

static  void
DebugOutput(char *format,...)
{
	char string[200] ;

	va_list args ;
    va_start(args,format) ;

    vsprintf(string,format,args) ;

    printf("%s",string) ;

    if (logfile)
    {
        fprintf(logfile,"%s",string) ;
    }
}

static  BOOL
GetTwoHex(char *ptr, BYTE *value)
{
    if (!isxdigit(ptr[0]) || !isxdigit(ptr[1]))
    {
        return FALSE ;
    }
    *value = asc2hex(ptr[0]) << 4 ;
    *value |= asc2hex(ptr[1]) ;

    if (reversed)
    {
        *value = ReverseByte(*value);
    }

    return TRUE ;
}

BYTE
BCDToDec(BYTE in)
{
    return ((in >> 4) * 10) + (in & 0x0f) ;
}

static  void
PowerMessage(void)
{
    DebugOutput(" Mode (%02x)",buffer[4]);
    if (buffer[4] & 0x40)
    {
        DebugOutput(" ON");
    }
    else
    {
        DebugOutput(" OFF");
    }
    if (buffer[4] & 0x20) DebugOutput(" Comp");    
    if (buffer[4] & 0x10) DebugOutput(" Shuff");
    if (buffer[4] & 0x04) DebugOutput(" REW");
    if (buffer[4] & 0x02) DebugOutput(" FF");
    if (buffer[4] & 0x01) DebugOutput(" JOG");
}

#pragma argsused
int main(int argc, char* argv[])
{
    char    *ptr ;
    char    *ptr1;
    BYTE    wtemp ;
    MemoryAllocator infile ;
    DWORD   index ;
    WORD    count;
    COMMPORT port ;
    BOOL    done ;
    BYTE    checksum = 0 ;

	for (int x = 1 ; x < argc ; x ++)
	{
		if (argv[x][0] != '-')
		{
            if (!infile.Load(argv[x]))
            {
                DebugOutput("Can't open file %s.\n",argv[x]);
                return -1 ;
            }
		}
		else switch(argv[x][1])
		{
            case 'l':       // log to file
                logfile = fopen(&argv[x][2],"w");
                if (!logfile)
                {
                    DebugOutput("Failed to open logfile %s.\n",&argv[x][2]);
                }
                else
                {
                    DebugOutput("Logging to file %s.\n",&argv[x][2]);
                }
                break ;

            case 'p':       // open comms
                wsprintf(buffer,"COM%c:115200,n,8,1",argv[x][2]);
                if (!port.Open(buffer))
                {
                    DebugOutput("Failed to open %s.\n",buffer);
                    return -1 ;
                }
                DebugOutput("Opened %s.\n",buffer);
                break ;

            case 'r':
                reversed = TRUE ;
                DebugOutput("Reverse Selected.\n");
                break ;

            case 'e':
                fixeod = TRUE ;
                DebugOutput("Fixing EOD.\n");
                break ;

			default :
                DebugOutput("Unknown option %s\n",argv[x]) ;
                break ;
        }
    }

    if (!infile.Size() && !port.IsOK())
    {
        DebugOutput("Please specifiy commport (-p1) or file to read.\n");
        return -1 ;
    }

    count = 0 ;
    done = FALSE ;
    index = 0 ;

    while (!done)
    {
        wtemp = 0 ;
        if (infile.Size())
        {
            infile.ReadData(index++,&wtemp,1);
            if (index >= infile.Size()) done = TRUE ;
        }
        else if (port.IsOK())
        {
            if (port.RxAvl())
            {
                wtemp = port.RxByte() ;
            }
        }

        if (kbhit())
        {
            if (getch() == 27) done = TRUE ;
        }

        if ((wtemp == '\r') || (wtemp == '\n'))
        {
            if (fixeod)
            {
                if (!count || !isxdigit(buffer[0]))
                {
                }
                else if (!strncmp(buffer,"Ack",3))
                {
                    DebugOutput("06\n");
                    checksum = 0 ;
                }
                else
                {
                    ptr = buffer;
                    ptr1 = buffer;
                    while (*ptr)
                    {
                        if (isxdigit(*ptr))
                        {
                            *(ptr1++) = *ptr ;
                        }
                        ptr ++;
                    }
                    *ptr1 = 0 ;
                    DebugOutput("*");

                    ptr = buffer ;
                    while (GetTwoHex(ptr,&wtemp))
                    {
                        DebugOutput("%02x",wtemp);
                        if ((checksum == wtemp) || (!checksum && (wtemp == 0x06)))
                        {
                            DebugOutput("\n");
                            checksum = 0 ;
                        }
                        else
                        {
                            checksum += wtemp ;
                        }
                        ptr += 2 ;
                    }
                }
                count = 0 ;
            }
            else if (count)
            {
                ptr = buffer ;
                if (GetTwoHex(ptr,&wtemp) && (wtemp == 0x06))
                {
                    DebugOutput("Ack\n");
                    ptr += 2 ;
                }

                if (strchr(ptr,':'))
                {
                    // date stamp
                    if (strcmp(buffer,lasttimestamp))    // if not same as prev
                    {
                        DebugOutput("%s\n",buffer);
                        strcpy(lasttimestamp,buffer);
                    }
                }
                else if (strcmp(ptr,"FF") && isxdigit(buffer[0]))
                {
                    count = 0 ;
                    while(GetTwoHex(ptr,&wtemp))
                    {
                        ptr += 2 ;
                        DebugOutput("%02x ",wtemp);
                        buffer[count++] = wtemp;
                    }
                    if (count)
                    {
                        while (count++ < 12)
                        {
                            DebugOutput("   ");
                        }
                        DebugOutput(":");
                        if (buffer[2] == 0x82)  // CD messages
                        {
                            DebugOutput("(CD)");

                            if (buffer[1] == 0x9b)
                            {
                                if (buffer[3] == 0xd0)
                                {
                                    DebugOutput(" D:%d,T:%d %02d:%02d",buffer[4],BCDToDec(buffer[5]),
                                        BCDToDec(buffer[6]),BCDToDec(buffer[7] & 0x7f));
                                }
                                else if (buffer[3] == 0xc1)
                                {
                                    PowerMessage();
                                }
                                else if (buffer[3] == 0xc2)
                                {
                                    DebugOutput(" Select disk %d",BCDToDec(buffer[4]));
                                }
                                else if (buffer[3] == 0xc3)
                                {
                                    DebugOutput(" Select track %d",BCDToDec(buffer[4]));
                                }
                            }
                        }
                        else if (buffer[2] == 0x80)  // Radio messages
                        {
                            DebugOutput("(HD)");

                            if (buffer[1] == 0x9a)
                            {
                                if (buffer[3] == 0xc1)
                                {
                                    PowerMessage();
                                }
                                else if (buffer[3] == 0xc2)
                                {
                                    DebugOutput(" Select disk %d",buffer[4]);
                                }
                                else if (buffer[3] == 0xc3)
                                {
                                    DebugOutput(" Next track");
                                }
                                else if (buffer[3] == 0x43)
                                {
                                    DebugOutput(" Prev track");
                                }
                            }
                            else if (buffer[1] == 0x9b)
                            {
                                if (buffer[3] == 0xc2)
                                {
                                    DebugOutput(" Request Disk");                                
                                }
                            }
                            else if (buffer[1] == 0xab)
                            {
                                if (buffer[3] == 0xc3)
                                {
                                    DebugOutput(" ??");
                                }
                            }
                            else if (buffer[1] == 0xbb)
                            {
                                if (buffer[3] == 0xc3)
                                {
                                    DebugOutput(" ??");
                                }
                            }
                        }
                        else
                        {
                            DebugOutput("(??) ");
                        }
                        DebugOutput(".\n");
                    }
                }
                count = 0 ;
            }
        }
        else if (wtemp)
        {
            buffer[count++] = wtemp ;
            buffer[count] = 0 ;
        }
    }
    if (logfile) fclose(logfile);
    return 0;
}
//---------------------------------------------------------------------------

