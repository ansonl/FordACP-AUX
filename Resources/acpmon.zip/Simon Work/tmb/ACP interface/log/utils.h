#ifdef _OWLPCH
#include <owl\pch.h>
#else
#include <vcl.h>
#endif
#pragma hdrstop

#ifndef _utils_h
#define _utils_h

#include <time.h>

extern	void StripEOL(char *string) ;
extern	BYTE asc2hex(char asc);
extern	BOOL GetHex(char **_ptr,WORD *result) ;
extern	BOOL GetDecimalWord (char **_ptr,WORD *result) ;
extern	BOOL GetLongHex(char **_ptr,DWORD *result) ;
extern	BOOL GetLong(char **_ptr,DWORD *result) ;
extern  BOOL GetFloat(char **_ptr,float *result) ;
extern  BOOL GetDouble(char **_ptr,double *result) ;

extern	char *FindEnd(char *string) ;
extern	BOOL GetFileDateAndTime(char *filename,time_t *time = NULL) ;
inline	BOOL FileExists(char *filename) { return GetFileDateAndTime(filename) ; } ;
extern	char *GetBaseFileName(char *fullname) ;
extern	BOOL GetField(char **source,char *dest,BYTE destsize,char *delimstring = NULL) ;
extern	BYTE ReverseByte(BYTE toreverse) ;

#ifndef BIT
#define BIT(x)	(DWORD)(1L<<x)
#endif

#endif
