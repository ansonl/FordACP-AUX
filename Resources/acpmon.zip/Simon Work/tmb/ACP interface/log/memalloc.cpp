#ifdef _OWLPCH
#include <owl\pch.h>
#else
#include <vcl.h>
#endif
#pragma hdrstop

#include "memalloc.h"

BOOL
MemoryAllocator::Alloc(DWORD newsize)
{
	HGLOBAL newhandle = GlobalAlloc(GPTR,newsize) ;

    // if previous allocation then copy the data across
	if (IsOK())
    {
    	BYTE __HUGEPTR *ptr = (BYTE __HUGEPTR *)GlobalLock(newhandle) ;
        if (!ptr) return FALSE ;

		ReadData(0,ptr,newsize) ;	// will be size if smaller
        GlobalUnlock(newhandle) ;
        Free() ;
    }
   	size = newsize ;
   	handle = newhandle ;
    lockcount = 0 ;

    return IsOK() ;
}

BOOL
MemoryAllocator::CopyFrom(MemoryAllocator &other)
{
    BYTE __HUGEPTR *source = (BYTE __HUGEPTR *)other.Lock() ;
    if (!source) return FALSE ;

    CopyFrom(source,other.Size()) ;

    other.Unlock();

    return TRUE ;
}

BOOL
MemoryAllocator::CopyFrom(BYTE __HUGEPTR *source, DWORD count)
{
	return WriteData(0,source,count) ;
}

BOOL
MemoryAllocator::ReadData(DWORD offset,BYTE __HUGEPTR *destination,DWORD count)
{
    if (offset > Size()) return FALSE ;

    if ((offset+count) > Size()) count = Size()-offset ;

    BYTE __HUGEPTR *source = (BYTE __HUGEPTR *)Lock() ;

    if (!source) return FALSE ;

    source += offset ;

    while (count--)
    {
    	*destination = *source ;
        source ++ ;
        destination ++ ;
    }
    Unlock();
    return TRUE ;
}

BOOL
MemoryAllocator::WriteData(DWORD offset,BYTE __HUGEPTR *source,DWORD count)
{
    if (offset > Size()) return FALSE ;

    if ((offset+count) > Size()) count = Size()-offset ;

    BYTE __HUGEPTR *destination = (BYTE __HUGEPTR *)Lock() ;

    if (!destination) return FALSE ;

    destination += offset ;

    while (count--)
    {
    	*destination = *source ;
        source ++ ;
        destination ++ ;
    }
    Unlock();
    return TRUE ;
}

BOOL
MemoryAllocator::AddData(BYTE __HUGEPTR *data,DWORD count)
{
    DWORD pos = Size() ;

    if (Alloc(pos+count))
    {
        return WriteData(pos,data,count) ;
    }
    return TRUE ;
}

BOOL
MemoryAllocator::ReadFromFile(ifstream &is,DWORD count)
{
    BOOL result = TRUE ;

    if (!count) count = Size() ;
    if (count > Size()) count = Size() ;

 	char __HUGEPTR *ptr = (char __HUGEPTR *)Lock() ;

    while (count--)
    {
    	is.get(*ptr) ;
        ptr ++ ;
        if (!is.gcount())
        {
        	result = FALSE ;
            break ;
        }
    }

    Unlock() ;
    return result ;
}

BOOL
MemoryAllocator::WriteToFile(ofstream &os,DWORD count)
{
    BOOL result = TRUE ;

    if (!count) count = Size() ;
    if (count > Size()) count = Size() ;
    
 	char __HUGEPTR *ptr = (char __HUGEPTR *)Lock() ;

    while (count--)
    {
    	os.put(*ptr) ;
        ptr ++ ;
    }

    Unlock() ;
    return result ;
}

BOOL
MemoryAllocator::WriteToFile(FILE *file,DWORD count)
{
    BOOL result = TRUE ;

    if (!count) count = Size() ;
    if (count > Size()) count = Size() ;
    
 	char __HUGEPTR *ptr = (char __HUGEPTR *)Lock() ;

    while (count--)
    {
        fputc(*ptr,file);
        ptr ++ ;
    }

    Unlock() ;
    return result ;
}

void
MemoryAllocator::FillWith(BYTE tofillwith, DWORD start,DWORD end)
{
	DWORD count ;
 	char __HUGEPTR *ptr = (char __HUGEPTR *)Lock() ;

    if (!end) end = Size() ;

    ptr += start ;

    for (count = start ; count < end ; count ++)
    {
    	*ptr = tofillwith ;
        ptr ++ ;
    }

    Unlock() ;
}

DWORD
MemoryAllocator::WordChecksum(DWORD count)
{
	DWORD checksum = 0 ;
 	BYTE __HUGEPTR *ptr = (BYTE __HUGEPTR *)Lock() ;

	if (!count) count = Size() ;

    while (count)
    {
        checksum += *ptr << 8 ;
        ptr ++ ;
        count -- ;
    	checksum += *ptr & 0xff ;
        ptr ++ ;
        count -- ;
    }

    Unlock() ;
    return checksum;
}

DWORD
MemoryAllocator::ByteChecksum(DWORD count)
{
	DWORD checksum = 0 ;
 	BYTE __HUGEPTR *ptr = (BYTE __HUGEPTR *)Lock() ;

	if (!count) count = Size() ;

    while (count)
    {
    	checksum += *ptr ;
        ptr ++ ;
        count -= sizeof(BYTE) ;
    }

    Unlock() ;
    return checksum;
}

DWORD
MemoryAllocator::GetFillLevel(BYTE emptybyte)
{
	DWORD level = 0 ;
	DWORD count ;
 	BYTE __HUGEPTR *ptr = (BYTE __HUGEPTR *)Lock() ;

    for (count = 0 ; count < Size() ; count ++)
    {
    	if (*ptr != emptybyte)
        {
        	level = count+1 ;
        }
        ptr ++ ;
    }

    Unlock() ;
    return level;
}

BOOL
FileAllocator::Load(char *filename)
{
	ifstream file(filename,ios::in|ios::binary) ;
    if (!file) return FALSE ;

    file.seekg(0,ios::end) ;
    Alloc(file.tellg()) ;
    file.seekg(0,ios::beg) ;

	return ReadFromFile(file) ;
}

BOOL
FileAllocator::Save(char *filename)
{
	ofstream file(filename,ios::out|ios::binary) ;
    if (!file) return FALSE ;

    return WriteToFile(file) ;
}

