#ifndef _memalloc_h
#define _memalloc_h

#ifdef _OWLPCH
#include <owl\pch.h>
#else
#include <vcl.h>
#endif

#pragma hdrstop

#include <fstream.h>

#ifdef __WIN32__
#define __HUGEPTR
#else
#define __HUGEPTR huge
#endif

class MemoryAllocator
{
	HGLOBAL	handle ;
    DWORD 	size ;
    WORD	lockcount ;
public:
	BOOL	ReadData(DWORD offset,BYTE __HUGEPTR *data,DWORD count) ;
   	BOOL	WriteData(DWORD offset,BYTE __HUGEPTR *data,DWORD count) ;
    BOOL    AddData(BYTE __HUGEPTR *data,DWORD count) ;
    BOOL    AddString(char *string) { return AddData(string,strlen(string)) ; } ;
	DWORD	Size() { return IsOK() ? size : 0 ; } ;
	void 	FillWith(BYTE tofillwith, DWORD start = 0,DWORD end = 0) ;
	BOOL 	IsOK() { if (!handle) return FALSE ; return TRUE ; } ;
    BOOL 	Alloc(DWORD newsize) ;
	void 	Free() { if (IsOK()) { while (lockcount--) Unlock() ; GlobalFree(handle) ; } handle = NULL ; } ;
	void 	__HUGEPTR * Lock() { if (IsOK()) { lockcount ++ ; return GlobalLock(handle) ; } return NULL ; } ;
    BOOL 	Unlock() { if (lockcount) lockcount -- ; return GlobalUnlock(handle) ; } ;
    BOOL	CopyFrom(MemoryAllocator &other) ;
    BOOL	CopyFrom(BYTE __HUGEPTR *datatocopy, DWORD count) ;
    MemoryAllocator & operator = (MemoryAllocator &other) { Free() ; handle = other.handle ; size = other.size ; other.handle = NULL ; return *this ; } ;

    MemoryAllocator() { handle = NULL ; } ;
    MemoryAllocator(DWORD size) { handle = NULL ; Alloc(size) ; } ;

    DWORD	WordChecksum(DWORD numbytes = 0) ; // uses size if 0
    DWORD	ByteChecksum(DWORD numbytes = 0) ;

    BOOL	ReadFromFile(ifstream &is,DWORD numbytes = 0) ;
    BOOL	WriteToFile(ofstream &os,DWORD numbytes = 0) ;
    BOOL	WriteToFile(FILE *file,DWORD numbytes = 0) ;    
    DWORD	GetFillLevel(BYTE emptybyte = 0) ;

   	BOOL	Load(char *filename) ;
    BOOL	Save(char *filename) ;
	MemoryAllocator(char *name) {handle = NULL ; Load(name);} ;

    ~MemoryAllocator() { Free() ; } ;
} ;

class	MemoryAllocatorSession
{
	MemoryAllocator *parent ;
public:
    void 	__HUGEPTR * Lock() { return parent->Lock() ; } ;
    BOOL 	Unlock() { return parent->Unlock() ; } ;

	MemoryAllocatorSession(MemoryAllocator *p) { parent = p ; } ;
	~MemoryAllocatorSession() { Unlock() ; } ;
} ;

#define FileAllocator MemoryAllocator

#endif