#ifndef timer_h
#define timer_h

#define PRESCALER 256        /* actual prescaler value */
#define PRESCALER_SELECT 4  /* value loaded into TCCR0 to select prescaler (selected in accordance with PRESCALER) */
#define TICKS_PER_SECOND (OSCILLATOR_FREQ / PRESCALER / 256)

// Time to ticks conversion macros
#define TIMERMILLISECONDS2TICKS(x)   (((x) * TICKS_PER_SECOND)/1000L)
#define TIMERSECONDS2TICKS(x)        ((x) * TICKS_PER_SECOND)

/* public functions */
extern  void TIMERInitialise(void);
extern  BOOL TIMERHasTickTimeElapsed(void) ;

#endif /* timer_h */
