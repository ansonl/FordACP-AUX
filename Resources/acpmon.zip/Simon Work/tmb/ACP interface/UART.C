/*------------------------------------------------------------------------
      Copyright (c) 2003
      Copyright (c) LS Design (UK) Ltd
  ------------------------------------------------------------------------
 
        Project : LSD Generic
     Module Name: uart.c
        $Archive: /ivision/DMX Remote/UART.C $
       $Revision: 7 $
         $Author: Simon $
           $Date: 22/08/03 13:32 $
    Description : AVR UART driver
                :
  ----------------------------------------------------------------------*/

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\signal.h>
#include <avr\pgmspace.h>
#include <avr\wdt.h>

#include "types.h"
#include "defines.h"
#include "uart.h"

/* UART baud rate calculation macro */
#define UART_BAUD_SELECT    (OSCILLATOR_FREQ / (UART_BAUDRATE * 16l) - 1)

/* global variables */
U8 	UARTRxBuffer[32];
U8	UARTPutPointer ;
U8	UARTGetPointer ;

/*------------------------------------------------------------------------
  Function Name : UART 0 recieve IRQ handler
  Description   : Reads the recieved character and saves to rx buffer
  Parameters    : None
  Inputs        : Uart recieve data register
  Outputs       : UARTRxBuffer and UARTPutPointer are updated
  Return Value  : None
  Remarks       : 
  ----------------------------------------------------------------------*/

#ifdef SIG_USART0_RECV
SIGNAL(SIG_USART0_RECV)
#else
#ifdef SIG_UART0_RECV
SIGNAL(SIG_UART0_RECV)
#else
SIGNAL(SIG_UART_RECV)
#endif
#endif
{
    U8 byte;

    /* get byte from UART; this also clears RXC (UART Receive Complete bit) */

#ifdef UDR0
    byte = inp(UDR0); 
#else
    byte = inp(UDR);
#endif

    UARTRxBuffer[UARTPutPointer] = byte ;
    if (++UARTPutPointer == sizeof(UARTRxBuffer))
    {
		UARTPutPointer = 0 ;
    }
}

/*------------------------------------------------------------------------
  Function Name : UARTIsRxReady
  Description   : Query function to determine if a byte is in the queue
  Parameters    : None
  Inputs        : UARTPutPointer,UARTGetPointer
  Outputs       : None
  Return Value  : TRUE if a byte is in the buffer
  Remarks       : 
  ----------------------------------------------------------------------*/

BOOL
UARTIsRxReady(void)
{
	if (UARTPutPointer != UARTGetPointer)
    {
    	return TRUE ;
    }
    return FALSE ;
}

/*------------------------------------------------------------------------
  Function Name : UARTReadByte
  Description   : Reads a byte from the Rx buffer
  Parameters    : None
  Inputs        : UARTPutPointer,UARTGetPointer,UARTRxBuffer
  Outputs       : UARTGetPointer is updated
  Return Value  : byte from the buffer (0 if no byte is present)
  Remarks       : UARTIsRxReady should be used to determine if a byte is ready
  ----------------------------------------------------------------------*/

U8
UARTReadByte(void)
{
	U8	byte = 0 ;

    if (UARTIsRxReady())
    {
    	cli() ;
        byte = UARTRxBuffer[UARTGetPointer] ;
	    if (++UARTGetPointer == sizeof(UARTRxBuffer))
	    {
			UARTGetPointer = 0 ;
	    }
        sei() ;
    }
    return byte ;
}

/*------------------------------------------------------------------------
  Function Name : UARTSendByte
  Description   : Sends out a single byte via UART
  Parameters    : data - byte to send
  Inputs        : Waits for UART to be ready before sending
  Outputs       : UART data register is written
  Return Value  : none
  Remarks       : This function blocks until previous byte has gone
  ----------------------------------------------------------------------*/

void
UARTSendByte(U8 data)
{
    wdt_reset() ;

    /* wait for UART to become available */
#ifdef UCSR0A
    while (!(inp(UCSR0A) & BV(UDRE0)));
#else
#ifdef UCSRA
    while (!(inp(UCSRA) & BV(UDRE)));
#else
    while (!(inp(USR) & BV(UDRE)));
#endif    
#endif

    /* send character */
#ifdef UDR0
    outp(data, UDR0);
#else
    outp(data, UDR);
#endif
}

/*------------------------------------------------------------------------
  Function Name : UARTInitialise
  Description   : Initialises the UART
  Parameters    : None
  Inputs        : None
  Outputs       : UART is enabled, baud rate set, rx interrupt enabled
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTInitialise(void)
{
	/* enable RxD/TxD and RX interrupt */
#ifdef UCSR0B
    outp(BV(RXCIE0) | BV(RXEN0) | BV(TXEN0), UCSR0B);
#else
#ifdef UCSRB
    outp(BV(RXCIE) | BV(RXEN) | BV(TXEN), UCSRB);
#else
    outp(BV(RXCIE) | BV(RXEN) | BV(TXEN), UCR);
#endif
#endif

    /* set baud rate */
#ifdef	UBRR0L
    outb(UBRR0L,(U8)UART_BAUD_SELECT);
#else
#ifdef UBRRL
    outb(UBRRL,(U8)UART_BAUD_SELECT);
#else
    outb(UBRR,(U8)UART_BAUD_SELECT);
#endif
#endif
}

/*------------------------------------------------------------------------
  Function Name : UARTOutputString
  Description   : Sends a string from RAM to the UART
  Parameters    : string - pointer to null terminated string
  Inputs        : string is read
  Outputs       : UARTSendByte is used to output the characters
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutputString(char *string)
{
    while (*string)
    {
        UARTSendByte(*string) ;
        string ++ ;
    }
}

/*------------------------------------------------------------------------
  Function Name : UARTOutputConstString
  Description   : Sends a string from FLASH to the UART
  Parameters    : string - pointer to null terminated string
  Inputs        : string is read
  Outputs       : UARTSendByte is used to output the characters
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutputConstString(char *string)
{
    char temp ;

    while ((temp = PRG_RDB(string)))
    {
        UARTSendByte(temp) ;
        string ++ ;
    }
}

/*------------------------------------------------------------------------
  Function Name : UARTOutput4Bits
  Description   : Sends a hex nibble in ASCII to the UART
  Parameters    : value - nibble value to send
  Inputs        : none
  Outputs       : UARTSendByte is used to output the characters
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutput4Bits(U8 value)
{
	if (value > 9)
    {
    	value += 'A' - 10 ;
    }
    else
    {
    	value += '0' ;
    }
    UARTSendByte(value) ;
}

/*------------------------------------------------------------------------
  Function Name : UARTOutput8Bits
  Description   : Sends a hex byte in ASCII to the UART
  Parameters    : value - value to send
  Inputs        : none
  Outputs       : UARTOutput4Bits is used to output the 2 nibbles
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutput8Bits(U8 value)
{
	UARTOutput4Bits(value >> 4) ;
	UARTOutput4Bits(value & 0x0f) ;
}

/*------------------------------------------------------------------------
  Function Name : UARTOutput16Bits
  Description   : Sends a hex word in ASCII to the UART
  Parameters    : value - value to send
  Inputs        : none
  Outputs       : UARTOutput8Bits is used to output the 2 bytes
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutput16Bits(U16 value)
{
    UARTOutput8Bits(value >> 8) ;
    UARTOutput8Bits(value & 0xff) ;
}

/*------------------------------------------------------------------------
  Function Name : UARTOutputBinary
  Description   : Sends a hex byte in binary (ASCII) to the UART
  Parameters    : value - value to send
  Inputs        : none
  Outputs       : UARTSendByte is used to output the chracters (0 or 1)
  Return Value  : none
  Remarks       : 
  ----------------------------------------------------------------------*/

void
UARTOutputBinary(U8 value)
{
    U8 x ;

    for (x = 0 ; x < 8 ; x ++)
    {
        if (value & 0x80)
        {
            UARTSendByte('1') ;
        }
        else
        {
            UARTSendByte('0') ;
        }
        value <<= 1 ;
    }
}

