
#ifndef _defines_h
#define _defines_h

#define OSCILLATOR_FREQ     7372800
#define UART_BAUDRATE       115200

#endif
