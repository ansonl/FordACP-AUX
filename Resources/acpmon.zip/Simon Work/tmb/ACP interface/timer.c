/*------------------------------------------------------------------------
    Module Name : timer.c
    Description : general purpose timer
  ----------------------------------------------------------------------*/

#include <avr\interrupt.h>
#include <avr\signal.h>
#include "defines.h"
#include "types.h"

#include "timer.h"

/* global variables */
static volatile U8  TIMERTickCount ;

/*------------------------------------------------------------------------
  Interrupt Handler : TCNT0 overflow
  ----------------------------------------------------------------------*/

SIGNAL(SIG_OVERFLOW0)
{
    TIMERTickCount ++ ;
}

/*------------------------------------------------------------------------
  Function Name : TIMERInitialise
  Description   : initialisation; global interrupt enable bit must be set
                  elsewhere
  Parameters    :
  Return Value  :
  ----------------------------------------------------------------------*/

void 
TIMERInitialise(void)
{
    outp(PRESCALER_SELECT, TCCR0);  /* set prescaler (divides down clock) */
    outp(BV(TOIE0), TIMSK);         /* enable TCNT0 overflow interrupt */
}

/*------------------------------------------------------------------------
  Function Name : TIMERHasTickTimeElapsed
  Description   : query function to determine if tick time has elapsed
  Parameters    : none
  Return Value  : TRUE if time has elapsed
  ----------------------------------------------------------------------*/

U8 
TIMERHasTickTimeElapsed(void)
{
    if (TIMERTickCount)
    {
        cli();
        TIMERTickCount -- ;
        sei();
        return TRUE;
    }
    return FALSE;
}
