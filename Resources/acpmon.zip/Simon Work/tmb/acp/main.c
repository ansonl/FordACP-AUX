/*------------------------------------------------------------------------
      Copyright (c) 2003
      Copyright (c) LS Design (UK) Ltd
  ------------------------------------------------------------------------
 
        Project :
     Module Name: main.c
        $Archive: /MP3 Player/ACP interface/main.c $
       $Revision: 10 $
         $Author: Simon $
           $Date: 16/06/03 8:48 $
    Description : main module
                :
  ----------------------------------------------------------------------*/

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\signal.h>
#include <avr\pgmspace.h>
#include <avr\ina90.h>
#include <avr\wdt.h>

#include "types.h"
#include "defines.h"
#include "uart.h"
#include "version.h"
#include "modelid.h"
#include "iodefs.h"
#include "timer.h"
#include "acp.h"

const char PROGMEM TitleString[] = "ACP Data Logger " ;
const char PROGMEM SOFTWARE_VERSION[] = { 'V' , SOFTWARE_VERSION_MAJOR , '.' , SOFTWARE_VERSION_MINOR , 0 } ;
const char PROGMEM CRLFString[] = "\r\n" ;

/*------------------------------------------------------------------------
  Function Name : main
  Description   : main function
  Parameters    : None
  Inputs        : None
  Outputs       : None
  Return Value  : None
  Remarks       :
  ----------------------------------------------------------------------*/

int main(void)
{
    U8 ledtimer ;

    outb(DDRB,PORTB_INITDDR);
    outb(PORTB,PORTB_INITVALUE);

    outb(DDRD,PORTD_INITDDR);
    outb(PORTD,PORTD_INITVALUE);

    TIMERInitialise() ;		// start timer interrupt
    UARTInitialise();	// init the UART
    ACPInitialise();

    sei(); // Enable all interrupts

    UARTOutputConstString((char *)CRLFString) ;
    UARTOutputConstString((char *)CRLFString) ;
    UARTOutputConstString((char *)TitleString) ;
    UARTOutputConstString((char *)SOFTWARE_VERSION);
    UARTOutputConstString((char *)CRLFString) ;

    while (TRUE)
    {
        ACPService();

        if (TIMERHasTickTimeElapsed())
        {
            if (++ledtimer == TIMERMILLISECONDS2TICKS(400))
            {
                ledtimer = 0 ;

                IO_SETBOOTLED(!IO_GETBOOTLED());
            }
        }
 	}
}
