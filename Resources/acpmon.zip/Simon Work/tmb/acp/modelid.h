
#ifndef _modelid_h
#define _modelid_h

// customer IDs defined
#define CI_LSDPROPRIETARY	0x00
#define CI_RELACOUSTICS		0x01
#define CI_SKYSHIPS 		0x02
#define CI_IVISION          0x03
#define CI_CHAPTERAUDIO     0x04
#define CI_FALCON			0x11

// software IDs defined
// LSD proprietary
#define MI_T15HVPROGRAMMER	0x00
#define MI_MP3PLAYER        0x01

// REL acoustics
#define MI_STUDIOAMP		    0x00
#define MI_STRATASTORMCONTROL   0x01
#define MI_STUDIOCONTROL        0x02
#define MI_STUDIOREMOTE         0x03

// skyships
#define MI_PCONVERT		    0x00

// iVision
#define MI_DMXCONTROLLER    0x00

// falcon
#define MI_HHCUKCCU			0x00
#define MI_CRD              0x01
#define MI_CAD              0x02

// chapter audio
#define MI_PREFACE          0x00
#define MI_PREFACEREMOTE    0x01

#endif
