#ifndef _version_h
#define _version_h

#define	CUSTID 0x00
#define	MODELID 0x00

#define	SOFTWARE_VERSION_MAJOR '0'
#define	SOFTWARE_VERSION_MINOR 'A'
extern const char SOFTWARE_VERSION[] ;

#endif
