
#ifndef _iodefs_h
#define _iodefs_h

#define	PORTB_INITDDR		0x01    // all inputs
#define	PORTB_INITVALUE		0xff    // pull ups on

#define IO_SETBOOTLED(x)	{ if (x) { sbi(PORTB,0) ; } else { cbi(PORTB,0) ; }}
#define IO_GETBOOTLED()     bit_is_set(PORTB,0)

#define	PORTD_INITDDR		0x00    // all inputs
#define	PORTD_INITVALUE		0xff    // pull ups on

#endif
