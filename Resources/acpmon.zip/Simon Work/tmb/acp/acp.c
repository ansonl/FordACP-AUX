
#include <avr\io.h>
#include <avr\signal.h>

#include "types.h"
#include "defines.h"

#include "acp.h"

#define PRESCALER           8 	// Prescaler value
#define PRESCALER_SELECT    2 	// Value loaded into TCCR to select prescaler

#define ACP_BAUDRATE        9600L
#define ACP_BITTIME	        (U16)(((U32)OSCILLATOR_FREQ/((U32)PRESCALER*ACP_BAUDRATE))-1)
#define ACP_STARTBITTIME    (ACP_BITTIME/2)

#define ACP_ACKWAITTIME     ((ACP_BAUDRATE * 20)/1000)      // 20ms
#define ACP_RETRIES_MAX     5

U8      ACPBitCount ;
U8      ACPShiftRegister ;
U8      ACPUartFlags;
U8      ACPTxMessageBuffer[12];
U8      ACPRxMessageBuffer[12];
U8      ACPTxMessageCount ;
U8      ACPRxMessageCount ;
U8      ACPRxChecksum ;
U8      ACPTxOutCount ;
U8      ACPMessageFlags ;
U8      ACPCommand ;
U8      ACPModeBits ;
U8      ACPStatus ;
U8      ACPRetryCount ;
U8      ACPRetryTimer ;

U8      ACPCurrentDisk ;
U8      ACPCurrentTrack ;
U8      ACPTimeMins ;
U8      ACPTimeSeconds ;
U8      ACPDiskStatus ;

U8      ACPFCValue;
U8      ACPC8Value;

// flags byte
#define ACP_F_MSGRX         0x01
#define ACP_F_MSGREADY      0x02
#define ACP_F_SENDACK       0x04
#define ACP_F_TXFLAG        0x08
#define ACP_F_TXACTIVE      0x10
#define ACP_F_RXACTIVE      0x20
#define ACP_F_CSUMOK        0x40
#define ACP_F_RXACK         0x80

// message flags
#define ACP_MF_SENDSTATUS   0x01
#define ACP_MF_SENDDISK     0x02
#define ACP_MF_SENDTRACK    0x04
#define ACP_MF_SENDMODEBITS 0x08
#define ACP_MF_SENDDISKINFO 0x10
#define ACP_MF_SENDC8       0x20
#define ACP_MF_SENDE0       0x40
#define ACP_MF_SENDFC       0x80

// ACP status flags
#define ACP_SF_WAITFORACK   0x01

#define ACP_RXIDLE_TIME     20      // number of bits of idle to discard last message
#define ACP_TXIDLE_TIME     40      // number of bits of idle to start new message

#define ACP_RXD()       bit_is_set(ACSR,ACO)
#define ACP_SETTXD(x)   { if (x) { DDRB &= ~0x03 ; } else { DDRB |= 0x03 ; }}
#define ACP_GETTXD()    bit_is_clear(DDRB,0)

static  void
ACPPrepareForStartBit(void)
{
    sbi(ACSR,ACI);                    // clear int flag
    sbi(ACSR,ACIE);                    // enable int for start bit
}

static  void
ACPRxReset(void)
{
    ACPRxMessageCount = 0 ;
    ACPRxChecksum = 0 ;
}

/* Output Compare1(A) Interrupt Function name */
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	U16 reload ;
    U8  byte ;
    U8  flags;
    U8  bctemp ;

    reload = inw(OCR1L) ;
    reload += ACP_BITTIME ;
    outw(OCR1L,reload) ;

    flags = ACPUartFlags ;
    bctemp = ++ACPBitCount ;
    byte = ACPShiftRegister ;

    if (flags & ACP_F_TXACTIVE)
    {
        if (ACP_GETTXD() && !ACP_RXD())     // collision
        {
            flags &= ~ACP_F_TXACTIVE ;      // wait till next opportunity
            ACPPrepareForStartBit();           // enable int
        }
        else if (bctemp < 9)
        {
            ACP_SETTXD(byte & BV(0)) ;
            byte >>= 1 ;
        }
        else if ((bctemp == 10))  // EOD bit
        {
            ACP_SETTXD(!(flags & ACP_F_SENDACK) && ((++ACPTxOutCount) == ACPTxMessageCount));     // set EOD
        }
        else
        {
            ACP_SETTXD(TRUE);

            if (bctemp >= 11)
            {
                ACPPrepareForStartBit();           // enable int
                flags &= ~ACP_F_TXACTIVE ;

                if (flags & ACP_F_SENDACK)
                {
                    flags &= ~ACP_F_SENDACK ;
                }
                else if (ACPTxOutCount == ACPTxMessageCount)    // all bytes gone
                {
                    flags &= ~ACP_F_MSGREADY;
                }
                else
                {
                    flags |= ACP_F_TXFLAG ; // send next message byte
                }
            }
        }
    }
    else if (flags & ACP_F_TXFLAG)
    {
        cbi(GIMSK,INT0) ;                       // disable start bit interrupt
        ACP_SETTXD(FALSE) ;                     // start bit
        ACPBitCount = 0 ;                       // transmit active
        flags |= ACP_F_TXACTIVE ;
        flags &= ~ACP_F_TXFLAG ;

        byte = 0x06 ;        
        if (!(flags & ACP_F_SENDACK))
        {
            byte = ACPTxMessageBuffer[ACPTxOutCount] ;
        }
    }
    else if (flags & ACP_F_RXACTIVE)
    {
        byte >>= 1 ;
        if (ACP_RXD())
        {
            byte |= BV(7) ;
        }
    
        if (bctemp == 1)       // start bit centre
        {
            if (ACP_RXD()) // start bit is not low
            {
                flags &= ~ACP_F_RXACTIVE ;
                ACPPrepareForStartBit();    // abort reception, wait for a new start bit
            }
        }
        else if (bctemp == 9)     // if we have all the data bits
        {
            if (!ACPRxMessageCount && (byte == 0x06))
            {
                flags |= ACP_F_RXACK ;
            }
            else
            {
                flags &= ~ACP_F_CSUMOK ;

                if (ACPRxChecksum == byte)
                {
                    flags |= ACP_F_CSUMOK ;
                }

                ACPRxChecksum += byte ;     // add to checksum

                // add byte to message
                if (ACPRxMessageCount < sizeof(ACPRxMessageBuffer))
                {
                    ACPRxMessageBuffer[ACPRxMessageCount++] = byte;
                }
            }
        }
        else if (bctemp == 10)     // if we have the EOD bit
        {
            if (ACP_RXD())                  // if we have the EOD bit
            {
                if (flags & ACP_F_CSUMOK)   // and checksum is OK
                {
                    flags |= ACP_F_MSGRX ;  // we have a message
                }
            }
        }
        else if (bctemp == 11)     // if we have the stop bit
        {
            ACPPrepareForStartBit();        // prepare for new start bit
            flags &= ~ACP_F_RXACTIVE ;

            if (flags & ACP_F_MSGRX)        // if this is the end of a message
            {
                flags |= (ACP_F_TXFLAG|ACP_F_SENDACK);  // send ack
            }
        }
    }
    else if (bctemp == ACP_RXIDLE_TIME)  // idle
    {
        ACPRxReset();
    }
    else if (bctemp >= ACP_TXIDLE_TIME)  // idle
    {
        ACPBitCount = ACP_TXIDLE_TIME ;

        if (flags & ACP_F_MSGREADY)     // if we have a message to go
        {
            ACPTxOutCount = 0;
            flags |= ACP_F_TXFLAG ;     // start it off
        }
    }

    if (ACPRetryTimer) ACPRetryTimer -- ;

    ACPShiftRegister = byte ;
    ACPUartFlags = flags ;
}

// ACP start bit interrupt
SIGNAL(SIG_COMPARATOR)
{
    // reset timer 0
    outw(TCNT1L,0) ;
    outw(OCR1L,ACP_STARTBITTIME) ;  	// set TCNT1 for start bit
    ACPBitCount = 0 ;
    cbi(ACSR,ACIE);                     // disable int
   	sbi(TIFR,OCF1A);					// clear timer 1 compare flag
}

void
ACPInitialise(void)
{
  	outp(PRESCALER_SELECT, TCCR1B);	    // start timer1
    sbi(TIMSK,OCIE1A) ;		            // compare interrupt enable
    outb(ACSR,BIT(ACIS1));              // raise comparator int on falling edge
    ACPPrepareForStartBit();
}

static  void
ACPSendMessage(void)
{
    ACPRetryTimer = ACP_ACKWAITTIME;
    ACPUartFlags |= ACP_F_MSGREADY;
    ACPStatus |= ACP_SF_WAITFORACK ;
}

static  void
ACPAddChecksumAndSend(U8 length)
{
    U8 *ptr = ACPTxMessageBuffer ;
    U8 count = length ;
    U8 checksum = 0 ;

    do
    {
        checksum += *(ptr++) ;
    } while (--count);

    *ptr = checksum ;
    ACPTxMessageCount = length + 1 ;
    ACPRetryCount = 0 ;
    ACPSendMessage();
}

static  U8
ACPBin2BCD(U8 toconv)
{
    return ((toconv/10)*16) + (toconv % 10) ;
}

static  inline BOOL
ACPCheckSendBits(U8 mask)
{
    if (ACPMessageFlags & mask)
    {
        ACPMessageFlags &= ~mask ;
        return TRUE ;
    }
    return FALSE ;
}

void
ACPService(void)
{
    if (ACPUartFlags & ACP_F_MSGRX)     // we have a message
    {
        ACPUartFlags &= ~ACP_F_MSGRX ;

        if (ACPRxMessageBuffer[2] == 0x80)  // from the stereo
        {
            if (ACPRxMessageBuffer[1] == 0x9a)  // commands
            {
                if (ACPRxMessageBuffer[3] == 0xc1)
                {
                    ACPModeBits = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDMODEBITS ;
                }
                else if (ACPRxMessageBuffer[3] == 0xc2)
                {
                    ACPCommand = ACP_COMMAND_SELDISK | ACPRxMessageBuffer[4];
                }
                else if (ACPRxMessageBuffer[3] == 0xc3)
                {
                    ACPCommand = ACP_COMMAND_NEXTTRACK ;
                }
                else if (ACPRxMessageBuffer[3] == 0x43)
                {
                    ACPCommand = ACP_COMMAND_PREVTRACK ;
                }
                else if (ACPRxMessageBuffer[3] == 0xfc)
                {
                    ACPFCValue = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDFC ;
                }
                else if (ACPRxMessageBuffer[3] == 0xc8)
                {
                    ACPC8Value = ACPRxMessageBuffer[4] ;
                    ACPMessageFlags |= ACP_MF_SENDC8 ;
                }
            }
            else if (ACPRxMessageBuffer[1] == 0x9b)     // requests
            {
                if (ACPRxMessageBuffer[3] == 0xc2)
                {
                    ACPMessageFlags |= ACP_MF_SENDDISK ;
                }
                else if (ACPRxMessageBuffer[3] == 0xff)
                {
                    ACPMessageFlags |= ACP_MF_SENDSTATUS ;
                }
                else if (ACPRxMessageBuffer[3] == 0xe0)
                {
                    ACPMessageFlags |= ACP_MF_SENDE0 ;
                }
            }
        }
    }

    if (ACPStatus & ACP_SF_WAITFORACK)  // if we're waiting for acknowledge
    {
        if (ACPUartFlags & ACP_F_RXACK)      // if we have it
        {
            ACPUartFlags &= ~ACP_F_RXACK ;
            ACPStatus &= ~ACP_SF_WAITFORACK ;   // no longer waiting
        }
        else if (!ACPRetryTimer)    // timeout
        {
            if (++ACPRetryCount == ACP_RETRIES_MAX) // if max retries
            {
                ACPStatus &= ~ACP_SF_WAITFORACK ;   // give up
            }
            else
            {
                ACPSendMessage();                   // retry
            }
        }
    }
    else
    {
        // see if we need to send something
        ACPTxMessageBuffer[0] = 0x71 ;
        ACPTxMessageBuffer[1] = 0x9b ;
        ACPRxMessageBuffer[2] = 0x82;       // CD changer ID

        if (ACPCheckSendBits(ACP_MF_SENDDISK))
        {
            ACPTxMessageBuffer[3] = 0xc2 ;
            ACPTxMessageBuffer[4] = ACPCurrentDisk ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDTRACK))
        {
            ACPTxMessageBuffer[3] = 0xc3 ;
            ACPTxMessageBuffer[4] = ACPCurrentTrack ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDSTATUS))
        {
            ACPTxMessageBuffer[3] = 0xff ;
            ACPTxMessageBuffer[4] = ACPDiskStatus ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDMODEBITS))
        {
            ACPTxMessageBuffer[3] = 0xc1 ;
            ACPTxMessageBuffer[4] = ACPModeBits ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDDISKINFO))
        {
            ACPTxMessageBuffer[3] = 0xd0 ;
            ACPTxMessageBuffer[4] = ACPCurrentDisk ;
            ACPTxMessageBuffer[5] = ACPCurrentTrack ;
            ACPTxMessageBuffer[6] = ACPBin2BCD(ACPTimeMins) ;
            ACPTxMessageBuffer[7] = ACPBin2BCD(ACPTimeSeconds)|BIT(7) ;
            ACPAddChecksumAndSend(8);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDE0))
        {
            ACPTxMessageBuffer[3] = 0xe0 ;
            ACPTxMessageBuffer[4] = 0x04 ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDFC))
        {
            ACPTxMessageBuffer[3] = 0xfc ;
            ACPTxMessageBuffer[4] = ACPFCValue ;
            ACPAddChecksumAndSend(5);
        }
        else if (ACPCheckSendBits(ACP_MF_SENDC8))
        {
            ACPTxMessageBuffer[3] = 0xc8 ;
            ACPTxMessageBuffer[4] = ACPC8Value ;
            ACPAddChecksumAndSend(5);
        }
    }
}


U8      
ACPGetCommand(void)
{
    U8 cmd = ACPCommand ;

    ACPCommand = ACP_COMMAND_NONE ;

    return cmd ;
}

void    
ACPSetDisk(U8 disk)
{
    ACPCurrentDisk = disk ;
    ACPMessageFlags |= ACP_MF_SENDDISK ;
}

void    
ACPSetTrack(U8 track)
{
    ACPCurrentTrack = track ;
    ACPMessageFlags |= ACP_MF_SENDTRACK ;
}

void    
ACPSetDiskTime(U8 mins,U8 secs)
{
    ACPTimeMins = mins ;
    ACPTimeSeconds = secs ;
    ACPMessageFlags |= ACP_MF_SENDDISKINFO ;
}

U8      
ACPGetMode(void)
{
    return ACPModeBits ;
}

void
ACPSetStatus(U8 status)
{
    ACPDiskStatus = status ;
    ACPMessageFlags |= ACP_MF_SENDSTATUS ;
}

