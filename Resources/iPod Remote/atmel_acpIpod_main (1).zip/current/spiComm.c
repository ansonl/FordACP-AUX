/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "spiComm.h"

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// initialize SPI master
void SPI_initMaster(void)
{
	// set MOSI, SS and SCK output, all others input
	SPI_DDR = (1 << SPI_MOSI) | (1 << SPI_SCK) | (1 << SPI_SS);

	// enable SPI, master; set clock rate
	SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR1) | (1 << SPR0);

	// SS low
	SPI_PORT &= ~(1 << SPI_SS);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// general initialization
void SPI_init(void)
{
	SPI_initMaster();
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send SPI data
void SPI_sendData(uint8_t d)
{
	// send byte
	SPDR = d;
	// wait for transmission complete
	while(!(SPSR & (1<<SPIF)))
	{
		;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send SPI string
void SPI_sendString(uint8_t msgType, const char *msgContent, uint8_t msgLength)
{
	uint8_t c = 0;
	uint8_t i = 0;

	SPI_sendData(SPI_MSG_START);
	SPI_sendData(msgType);
	c = SPI_MSG_START + msgType;
	for (i = 0; i < msgLength; i++)
	{
		if (msgContent[i] == 0)
		{
			break;
		}
		else
		{
			c += msgContent[i];
			SPI_sendData(msgContent[i]);
		}
	}
	SPI_sendData(SPI_MSG_STOP);
	SPI_sendData(c);
}
