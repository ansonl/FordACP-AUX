/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

// CPU clock frequence: 14.745600 MHz; needs to be declared before #include <util/delay.h>
// when changing F_CPU, check following items:
//		-> UART-speed of ACP and IPOD
//		-> delay-functions: maximum values
#ifndef F_CPU
#define F_CPU		14745600
#endif

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// macros for DDR and PIN
// DDR(x)
#define DDR(x) (*(&x - 1))			// address of data direction register of port x

// PIN(x)
#if defined(__AVR_ATmega64__) || defined(__AVR_ATmega128__)
    // on ATmega64/128 PINF is on port 0x00 and not 0x60
    #define PIN(x) ( &PORTF==&(x) ? _SFR_IO8(0x00) : (*(&x - 2)) )
#else
	#define PIN(x) (*(&x - 2))		// address of input register of port x
#endif

// version
#define VERSION_MAJOR	0
#define VERSION_MINOR	1
#define VERSION_BUILD	10
