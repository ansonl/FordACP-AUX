/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "ipod.h"

////////////////////////////////////////////////
// defines/constants/declarations
////////////////////////////////////////////////

// status of the IPOD communication
uint8_t ipodRXStatus;
uint8_t ipodTXStatus;

// RX data
uint8_t ipodRXTotalBytes;
uint16_t ipodRXActiveData;
uint16_t ipodRXCurrentData;
uint8_t ipodRXData[IPOD_RX_DATA_BUFFERS][IPOD_RX_MAX_MSG_LENGTH_BUF];
uint8_t ipodRXDataCount[IPOD_RX_DATA_BUFFERS];
uint8_t ipodRXChecksum[IPOD_RX_DATA_BUFFERS];
uint8_t ipodRXStatusDetail[IPOD_RX_DATA_BUFFERS];

// TX data
uint8_t ipodTXTotalBytes;
uint16_t ipodTXActiveData;
uint16_t ipodTXCurrentData;
uint8_t ipodTXData[IPOD_TX_DATA_BUFFERS][IPOD_TX_MAX_MSG_LENGTH_BUF];
uint8_t ipodTXDataCount[IPOD_TX_DATA_BUFFERS];
uint8_t ipodTXChecksum[IPOD_TX_DATA_BUFFERS];

// processing data
uint16_t ipodProcRXData;
uint16_t ipodProcTXData;

// ipod status flags
uint8_t ipodStatusFlags = IPOD_STA_CLEAR;
// ipod logo status flags
uint8_t ipodLogoStatusFlags = IPOD_STA_LOGO_CLEAR;
// ipod command flags
uint32_t ipodCommandFlags = IPOD_CMD_CLEAR;

// ipod play info
uint32_t ipodInfoTracksTotal = 0;
uint32_t ipodInfoTracksCurrent = 0;
uint32_t ipodInfoAlbumsTotal = 0;
uint32_t ipodInfoAlbumsCurrent = 0;
uint32_t ipodInfoTimeTotal = 0;
uint32_t ipodInfoTimePlayed = 0;
uint32_t ipodInfoTimeRemain = 0;
uint8_t ipodInfoPlayStatus = IPOD_STOP;
uint8_t ipodInfoPlayStatusOld = IPOD_STOP;
uint8_t ipodInfoShuffleStatus = IPOD_SHUFFLE_UNKNOWN;
uint8_t ipodInfoRepeatStatus = IPOD_REPEAT_UNKNOWN;

// string variables
char ipodStrArtist[IPOD_STRLEN_ARTIST];
uint8_t ipodPosStrArtist = 0;
char ipodStrAlbum[IPOD_STRLEN_ALBUM];
uint8_t ipodPosStrAlbum = 0;
char ipodStrTrack[IPOD_STRLEN_TRACK];
uint8_t ipodPosStrTrack = 0;
char ipodStrTrackNrCur[IPOD_STRLEN_TRACKNR_CUR];
char ipodStrTrackNrTot[IPOD_STRLEN_TRACKNR_TOT];
char ipodStrTimePlayed[IPOD_STRLEN_TIME_PLAYED];
char ipodStrTimeRemain[IPOD_STRLEN_TIME_REMAIN];
char ipodStrTimeTotal[IPOD_STRLEN_TIME_TOTAL];
char ipodStrPlayStatus[IPOD_STRLEN_PLAY_STATUS];

// ipod string flags
uint16_t ipodStringFlags = IPOD_STA_STR_NONE;

uint8_t PROGMEM aIpodImage[IPOD_LOGO_HEIGHT * IPOD_LOGO_WIDTH / (8 / IPOD_LOGO_BPP)] =
{
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x90, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF4, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x95, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x56, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x15, 0x55, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x6B, 0xFF, 0xFF, 0xFA, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2B, 0xFF, 0xFF, 0xFF, 0xFF, 0xF9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x06, 0xFF, 0xFE, 0xA5, 0x56, 0xAF, 0xFF, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x2F, 0xFE, 0x50, 0x00, 0x00, 0x01, 0xAF, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x02, 0xFF, 0x90, 0x00, 0x00, 0x00, 0x00, 0x06, 0xFF, 0x90, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x1B, 0xF9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0xF8, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x7F, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xFE, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x02, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0xD0, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x0B, 0xF4, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xF4, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x2F, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xFD, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0xBF, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBF, 0x40, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x01, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0xC0, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x07, 0xF4, 0x00, 0x0B, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xE0, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x0F, 0xD0, 0x00, 0x6F, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xF4, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x2F, 0x80, 0x01, 0xFF, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x7F, 0x00, 0x07, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0xBD, 0x00, 0x0F, 0xF4, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x40, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x01, 0xF8, 0x00, 0x2F, 0xC0, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x80, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x02, 0xF4, 0x00, 0x3F, 0x40, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xD0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x07, 0xE0, 0x00, 0x09, 0x02, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0xE0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x0B, 0xD0, 0x00, 0x00, 0x0B, 0xF4, 0x00, 0xAF, 0xFE, 0x40, 0x00, 0x00, 0x00, 0x00, 0x02, 0xF0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x0F, 0xC0, 0x00, 0x00, 0x07, 0xC0, 0x0B, 0xFF, 0xFF, 0xE4, 0x00, 0x00, 0x00, 0x00, 0x01, 0xF4, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x1F, 0x80, 0x00, 0x00, 0x01, 0x40, 0x2F, 0xFA, 0xAF, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x2F, 0x40, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x80, 0x01, 0xBF, 0x40, 0x00, 0x00, 0x00, 0x00, 0xBC, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x2F, 0x00, 0x00, 0x00, 0x00, 0x02, 0xF8, 0x00, 0x00, 0x1F, 0xD0, 0x00, 0x00, 0x00, 0x00, 0xBD, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xE0, 0x00, 0x00, 0x07, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x7D, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x0F, 0xC0, 0x00, 0x00, 0x02, 0xF4, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x80, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x00, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x00, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x40, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x0F, 0xC0, 0x00, 0x00, 0x01, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xE0, 0x00, 0x00, 0x07, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x7D, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x2F, 0x00, 0x00, 0x00, 0x00, 0x03, 0xF8, 0x00, 0x00, 0x1F, 0xE0, 0x00, 0x00, 0x00, 0x00, 0xBD, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x2F, 0x40, 0x00, 0x00, 0x00, 0x01, 0xFE, 0x40, 0x00, 0xBF, 0x80, 0x00, 0x00, 0x00, 0x00, 0xBC, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x1F, 0x80, 0x00, 0x00, 0x00, 0x00, 0x7F, 0xE9, 0x6B, 0xFE, 0x00, 0x40, 0x00, 0x00, 0x00, 0xF8, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x0F, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xFF, 0xFF, 0xF4, 0x01, 0xE0, 0x00, 0x00, 0x01, 0xF8, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x0B, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x01, 0xBF, 0xFE, 0x40, 0x07, 0xF4, 0x00, 0x00, 0x02, 0xF0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x07, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x50, 0x00, 0x2F, 0xD0, 0x24, 0x00, 0x07, 0xE0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x02, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0x40, 0xBD, 0x00, 0x0B, 0xD0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x01, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x19, 0x01, 0xFD, 0x00, 0x0F, 0xC0, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0xF8, 0x00, 0x2F, 0x40, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0xE0, 0x00, 0x7E, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x2F, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBF, 0x80, 0x00, 0xFD, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x0F, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xFE, 0x00, 0x02, 0xF8, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x07, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x0B, 0xF0, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x02, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x1F, 0xD0, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0xBE, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x40, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x2F, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xFD, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x0B, 0xF4, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xF8, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x02, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0xD0, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0xBF, 0x90, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xFF, 0x40, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x1F, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1B, 0xF8, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x02, 0xFF, 0x90, 0x00, 0x00, 0x00, 0x00, 0x01, 0xBF, 0xD0, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x6F, 0xFA, 0x40, 0x00, 0x00, 0x00, 0x6F, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x06, 0xFF, 0xFA, 0x55, 0x55, 0x6B, 0xFF, 0xE4, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x6F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xAF, 0xFF, 0xFF, 0xFE, 0x90, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x5A, 0xA5, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xBE, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2F, 0xFA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAF, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xBF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

////////////////////////////////////////////////
// interrupt handling
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// data received on uart
ISR(IPOD_UART_RECV)
{
	// variables
	uint8_t uartStatus;
	uint8_t rxByte;

	// status uart
	uartStatus = IPOD_UART_UCSRA;

	// rxByte
	rxByte = IPOD_UART_UDR;

	// check if there is a frame error, data overrun or parity error
	if ((uartStatus & ((1<<IPOD_UART_FE)|(1<<IPOD_UART_DOR)|(1<<IPOD_UART_PE))) != 0x00)
	{
		return;
	}

	// increment total RX bytes
	ipodRXTotalBytes++;

	// process the received data
	ipodProcessReceivedData(rxByte);
}

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// initializes the IPOD uart
void ipodUartInit(void)
{
	// we will use IPOD_UART for communication with the head unit
	// IPOD_TX: DDR set low; PORT set low
	// IPOD_RX: DDR set low; PORT set low
	DDR(IPOD_PORT) &= ~_BV(IPOD_TX_PIN);
	DDR(IPOD_PORT) &= ~_BV(IPOD_RX_PIN);
	IPOD_PORT &= ~_BV(IPOD_TX_PIN);
	IPOD_PORT &= ~_BV(IPOD_RX_PIN);

	// set UART baud rate
	IPOD_UART_UBRRH = (uint8_t)(IPOD_UART_BAUD_SELECT>>8);
	IPOD_UART_UBRRL = (uint8_t)(IPOD_UART_BAUD_SELECT);

	// set UART for:
	//		ACP_UART_UCSRA
	//		- asynchronous normal mode (default)
	//		ACP_UART_UCSRB/ACP_UART_UCSRC
	//		- RXCIE (RX complete interrupt enable)
	//		- RXEN (RX enable)
	//		- TXEN (TX enable)
	//		- 8 data bits
	//		- no parity (default)
	//		- 1 stop bit (default)
	IPOD_UART_UCSRB = (uint8_t)((1<<IPOD_UART_RXCIE) | (1<<IPOD_UART_RXEN) | (1<<IPOD_UART_TXEN));
	IPOD_UART_UCSRC = (uint8_t)((1<<IPOD_UART_URSEL) | (1<<IPOD_UART_UCSZ1) | (1<<IPOD_UART_UCSZ0));
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the IPOD variables

////////////////////////////////////////////////////////////////////////////////////////////////
// ipodRXStatus
void ipodResetRXStatus(void)
{
	ipodRXStatus = IPOD_RX_READY;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// ipodRXStatus
void ipodResetTXStatus(void)
{
	ipodTXStatus = IPOD_TX_READY;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the RX data
void ipodResetRXData(void)
{
	uint8_t i, j;

	ipodRXTotalBytes = 0;
	ipodRXActiveData = 0x00;
	ipodRXCurrentData = 0;

	for (i = 0; i < IPOD_RX_DATA_BUFFERS; i++)
	{
		// reset the counters
		ipodRXDataCount[i] = 0;

		// reset the checksums
		ipodRXChecksum[i] = 0;

		// reset the detailed RX status
		ipodRXStatusDetail[i] = IPOD_RX_STA_CLEAR;

		for (j = 0; j < IPOD_RX_MAX_MSG_LENGTH_BUF; j++)
		{
			ipodRXData[i][j] = 0x00;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the TX data
void ipodResetTXData(void)
{
	uint8_t i, j;

	ipodTXTotalBytes = 0;
	ipodTXActiveData = 0x00;
	ipodTXCurrentData = 0;

	for (i = 0; i < IPOD_TX_DATA_BUFFERS; i++)
	{
		// reset the counters
		ipodTXDataCount[i] = 0;

		// reset the checksums
		ipodTXChecksum[i] = 0;

		for (j = 0; j < IPOD_TX_MAX_MSG_LENGTH_BUF; j++)
		{
			ipodTXData[i][j] = 0x00;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the processing data
void ipodResetProcData(void)
{
	ipodProcRXData = 0;
	ipodProcTXData = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// general initialization
void ipodInit(void)
{
	ipodResetRXStatus();
	ipodResetTXStatus();
	ipodResetRXData();
	ipodResetTXData();
	ipodResetProcData();
	ipodUartInit();
}

////////////////////////////////////////////////////////////////////////////////////////////////
// process the received ipod-data
void ipodProcessReceivedData(uint8_t rxByte)
{
	switch (ipodRXStatus)
	{
		case IPOD_RX_READY:
		case IPOD_RX_RECEIVING:
		{
			if (ipodRXStatus == IPOD_RX_READY)
			{
				// change status: receiving data
				ipodRXStatus = IPOD_RX_RECEIVING;

				// prepare buffer variables
				ipodRXActiveData &= ~(1<<ipodRXCurrentData);
				ipodRXDataCount[ipodRXCurrentData] = 0;
				ipodRXChecksum[ipodRXCurrentData] = 0;
				// first we expect START1
				ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_START1;
			}

			// process the data
			if (ipodRXDataCount[ipodRXCurrentData] < IPOD_RX_MAX_MSG_LENGTH)
			{
				// if received <= IPOD_MAX_MSG_LENGTH bytes
				if (ipodRXStatusDetail[ipodRXCurrentData] != IPOD_RX_STA_EXPECT_DATA_STRING)
				{
					// normal data
					if (ipodRXStatusDetail[ipodRXCurrentData] != IPOD_RX_STA_EXPECT_CHECKSUM)
					{
						// only if we don't expect checksum: store byte
						if (ipodRXDataCount[ipodRXCurrentData] < IPOD_RX_MAX_MSG_LENGTH_BUF)
						{
							// if received <= IPOD_MAX_MSG_LENGTH_BUF bytes: message must still fit in normal buffers
							ipodRXData[ipodRXCurrentData][ipodRXDataCount[ipodRXCurrentData]] = rxByte;
						}
						else
						{
							// if received > IPOD_MAX_MSG_LENGTH_BUF bytes: message too long for normal buffers; start over again

							// reset status of current message
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_CLEAR;
							// reset RX status
							ipodResetRXStatus();

							break;
						}
					}
				}
				else
				{
					// string data
					// which string is being received?
					switch (ipodRXData[ipodRXCurrentData][5])
					{
						case 0x21:	// track
						{
							if (ipodPosStrTrack < (IPOD_STRLEN_TRACK))
							{
								ipodStrTrack[ipodPosStrTrack] = rxByte;
								ipodStrTrack[ipodPosStrTrack + 1] = 0x00;
								ipodPosStrTrack++;
							}
							break;
						}
						case 0x23:	// artist
						{
							if (ipodPosStrArtist < (IPOD_STRLEN_ARTIST))
							{
								ipodStrArtist[ipodPosStrArtist] = rxByte;
								ipodStrArtist[ipodPosStrArtist + 1] = 0x00;
								ipodPosStrArtist++;
							}
							break;
						}
						case 0x25:	// album
						{
							if (ipodPosStrAlbum < (IPOD_STRLEN_ALBUM))
							{
								ipodStrAlbum[ipodPosStrAlbum] = rxByte;
								ipodStrAlbum[ipodPosStrAlbum + 1] = 0x00;
								ipodPosStrAlbum++;
							}
							break;
						}
					}
				}

				// increase the received data counter
				ipodRXDataCount[ipodRXCurrentData] += 1;

				switch (ipodRXStatusDetail[ipodRXCurrentData])
				{
					case IPOD_RX_STA_EXPECT_START1:
					{
						if (rxByte == IPOD_MSG_START1)
						{
							// now we expect START2
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_START2;
						}
						else
						{
							// invalid message
							// reset RX status
							ipodResetRXStatus();
						}
						break;
					}
					case IPOD_RX_STA_EXPECT_START2:
					{
						if (rxByte == IPOD_MSG_START2)
						{
							// now we expect LENGTH
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_LENGTH;
						}
						else
						{
							// invalid message
							// reset RX status
							ipodResetRXStatus();
						}
						break;
					}
					case IPOD_RX_STA_EXPECT_LENGTH:
					{
						// count for checksum
						ipodRXChecksum[ipodRXCurrentData] = rxByte;

						// if length > 3; we expect MODE, CMD1 and CMD2, else we expect DATA_SIMPLE
						if (ipodRXData[ipodRXCurrentData][2] > 3)
						{
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_MODE;
						}
						else
						{
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_DATA_SIMPLE;
						}
						break;
					}
					case IPOD_RX_STA_EXPECT_MODE:
					{
						// count for checksum
						ipodRXChecksum[ipodRXCurrentData] += rxByte;

						// now we expect CMD1
						ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_CMD1;
						break;
					}
					case IPOD_RX_STA_EXPECT_CMD1:
					{
						// count for checksum
						ipodRXChecksum[ipodRXCurrentData] += rxByte;

						// now we expect CMD2
						ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_CMD2;
						break;
					}
					case IPOD_RX_STA_EXPECT_CMD2:
					{
						// count for checksum
						ipodRXChecksum[ipodRXCurrentData] += rxByte;

						// now we expect DATA_SIMPLE or DATA_STRING
						switch (ipodRXData[ipodRXCurrentData][5])
						{
							case 0x21:		// track
							{
								ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_DATA_STRING;
								ipodPosStrTrack = 0;
								break;
							}
							case 0x23:		// artist
							{
								ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_DATA_STRING;
								ipodPosStrArtist = 0;
								break;
							}
							case 0x25:		// album
							{
								ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_DATA_STRING;
								ipodPosStrAlbum = 0;
								break;
							}
							default:
							{
								ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_DATA_SIMPLE;
								break;
							}
						}
						break;
					}
					case IPOD_RX_STA_EXPECT_DATA_SIMPLE:
					case IPOD_RX_STA_EXPECT_DATA_STRING:
					{
						// count for checksum
						ipodRXChecksum[ipodRXCurrentData] += rxByte;

						if ((ipodRXDataCount[ipodRXCurrentData] - 3) == ipodRXData[ipodRXCurrentData][2])
						{
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_EXPECT_CHECKSUM;
						}
						break;
					}
					case IPOD_RX_STA_EXPECT_CHECKSUM:
					{
						uint16_t tempChecksum = 0x0100 - (uint16_t)ipodRXChecksum[ipodRXCurrentData];

						if ((tempChecksum & 0x00FF) == (uint16_t)rxByte)
						{
							// checksum OK
							// valid IPOD-message

							// reset buffer status
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_CLEAR;

							// set current data active data
							ipodRXActiveData |= (1<<ipodRXCurrentData);

							// next buffer to use
							ipodRXCurrentData = (ipodRXCurrentData + 1) % IPOD_RX_DATA_BUFFERS;

							// change rx status
							ipodRXStatus = IPOD_RX_MSG_COMPLETE;

							if (ipodRXActiveData != IPOD_FULL_RX_BUFFER)
							{
								ipodRXStatus = IPOD_RX_READY;
							}
							else
							{
								ipodRXStatus = IPOD_RX_BUFFERS_FULL;
							}
						}
						else
						{
							// invalid message
							// reset status of current message
							ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_CLEAR;
							// reset RX status
							ipodResetRXStatus();
						}
						break;
					}
				}
			}
			else
			{
				// if received > IPOD_MAX_MSG_LENGTH bytes: message too long; start over again

				// reset status of current message
				ipodRXStatusDetail[ipodRXCurrentData] = IPOD_RX_STA_CLEAR;
				// reset RX status
				ipodResetRXStatus();
			}

			break;
		}
		case IPOD_RX_MSG_COMPLETE:			// should not come here
		case IPOD_RX_BUFFERS_FULL:
		{
			// messages needs to be handled first; ignore data
			break;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// convert time in ms to string
void convertIntToTime(uint32_t lngTime, char *strTime, uint8_t sign)
{
	uint8_t i = 0;

	if (sign != 0)
	{
		strTime[i] = '-';
		i++;
	}

	lngTime /= 1000;

	if (lngTime > 3599)
	{
		strTime[i] = '-';
		i++;
		strTime[i] = '-';
		i++;
		strTime[i] = ':';
		i++;
		strTime[i] = '-';
		i++;
		strTime[i] = '-';
		i++;
	}
	else
	{
		uint8_t tempMin = lngTime / 60;;
		uint8_t tempSec = lngTime % 60;

		if (tempMin < 10)
		{
			if (sign != 0)
			{
				strTime[i - 1] = ' ';
				strTime[i] = '-';
				i++;
			}
			else
			{
				strTime[i] = ' ';
				i++;
			}
			strTime[i] = '0' + tempMin;
			i++;
		}
		else
		{
			strTime[i] = '0' + (tempMin / 10);
			i++;
			strTime[i] = '0' + (tempMin % 10);
			i++;
		}

		strTime[i] = ':';
		i++;

		if (tempSec < 10)
		{
			strTime[i] = '0';
			i++;
			strTime[i] = '0' + tempSec;
			i++;
		}
		else
		{
			strTime[i] = '0' + (tempSec / 10);
			i++;
			strTime[i] = '0' + (tempSec % 10);
			i++;
		}
	}

	strTime[i] = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// process received messages
void ipodProcessReceivedMessages(void)
{
	// if we've got data in the RX buffer
	while (ipodRXActiveData != IPOD_EMPTY_RX_BUFFER)
	{
		// process data in ipodRXData[ipodProcRXData]
		// 6th byte contains command info
		switch (ipodRXData[ipodProcRXData][5])
		{
			// time and status info
			case 0x1D:
			{
				// bytes 7-10 contain track length in ms
				ipodInfoTimeTotal = ipodRXData[ipodProcRXData][6];
				ipodInfoTimeTotal <<= 8;
				ipodInfoTimeTotal += ipodRXData[ipodProcRXData][7];
				ipodInfoTimeTotal <<= 8;
				ipodInfoTimeTotal += ipodRXData[ipodProcRXData][8];
				ipodInfoTimeTotal <<= 8;
				ipodInfoTimeTotal += ipodRXData[ipodProcRXData][9];

				// bytes 11-14 contain elapsed time in ms
				ipodInfoTimePlayed = ipodRXData[ipodProcRXData][10];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][11];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][12];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][13];

				ipodInfoTimeRemain = ipodInfoTimeTotal - ipodInfoTimePlayed;

				// byte 15 contains play status (0x00 = stop; 0x01 = playing; 0x02 = paused)
				ipodInfoPlayStatus = ipodRXData[ipodProcRXData][14];

				// we don't use polling, so we need to update here
				convertIntToTime(ipodInfoTimeTotal, *ipodGetPointer_strTimeTotal(), 0);
				convertIntToTime(ipodInfoTimePlayed, *ipodGetPointer_strTimePlayed(), 0);
				convertIntToTime(ipodInfoTimeRemain, *ipodGetPointer_strTimeRemain(), 1);

				ipodStringFlags |= IPOD_STA_STR_TIME_PLAYED;
				ipodStringFlags |= IPOD_STA_STR_TIME_REMAIN;
				ipodStringFlags |= IPOD_STA_STR_TIME_TOTAL;

				// only update play status when not seeking
				if (!(ipodStatusFlags & IPOD_STA_SEEKING))
				{
					ipodSetPlayStatus();
				}

				break;
			}
			// current nr. in playlist
			case 0x1F:
			{
				// bytes 7-10 contain current nr. in playlist
				ipodInfoTracksCurrent = ipodRXData[ipodProcRXData][6];
				ipodInfoTracksCurrent <<= 8;
				ipodInfoTracksCurrent += ipodRXData[ipodProcRXData][7];
				ipodInfoTracksCurrent <<= 8;
				ipodInfoTracksCurrent += ipodRXData[ipodProcRXData][8];
				ipodInfoTracksCurrent <<= 8;
				ipodInfoTracksCurrent += ipodRXData[ipodProcRXData][9];
				ipodInfoTracksCurrent += 1;		// zero-indexed

				if (ipodInfoTracksCurrent > 9999)
				{
					ipodStrTrackNrCur[0] = '-';
					ipodStrTrackNrCur[1] = '-';
					ipodStrTrackNrCur[2] = '-';
					ipodStrTrackNrCur[3] = '-';
					ipodStrTrackNrCur[4] = 0;
				}
				else
				{
					itoa(ipodInfoTracksCurrent, ipodStrTrackNrCur, 10);
				}

				ipodStringFlags |= IPOD_STA_STR_TRACKNR_CUR;

				break;
			}
			// trackname
			case 0x21:
			{
					ipodStringFlags |= IPOD_STA_STR_TRACK;
			}
			// artist
			case 0x23:
			{
					ipodStringFlags |= IPOD_STA_STR_ARTIST;
			}
			// album
			case 0x25:
			{
					ipodStringFlags |= IPOD_STA_STR_ALBUM;
			}
			// elapsed time (polled)
			case 0x27:
			{
				/*
				// bytes 8-11 contain elapsed time in ms
				ipodInfoTimePlayed = ipodRXData[ipodProcRXData][7];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][8];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][9];
				ipodInfoTimePlayed <<= 8;
				ipodInfoTimePlayed += ipodRXData[ipodProcRXData][10];

				ipodInfoTimeRemain = ipodInfoTimeTotal - ipodInfoTimePlayed;

				convertIntToTime(ipodInfoTimeTotal, *ipodGetPointer_strTimeTotal(), 0);
				convertIntToTime(ipodInfoTimePlayed, *ipodGetPointer_strTimePlayed(), 0);
				convertIntToTime(ipodInfoTimeRemain, *ipodGetPointer_strTimeRemain(), 1);

				ipodStringFlags |= IPOD_STA_STR_TIME_PLAYED;
				ipodStringFlags |= IPOD_STA_STR_TIME_REMAIN;
				ipodStringFlags |= IPOD_STA_STR_TIME_TOTAL;
				*/

				break;
			}
			// shuffle mode
			case 0x2D:
			{
				ipodInfoShuffleStatus = ipodRXData[ipodProcRXData][6];

				// only update play status when not seeking
				if (!(ipodStatusFlags & IPOD_STA_SEEKING))
				{
					ipodSetPlayStatus();
				}

				break;
			}
			// total nr. in playlist
			case 0x36:
			{
				// bytes 7-10 contain total nr. in playlist
				ipodInfoTracksTotal = ipodRXData[ipodProcRXData][6];
				ipodInfoTracksTotal <<= 8;
				ipodInfoTracksTotal += ipodRXData[ipodProcRXData][7];
				ipodInfoTracksTotal <<= 8;
				ipodInfoTracksTotal += ipodRXData[ipodProcRXData][8];
				ipodInfoTracksTotal <<= 8;
				ipodInfoTracksTotal += ipodRXData[ipodProcRXData][9];

				if (ipodInfoTracksTotal > 9999)
				{
					ipodStrTrackNrTot[0] = '-';
					ipodStrTrackNrTot[1] = '-';
					ipodStrTrackNrTot[2] = '-';
					ipodStrTrackNrTot[3] = '-';
					ipodStrTrackNrTot[5] = 0;
				}
				else
				{
					itoa(ipodInfoTracksTotal, ipodStrTrackNrTot, 10);
				}

				ipodStringFlags |= IPOD_STA_STR_TRACKNR_TOT;

				break;
			}
			default:
			{
				// ignore message
				break;
			}
		}

		// clear the processed buffer bit
		ipodRXActiveData &= ~(1<<ipodProcRXData);

		// next buffer to use
		ipodProcRXData = (ipodProcRXData + 1) % IPOD_RX_DATA_BUFFERS;

		// if we had a full buffer
		if (ipodRXActiveData != IPOD_FULL_RX_BUFFER)
		{
			if (ipodRXStatus == IPOD_RX_BUFFERS_FULL)
			{
				ipodRXStatus = IPOD_RX_READY;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return total RX bytes
uint8_t ipodGetTotalRXBytes(void)
{
	return ipodRXTotalBytes;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return total TX bytes
uint8_t ipodGetTotalTXBytes(void)
{
	return ipodTXTotalBytes;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get status flags
uint8_t ipodGetStatusFlags(void)
{
	return ipodStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set status flags
void ipodSetStatusFlags(uint8_t ipodNewStatusFlags)
{
	ipodStatusFlags = ipodNewStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get logo status flags
uint8_t ipodGetLogoStatusFlags(void)
{
	return ipodLogoStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set status flags
void ipodSetLogoStatusFlags(uint8_t ipodNewLogoStatusFlags)
{
	ipodLogoStatusFlags = ipodNewLogoStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get command flags
uint32_t ipodGetCommandFlags(void)
{
	return ipodCommandFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set command flags
void ipodSetCommandFlags(uint32_t ipodNewCommandFlags)
{
	ipodCommandFlags = ipodNewCommandFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get string flags
uint16_t ipodGetStringFlags(void)
{
	return ipodStringFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set string flags
void ipodSetStringFlags(uint16_t ipodNewStringFlags)
{
	ipodStringFlags = ipodNewStringFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set play status
void ipodSetPlayStatus(void)
{
	uint8_t tempPlayStatus = ipodStrPlayStatus[0] & 0x0F;
	uint8_t tempShuffleStatus = ipodStrPlayStatus[0] & 0xF0;

	switch (ipodInfoPlayStatus)
	{
		case IPOD_STOP: tempPlayStatus = SPI_MSG_STA_STOP; break;
		case IPOD_PLAY: tempPlayStatus = SPI_MSG_STA_PLAY; break;
		case IPOD_PAUSE: tempPlayStatus = SPI_MSG_STA_PAUSE; break;
		case IPOD_FAST_REV: tempPlayStatus = SPI_MSG_STA_FAST_REV; break;
		case IPOD_FAST_FWD: tempPlayStatus = SPI_MSG_STA_FAST_FWD; break;
	}

	switch (ipodInfoShuffleStatus)
	{
		case IPOD_SHUFFLE_OFF: tempShuffleStatus = SPI_MSG_STA_SHUFFLE_OFF; break;
		case IPOD_SHUFFLE_TRACK: tempShuffleStatus = SPI_MSG_STA_SHUFFLE_TRACK; break;
		case IPOD_SHUFFLE_ALBUM: tempShuffleStatus = SPI_MSG_STA_SHUFFLE_ALBUM; break;
	}

	if (ipodStrPlayStatus[0] != (tempShuffleStatus + tempPlayStatus))
	{
		ipodStrPlayStatus[0] = tempShuffleStatus + tempPlayStatus;
		ipodStringFlags |= IPOD_STA_STR_PLAY_STATUS;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send commands
void ipodSendCommands(void)
{
	// if we've got commands to process
	if (ipodCommandFlags != IPOD_CMD_CLEAR)
	{
		// this command order is important
		if (ipodCommandFlags & IPOD_CMD_DEF_REMOTE_MODE)
		{
			ipodPrepareMessage(IPOD_CMD_DEF_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_ADV_REMOTE_MODE)
		{
			ipodPrepareMessage(IPOD_CMD_ADV_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_RELEASE_BTN)
		{
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_ON)
		{
			ipodPrepareMessage(IPOD_CMD_DEF_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_ON);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_ADV_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_SET_REPEAT_MODE);
			ipodPrepareMessage(IPOD_CMD_START_POLL);
		}

		if (ipodCommandFlags & IPOD_CMD_OFF)
		{
			ipodPrepareMessage(IPOD_CMD_STOP_POLL);
			ipodPrepareMessage(IPOD_CMD_DEF_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_OFF);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_PLAY)
		{
			ipodPrepareMessage(IPOD_CMD_PLAY);
		}

		if (ipodCommandFlags & IPOD_CMD_PAUSE)
		{
			ipodPrepareMessage(IPOD_CMD_PAUSE);
		}

		if (ipodCommandFlags & IPOD_CMD_STOP)
		{
			ipodPrepareMessage(IPOD_CMD_STOP);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_REV_3ALB)
		{		
			ipodPrepareMessage(IPOD_CMD_SKIP_REV_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_SKIP_REV_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_SKIP_REV_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}
		
		if (ipodCommandFlags & IPOD_CMD_SKIP_FWD_3ALB)
		{
			ipodPrepareMessage(IPOD_CMD_SKIP_FWD_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_SKIP_FWD_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
			ipodPrepareMessage(IPOD_CMD_SKIP_FWD_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_REV_1ALB)
		{
			ipodPrepareMessage(IPOD_CMD_SKIP_REV_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_FWD_1ALB)
		{
			ipodPrepareMessage(IPOD_CMD_SKIP_FWD_1ALB);
			ipodPrepareMessage(IPOD_CMD_RELEASE_BTN);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_ALB_PREPARE)
		{
			ipodPrepareMessage(IPOD_CMD_DEF_REMOTE_MODE);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_ALB_FINISH)
		{
			ipodPrepareMessage(IPOD_CMD_ADV_REMOTE_MODE);
			ipodPrepareMessage(IPOD_CMD_PLAY);
			ipodPrepareMessage(IPOD_CMD_START_POLL);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_REV)
		{
			ipodPrepareMessage(IPOD_CMD_SKIP_REV);
		}

		if (ipodCommandFlags & IPOD_CMD_SKIP_FWD)
		{
			ipodPrepareMessage(IPOD_CMD_SKIP_FWD);
		}

		if (ipodCommandFlags & IPOD_CMD_FAST_REV)
		{
			ipodPrepareMessage(IPOD_CMD_FAST_REV);

			ipodInfoPlayStatusOld = ipodInfoPlayStatus;
			ipodInfoPlayStatus = IPOD_FAST_REV;
			ipodSetPlayStatus();
		}

		if (ipodCommandFlags & IPOD_CMD_FAST_FWD)
		{
			ipodPrepareMessage(IPOD_CMD_FAST_FWD);

			ipodInfoPlayStatusOld = ipodInfoPlayStatus;
			ipodInfoPlayStatus = IPOD_FAST_FWD;
			ipodSetPlayStatus();
		}

		if (ipodCommandFlags & IPOD_CMD_FAST_STOP)
		{
			ipodPrepareMessage(IPOD_CMD_FAST_STOP);

			ipodInfoPlayStatus = ipodInfoPlayStatusOld;
			ipodSetPlayStatus();
		}

		if (ipodCommandFlags & IPOD_CMD_START_POLL)
		{
//			ipodPrepareMessage(IPOD_CMD_START_POLL);
		}

		if (ipodCommandFlags & IPOD_CMD_STOP_POLL)
		{
//			ipodPrepareMessage(IPOD_CMD_STOP_POLL);
		}

		if (ipodCommandFlags & IPOD_CMD_GET_SHUFFLE_MODE)
		{
			ipodPrepareMessage(IPOD_CMD_GET_SHUFFLE_MODE);
		}

		if (ipodCommandFlags & IPOD_CMD_SET_SHUFFLE_MODE)
		{
			ipodPrepareMessage(IPOD_CMD_SET_SHUFFLE_MODE);
			ipodPrepareMessage(IPOD_CMD_GET_SHUFFLE_MODE);
		}

		if (ipodCommandFlags & IPOD_CMD_GET_BASIC_INFO)
		{
			ipodPrepareMessage(IPOD_CMD_GET_TIME_AND_PLAY_STATUS);
			ipodPrepareMessage(IPOD_CMD_GET_CUR_NR_PLAYLIST);
			ipodPrepareMessage(IPOD_CMD_GET_TOT_NR_PLAYLIST);
		}

		if (ipodCommandFlags & IPOD_CMD_GET_STRING_INFO)
		{
//			ipodPrepareMessage(IPOD_CMD_GET_TIME_AND_PLAY_STATUS);
//			ipodPrepareMessage(IPOD_CMD_GET_CUR_NR_PLAYLIST);
//			ipodPrepareMessage(IPOD_CMD_GET_TOT_NR_PLAYLIST);
			ipodPrepareMessage(IPOD_CMD_GET_SHUFFLE_MODE);
			ipodPrepareMessage(IPOD_CMD_GET_CUR_TITLE);
			ipodPrepareMessage(IPOD_CMD_GET_CUR_ARTIST);
			ipodPrepareMessage(IPOD_CMD_GET_CUR_ALBUM);

		}
	}

	// clear the flags
	ipodCommandFlags = IPOD_CMD_CLEAR;

	// send messages
	while (ipodTXActiveData != IPOD_EMPTY_TX_BUFFER)
	{
		ipodSendMessage();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// prepare one IPOD message
void ipodPrepareMessage(uint32_t ipodMessage)
{
	switch(ipodTXStatus)
	{
		case IPOD_TX_READY:
		{
			// change status: composing TX data
			ipodTXStatus = IPOD_TX_MSG_COMPOSING;

			// prepare buffer variables
			ipodTXActiveData &= ~(1<<ipodTXCurrentData);
			ipodTXDataCount[ipodTXCurrentData] = 0;

			uint16_t tempChecksum = 0x0000;

			// generate TX data
			if (ipodMessage & IPOD_CMD_DEF_REMOTE_MODE)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x00;
				ipodTXData[ipodTXCurrentData][4] = 0x01;
				ipodTXData[ipodTXCurrentData][5] = 0x02;
				ipodTXData[ipodTXCurrentData][6] = 0xFA;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}

			if (ipodMessage & IPOD_CMD_ADV_REMOTE_MODE)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x00;
				ipodTXData[ipodTXCurrentData][4] = 0x01;
				ipodTXData[ipodTXCurrentData][5] = 0x04;
				ipodTXData[ipodTXCurrentData][6] = 0xF8;

				ipodTXDataCount[ipodTXCurrentData] = 7;

				ipodLogoStatusFlags |= IPOD_STA_LOGO_SEND;
			}

			if (ipodMessage & IPOD_CMD_RELEASE_BTN)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x02;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x00;
				ipodTXData[ipodTXCurrentData][6] = 0xFB;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}

			if (ipodMessage & IPOD_CMD_ON)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x05;
				ipodTXData[ipodTXCurrentData][3] = 0x02;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x00;
				ipodTXData[ipodTXCurrentData][6] = 0x00;
				ipodTXData[ipodTXCurrentData][7] = 0x08;
				ipodTXData[ipodTXCurrentData][8] = 0xF1;

				ipodTXDataCount[ipodTXCurrentData] = 9;
			}

			if (ipodMessage & IPOD_CMD_OFF)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x05;
				ipodTXData[ipodTXCurrentData][3] = 0x02;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x00;
				ipodTXData[ipodTXCurrentData][6] = 0x00;
				ipodTXData[ipodTXCurrentData][7] = 0x04;
				ipodTXData[ipodTXCurrentData][8] = 0xF5;

				ipodTXDataCount[ipodTXCurrentData] = 9;
			}

			if (ipodMessage & IPOD_CMD_PLAY)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x01;
				ipodTXData[ipodTXCurrentData][7] = 0xCE;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_PAUSE)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x01;
				ipodTXData[ipodTXCurrentData][7] = 0xCE;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_STOP)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x02;
				ipodTXData[ipodTXCurrentData][7] = 0xCD;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_SKIP_REV_1ALB)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x02;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x40;
				ipodTXData[ipodTXCurrentData][6] = 0xBB;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}

			if (ipodMessage & IPOD_CMD_SKIP_FWD_1ALB)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x02;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x20;
				ipodTXData[ipodTXCurrentData][6] = 0xDB;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}

			if (ipodMessage & IPOD_CMD_SKIP_REV)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x04;
				ipodTXData[ipodTXCurrentData][7] = 0xCB;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_SKIP_FWD)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x03;
				ipodTXData[ipodTXCurrentData][7] = 0xCC;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_FAST_REV)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x06;
				ipodTXData[ipodTXCurrentData][7] = 0xC9;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_FAST_FWD)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x05;
				ipodTXData[ipodTXCurrentData][7] = 0xCA;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_FAST_STOP)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x29;
				ipodTXData[ipodTXCurrentData][6] = 0x07;
				ipodTXData[ipodTXCurrentData][7] = 0xC8;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_GET_TIME_AND_PLAY_STATUS)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x1C;
				ipodTXData[ipodTXCurrentData][6] = 0xDD;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}
			
			if (ipodMessage & IPOD_CMD_GET_CUR_NR_PLAYLIST)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x1E;
				ipodTXData[ipodTXCurrentData][6] = 0xDB;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}
			
			if (ipodMessage & IPOD_CMD_GET_TOT_NR_PLAYLIST)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x35;
				ipodTXData[ipodTXCurrentData][6] = 0xC4;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}
			
			if (ipodMessage & IPOD_CMD_GET_CUR_TITLE)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x07;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x20;
				ipodTXData[ipodTXCurrentData][6] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 24);
				ipodTXData[ipodTXCurrentData][7] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 16);
				ipodTXData[ipodTXCurrentData][8] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 8);
				ipodTXData[ipodTXCurrentData][9] = (uint8_t)(ipodInfoTracksCurrent - 1);

				tempChecksum = (0x0100 - (0x00FF & (0x2B + ipodTXData[ipodTXCurrentData][6] + ipodTXData[ipodTXCurrentData][7] + ipodTXData[ipodTXCurrentData][8] + ipodTXData[ipodTXCurrentData][9])));
				ipodTXData[ipodTXCurrentData][10] = (uint8_t)tempChecksum;

				ipodTXDataCount[ipodTXCurrentData] = 11;
			}
			
			if (ipodMessage & IPOD_CMD_GET_CUR_ARTIST)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x07;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x22;
				ipodTXData[ipodTXCurrentData][6] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 24);
				ipodTXData[ipodTXCurrentData][7] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 16);
				ipodTXData[ipodTXCurrentData][8] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 8);
				ipodTXData[ipodTXCurrentData][9] = (uint8_t)(ipodInfoTracksCurrent - 1);

				tempChecksum = (0x0100 - (0x00FF & (0x2D + ipodTXData[ipodTXCurrentData][6] + ipodTXData[ipodTXCurrentData][7] + ipodTXData[ipodTXCurrentData][8] + ipodTXData[ipodTXCurrentData][9])));
				ipodTXData[ipodTXCurrentData][10] = (uint8_t)tempChecksum;

				ipodTXDataCount[ipodTXCurrentData] = 11;
			}
			
			if (ipodMessage & IPOD_CMD_GET_CUR_ALBUM)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x07;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x24;
				ipodTXData[ipodTXCurrentData][6] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 24);
				ipodTXData[ipodTXCurrentData][7] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 16);
				ipodTXData[ipodTXCurrentData][8] = (uint8_t)((ipodInfoTracksCurrent - 1) >> 8);
				ipodTXData[ipodTXCurrentData][9] = (uint8_t)(ipodInfoTracksCurrent - 1);

				tempChecksum = (0x0100 - (0x00FF & (0x2F + ipodTXData[ipodTXCurrentData][6] + ipodTXData[ipodTXCurrentData][7] + ipodTXData[ipodTXCurrentData][8] + ipodTXData[ipodTXCurrentData][9])));
				ipodTXData[ipodTXCurrentData][10] = (uint8_t)tempChecksum;

				ipodTXDataCount[ipodTXCurrentData] = 11;
			}

			if (ipodMessage & IPOD_CMD_START_POLL)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x26;
				ipodTXData[ipodTXCurrentData][6] = 0x01;
				ipodTXData[ipodTXCurrentData][7] = 0xD1;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_STOP_POLL)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x26;
				ipodTXData[ipodTXCurrentData][6] = 0x00;
				ipodTXData[ipodTXCurrentData][7] = 0xD2;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_GET_SHUFFLE_MODE)
			{
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x03;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x2C;
				ipodTXData[ipodTXCurrentData][6] = 0xCD;

				ipodTXDataCount[ipodTXCurrentData] = 7;
			}

			if (ipodMessage & IPOD_CMD_SET_SHUFFLE_MODE)
			{
				switch (ipodInfoShuffleStatus)
				{
					case IPOD_SHUFFLE_OFF:
					{
						// switch to track
						ipodTXData[ipodTXCurrentData][0] = 0xFF;
						ipodTXData[ipodTXCurrentData][1] = 0x55;
						ipodTXData[ipodTXCurrentData][2] = 0x04;
						ipodTXData[ipodTXCurrentData][3] = 0x04;
						ipodTXData[ipodTXCurrentData][4] = 0x00;
						ipodTXData[ipodTXCurrentData][5] = 0x2E;
						ipodTXData[ipodTXCurrentData][6] = 0x01;
						ipodTXData[ipodTXCurrentData][7] = 0xC9;

						break;
					}
					case IPOD_SHUFFLE_TRACK:
					{
						// switch to album
						ipodTXData[ipodTXCurrentData][0] = 0xFF;
						ipodTXData[ipodTXCurrentData][1] = 0x55;
						ipodTXData[ipodTXCurrentData][2] = 0x04;
						ipodTXData[ipodTXCurrentData][3] = 0x04;
						ipodTXData[ipodTXCurrentData][4] = 0x00;
						ipodTXData[ipodTXCurrentData][5] = 0x2E;
						ipodTXData[ipodTXCurrentData][6] = 0x02;
						ipodTXData[ipodTXCurrentData][7] = 0xC8;

						break;
					}
					case IPOD_SHUFFLE_ALBUM:
					{
						// switch to off
						ipodTXData[ipodTXCurrentData][0] = 0xFF;
						ipodTXData[ipodTXCurrentData][1] = 0x55;
						ipodTXData[ipodTXCurrentData][2] = 0x04;
						ipodTXData[ipodTXCurrentData][3] = 0x04;
						ipodTXData[ipodTXCurrentData][4] = 0x00;
						ipodTXData[ipodTXCurrentData][5] = 0x2E;
						ipodTXData[ipodTXCurrentData][6] = 0x00;
						ipodTXData[ipodTXCurrentData][7] = 0xCA;

						break;
					}
				}
				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			if (ipodMessage & IPOD_CMD_SET_REPEAT_MODE)
			{
				// repeat all
				ipodTXData[ipodTXCurrentData][0] = 0xFF;
				ipodTXData[ipodTXCurrentData][1] = 0x55;
				ipodTXData[ipodTXCurrentData][2] = 0x04;
				ipodTXData[ipodTXCurrentData][3] = 0x04;
				ipodTXData[ipodTXCurrentData][4] = 0x00;
				ipodTXData[ipodTXCurrentData][5] = 0x31;
				ipodTXData[ipodTXCurrentData][6] = 0x02;
				ipodTXData[ipodTXCurrentData][7] = 0xC5;

				ipodTXDataCount[ipodTXCurrentData] = 8;
			}

			// set current data active data					
			ipodTXActiveData |= (1<<ipodTXCurrentData);

			// next buffer to use
			ipodTXCurrentData = (ipodTXCurrentData + 1) % IPOD_TX_DATA_BUFFERS;

			// change status: complete
			ipodTXStatus = IPOD_TX_MSG_COMPLETE;

			if (ipodTXActiveData != IPOD_FULL_TX_BUFFER)
			{
				ipodTXStatus = IPOD_TX_READY;
			}
			else
			{
				ipodTXStatus = IPOD_TX_BUFFERS_FULL;
			}

			break;
		}

		case IPOD_TX_MSG_COMPOSING:		// should not come here
		case IPOD_TX_MSG_COMPLETE:		// should not come here
		case IPOD_TX_BUFFERS_FULL:
		{
			// messages need to be sent first
			break;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send one IPOD message
void ipodSendMessage(void)
{
	// if we've got data in the TX buffer
	if (ipodTXActiveData != IPOD_EMPTY_TX_BUFFER)
	{
		// init send
		// delay for new message
		_delay_ms(IPOD_MSG_PRE_DELAY);

		// actual data send
		uint8_t i;
		for (i = 0; i < ipodTXDataCount[ipodProcTXData]; i++)
		{
			// wait for empty TX-buffer
			while(!(IPOD_UART_UCSRA & _BV(IPOD_UART_UDRE)))
			{
				;
			}

			IPOD_UART_UDR = ipodTXData[ipodProcTXData][i];

			// increment total TX bytes
			ipodTXTotalBytes++;
		}

		// wait for empty TX-buffer
		while(!(IPOD_UART_UCSRA & _BV(IPOD_UART_UDRE)))
		{
			;
		}

		// wait for complete data TX
		_delay_ms(IPOD_MSG_POST_DELAY);

		// clear the processed buffer bit
		ipodTXActiveData &= ~(1<<ipodProcTXData);

		// next buffers to use
		ipodProcTXData = (ipodProcTXData + 1) % IPOD_TX_DATA_BUFFERS;

		// if we had a full buffer
		if (ipodTXActiveData != IPOD_FULL_TX_BUFFER)
		{
			if (ipodTXStatus == IPOD_TX_BUFFERS_FULL)
			{
				ipodTXStatus = IPOD_TX_READY;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return string pointers
char (*ipodGetPointer_strArtist(void))[IPOD_STRLEN_ARTIST]
{
	return &ipodStrArtist;
}

char (*ipodGetPointer_strAlbum(void))[IPOD_STRLEN_ALBUM]
{
	return &ipodStrAlbum;
}

char (*ipodGetPointer_strTrack(void))[IPOD_STRLEN_TRACK]
{
	return &ipodStrTrack;
}

char (*ipodGetPointer_strTrackNrCur(void))[IPOD_STRLEN_TRACKNR_CUR]
{
	return &ipodStrTrackNrCur;
}

char (*ipodGetPointer_strTrackNrTot(void))[IPOD_STRLEN_TRACKNR_TOT]
{
	return &ipodStrTrackNrTot;
}

char (*ipodGetPointer_strTimePlayed(void))[IPOD_STRLEN_TIME_PLAYED]
{
	return &ipodStrTimePlayed;
}

char (*ipodGetPointer_strTimeRemain(void))[IPOD_STRLEN_TIME_REMAIN]
{
	return &ipodStrTimeRemain;
}

char (*ipodGetPointer_strTimeTotal(void))[IPOD_STRLEN_TIME_TOTAL]
{
	return &ipodStrTimeTotal;
}

char (*ipodGetPointer_strPlayStatus(void))[IPOD_STRLEN_PLAY_STATUS]
{
	return &ipodStrPlayStatus;
}

uint32_t ipodGetTimePlayed(void)
{
	return ipodInfoTimePlayed;
}

uint32_t ipodGetInfoTracksCurrent(void)
{
	return ipodInfoTracksCurrent;
}

// send one byte
void ipodSendByte(uint8_t txData)
{
	// wait for empty TX-buffer
	while(!(IPOD_UART_UCSRA & _BV(IPOD_UART_UDRE)))
	{
		;
	}

	// send byte
	IPOD_UART_UDR = txData;

	// increment total TX bytes
	ipodTXTotalBytes++;

	// wait for empty TX-buffer
	while(!(IPOD_UART_UCSRA & _BV(IPOD_UART_UDRE)))
	{
		;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send logo data
void ipodSendLogo(void)
{
	uint8_t intBlock = 0;

	uint8_t i = 0;
	uint8_t j = 0;
	uint8_t k = 0;

	uint8_t tempCheckSum = 0;
	uint8_t tempByte = 0;

	for (intBlock = 0; intBlock < ((IPOD_LOGO_HEIGHT - 1) / IPOD_LOGO_SENT_LINES_PER_BLOCK) + 1; intBlock++)
	{
		if (intBlock == 0)
		{
			// send first block
			ipodSendByte(0xFF);										// header
			ipodSendByte(0x55);

			ipodSendByte(14 + (IPOD_LOGO_SENT_LINES_PER_BLOCK * IPOD_LOGO_SENT_BYTES_PER_LINE));	// length
			tempCheckSum = 14 + (IPOD_LOGO_SENT_LINES_PER_BLOCK * IPOD_LOGO_SENT_BYTES_PER_LINE);

			ipodSendByte(0x04);										// mode
			tempCheckSum += 0x04;

			ipodSendByte(0x00);										// cmd
			ipodSendByte(0x32);
			tempCheckSum += 0x32;

			ipodSendByte(0x00);										// first block
			ipodSendByte(intBlock);
			tempCheckSum += intBlock;

			ipodSendByte(0x01);										// always 0x01, only first block
			tempCheckSum += 0x01;

			ipodSendByte(0x00);										// width
			ipodSendByte(IPOD_LOGO_WIDTH);
			tempCheckSum += IPOD_LOGO_WIDTH;

			ipodSendByte(0x00);										// height
			ipodSendByte(IPOD_LOGO_HEIGHT);
			tempCheckSum += IPOD_LOGO_HEIGHT;

			ipodSendByte(0x00);										// number of bytes sent per line
			ipodSendByte(0x00);
			ipodSendByte(0x00);
			ipodSendByte(IPOD_LOGO_SENT_BYTES_PER_LINE);
			tempCheckSum += IPOD_LOGO_SENT_BYTES_PER_LINE;

			// actual data: IPOD_LOGO_SENT_LINES_PER_BLOCK x IPOD_LOGO_SENT_BYTES_PER_LINE
			for (i = 0; i < IPOD_LOGO_SENT_LINES_PER_BLOCK; i++)
			{
				for (j = 0; j < IPOD_LOGO_SENT_BYTES_PER_LINE; j++)
				{
					tempByte = pgm_read_byte_near(aIpodImage + (i * IPOD_LOGO_SENT_BYTES_PER_LINE) + j);
					ipodSendByte(tempByte);
					tempCheckSum += tempByte;
				}
			}

			// checksum
			tempCheckSum = ((0x0100 - (uint16_t)tempCheckSum) & 0x00FF);
			ipodSendByte(tempCheckSum);
		}
		else
		{
			// otherwise: send normal block
			ipodSendByte(0xFF);										// header
			ipodSendByte(0x55);

			k = IPOD_LOGO_HEIGHT - (IPOD_LOGO_SENT_LINES_PER_BLOCK * intBlock);
			if (k > IPOD_LOGO_SENT_LINES_PER_BLOCK)
			{
				k = IPOD_LOGO_SENT_LINES_PER_BLOCK;
			}

			ipodSendByte(5 + (k * IPOD_LOGO_SENT_BYTES_PER_LINE));	// length
			tempCheckSum = 5 + (k * IPOD_LOGO_SENT_BYTES_PER_LINE);

			ipodSendByte(0x04);										// mode
			tempCheckSum += 0x04;

			ipodSendByte(0x00);										// cmd
			ipodSendByte(0x32);
			tempCheckSum += 0x32;

			ipodSendByte(0x00);										// normal block
			ipodSendByte(intBlock);
			tempCheckSum += intBlock;

			// actual data: k x IPOD_LOGO_SENT_BYTES_PER_LINE
			for (i = 0; i < k; i++)
			{
				for (j = 0; j < IPOD_LOGO_SENT_BYTES_PER_LINE; j++)
				{
					tempByte = pgm_read_byte_near(aIpodImage + (((intBlock * IPOD_LOGO_SENT_LINES_PER_BLOCK) + i) * IPOD_LOGO_SENT_BYTES_PER_LINE) + j);
					ipodSendByte(tempByte);
					tempCheckSum += tempByte;
				}
			}

			// checksum
			tempCheckSum = ((0x0100 - (uint16_t)tempCheckSum) & 0x00FF);
			ipodSendByte(tempCheckSum);
		}
	}

	ipodLogoStatusFlags &= ~IPOD_STA_LOGO_SEND;
}
