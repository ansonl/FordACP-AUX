/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"
#include "spiComm.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// ipod UART on microcontroller
#define IPOD_UART_RECV			SIG_USART1_RECV		// interrupt for receiving data on UART
#define IPOD_UART_UCSRA			UCSR1A				// UART control and status register A
#define IPOD_UART_UCSRB			UCSR1B				// UART control and status register B
#define IPOD_UART_UCSRC			UCSR1C				// UART control and status register C
#define IPOD_UART_UDR			UDR1				// UART data register
#define IPOD_UART_FE			FE1					// UART frame error
#define IPOD_UART_DOR			DOR1				// UART data overrun
#define IPOD_UART_PE			UPE1				// UART parity error
#define IPOD_UART_UBRRH			UBRR1H				// UART baud rate register H
#define IPOD_UART_UBRRL			UBRR1L				// UART baud rate register L
#define IPOD_UART_RXCIE			RXCIE1				// UART RX complete interrupt
#define IPOD_UART_RXEN			RXEN1				// UART RX enable
#define IPOD_UART_TXEN			TXEN1				// UART TX enable
#define IPOD_UART_UCSZ0			UCSZ10				// UART character size 0
#define IPOD_UART_UCSZ1			UCSZ11				// UART character size 1
#define IPOD_UART_UCSZ2			UCSZ12				// UART character size 2
#define IPOD_UART_URSEL			URSEL1				// UART register select
#define IPOD_UART_UDRE			UDRE1				// UART data register empty
#define IPOD_UART_RXB8			RXB81				// UART ninth bit RX
#define IPOD_UART_TXB8			TXB81				// UART ninth bit TX
#define IPOD_UART_TXC			TXC1				// UART TX complete

// ipod port and pins on microcontroller
#define IPOD_PORT				PORTB				// ipod port
#define IPOD_RX_PIN				2					// UART RX pin
#define IPOD_TX_PIN				3					// UART TX pin

// IPOD baud rate: 19200 bps (asynchronous normal mode)
#define IPOD_UART_BAUD_RATE		19200
#define IPOD_UART_BAUD_SELECT	((uint32_t)((uint32_t)F_CPU/(IPOD_UART_BAUD_RATE*16L)-1))

// status of the IPOD communication
#define IPOD_RX_READY				0
#define IPOD_RX_RECEIVING			1
#define IPOD_RX_MSG_COMPLETE		2
#define IPOD_RX_BUFFERS_FULL		3

#define IPOD_RX_STA_CLEAR				0
#define IPOD_RX_STA_EXPECT_START1		1
#define IPOD_RX_STA_EXPECT_START2		2
#define IPOD_RX_STA_EXPECT_LENGTH		3
#define IPOD_RX_STA_EXPECT_MODE			4
#define IPOD_RX_STA_EXPECT_CMD1			5
#define IPOD_RX_STA_EXPECT_CMD2			6
#define IPOD_RX_STA_EXPECT_DATA_SIMPLE	7
#define IPOD_RX_STA_EXPECT_DATA_STRING	8
#define IPOD_RX_STA_EXPECT_CHECKSUM		9

#define IPOD_TX_READY				0
#define IPOD_TX_MSG_COMPOSING		1
#define IPOD_TX_MSG_COMPLETE		2
#define IPOD_TX_BUFFERS_FULL		3

// IPOD timings
#define IPOD_MSG_PRE_DELAY		10			// delay in ms before message
#define IPOD_MSG_POST_DELAY		10			// delay in ms after message

// number of data buffers for RX and TX
#define IPOD_RX_DATA_BUFFERS	8
#define IPOD_TX_DATA_BUFFERS	16
#define IPOD_EMPTY_RX_BUFFER	0x0000
#define IPOD_EMPTY_TX_BUFFER	0x0000
#define IPOD_FULL_RX_BUFFER		0x00FF
#define IPOD_FULL_TX_BUFFER		0xFFFF

#define IPOD_MSG_START1				0xFF		// 1st msg byte
#define IPOD_MSG_START2				0x55		// 2nd msg byte

// max. length of an IPOD RX and TX message
#define IPOD_RX_MAX_MSG_LENGTH		0xF0		// maximum length of message
#define IPOD_RX_MAX_MSG_LENGTH_BUF	20			// RX buffer length
#define IPOD_TX_MAX_MSG_LENGTH_BUF	11			// TX buffer length

// IPOD status flags
#define IPOD_STA_CLEAR			0x00
#define IPOD_STA_ON				_BV(0)
#define IPOD_STA_PLAYING		_BV(1)
#define IPOD_STA_SEEKING		_BV(2)
#define IPOD_STA_PP_TOGGLE		_BV(3)	// switched play/pause via toggle

// IPOD command flags
#define IPOD_CMD_CLEAR						0x00000000
#define IPOD_CMD_DEF_REMOTE_MODE			0x00000001
#define IPOD_CMD_ADV_REMOTE_MODE			0x00000002
#define IPOD_CMD_RELEASE_BTN				0x00000004
#define IPOD_CMD_ON							0x00000008
#define IPOD_CMD_OFF						0x00000010
#define IPOD_CMD_PLAY						0x00000020
#define IPOD_CMD_PAUSE						0x00000040
#define IPOD_CMD_STOP						0x00000080
#define IPOD_CMD_SKIP_REV_3ALB				0x00000100
#define IPOD_CMD_SKIP_FWD_3ALB				0x00000200
#define IPOD_CMD_SKIP_REV_1ALB				0x00000400
#define IPOD_CMD_SKIP_FWD_1ALB				0x00000800
#define IPOD_CMD_SKIP_ALB_PREPARE			0x00001000
#define IPOD_CMD_SKIP_ALB_FINISH			0x00002000
#define IPOD_CMD_SKIP_REV					0x00004000
#define IPOD_CMD_SKIP_FWD					0x00008000
#define IPOD_CMD_FAST_REV					0x00010000
#define IPOD_CMD_FAST_FWD					0x00020000
#define IPOD_CMD_FAST_STOP					0x00040000
#define IPOD_CMD_GET_TIME_AND_PLAY_STATUS	0x00080000
#define IPOD_CMD_GET_CUR_NR_PLAYLIST		0x00100000
#define IPOD_CMD_GET_TOT_NR_PLAYLIST		0x00200000
#define IPOD_CMD_GET_CUR_TITLE				0x00400000
#define IPOD_CMD_GET_CUR_ARTIST				0x00800000
#define IPOD_CMD_GET_CUR_ALBUM				0x01000000
#define IPOD_CMD_START_POLL					0x02000000
#define IPOD_CMD_STOP_POLL					0x04000000
#define IPOD_CMD_GET_BASIC_INFO				0x08000000
#define IPOD_CMD_GET_STRING_INFO			0x10000000
#define IPOD_CMD_GET_SHUFFLE_MODE			0x20000000
#define IPOD_CMD_SET_SHUFFLE_MODE			0x40000000
#define IPOD_CMD_SET_REPEAT_MODE			0x80000000

// IPOD play info
#define IPOD_STOP					0x00
#define IPOD_PLAY					0x01
#define IPOD_PAUSE					0x02
#define IPOD_FAST_REV				0x03
#define IPOD_FAST_FWD				0x04
#define IPOD_SHUFFLE_OFF			0x00
#define IPOD_SHUFFLE_TRACK			0x01
#define IPOD_SHUFFLE_ALBUM			0x02
#define IPOD_SHUFFLE_UNKNOWN		0xFF
#define IPOD_REPEAT_OFF				0x00
#define IPOD_REPEAT_TRACK			0x01
#define IPOD_REPEAT_ALL				0x02
#define IPOD_REPEAT_UNKNOWN			0xFF

// IPOD strings - max lengths
#define IPOD_STRLEN_ARTIST			49		// 48 bytes + \0
#define IPOD_STRLEN_ALBUM			49		// 48 bytes + \0
#define IPOD_STRLEN_TRACK			49		// 48 bytes + \0
#define IPOD_STRLEN_GENRE			33		// 32 bytes + \0
#define IPOD_STRLEN_TRACKNR_CUR		5		// 4 bytes + \0
#define IPOD_STRLEN_TRACKNR_TOT		5		// 4 bytes + \0
#define IPOD_STRLEN_TIME_PLAYED		7		// 6 bytes + \0
#define IPOD_STRLEN_TIME_REMAIN		7		// 6 bytes + \0
#define IPOD_STRLEN_TIME_TOTAL		7		// 6 bytes + \0
#define IPOD_STRLEN_PLAY_STATUS		1

// IPOD strings - status flags
#define IPOD_STA_STR_NONE				0x0000
#define IPOD_STA_STR_ARTIST				0x0001
#define IPOD_STA_STR_ALBUM				0x0002
#define IPOD_STA_STR_TRACK				0x0004
#define IPOD_STA_STR_GENRE				0x0008
#define IPOD_STA_STR_TRACKNR_CUR		0x0010
#define IPOD_STA_STR_TRACKNR_TOT		0x0020
#define IPOD_STA_STR_TIME_PLAYED		0x0040
#define IPOD_STA_STR_TIME_REMAIN		0x0080
#define IPOD_STA_STR_TIME_TOTAL			0x0100
#define IPOD_STA_STR_PLAY_STATUS		0x0200

// IPOD logo; only tested with these values
#define IPOD_LOGO_WIDTH					128		// < 0xFF
#define IPOD_LOGO_HEIGHT				76		// < 0xFF
#define IPOD_LOGO_BPP					2
#define IPOD_LOGO_SENT_BYTES_PER_LINE	32		// < 0xFF; IPOD_LOGO_WIDTH / (8 / IPOD_LOGO_BPP)
#define IPOD_LOGO_SENT_LINES_PER_BLOCK	3		// we send 3 lines per block

#define IPOD_STA_LOGO_CLEAR				0x00
#define IPOD_STA_LOGO_SEND				0x01

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

void ipodUartInit(void);
void ipodResetRXStatus(void);
void ipodResetTXStatus(void);
void ipodResetRXData(void);
void ipodResetTXData(void);
void ipodResetProcData(void);
void ipodInit(void);

void ipodProcessReceivedData(uint8_t);
void ipodProcessReceivedMessages(void);

uint8_t ipodGetTotalRXBytes(void);
uint8_t ipodGetTotalTXBytes(void);

void ipodSetStatusFlags(uint8_t);
uint8_t ipodGetStatusFlags(void);
uint8_t ipodGetLogoStatusFlags(void);
void ipodSetLogoStatusFlags(uint8_t);
void ipodSetCommandFlags(uint32_t);
uint32_t ipodGetCommandFlags(void);
uint16_t ipodGetStringFlags(void);
void ipodSetStringFlags(uint16_t);
void ipodSetPlayStatus(void);

void ipodSendCommands(void);
void ipodPrepareMessage(uint32_t);
void ipodSendMessage(void);

char (*ipodGetPointer_strArtist(void))[IPOD_STRLEN_ARTIST];
char (*ipodGetPointer_strAlbum(void))[IPOD_STRLEN_ALBUM];
char (*ipodGetPointer_strTrack(void))[IPOD_STRLEN_TRACK];
char (*ipodGetPointer_strTrackNrCur(void))[IPOD_STRLEN_TRACKNR_CUR];
char (*ipodGetPointer_strTrackNrTot(void))[IPOD_STRLEN_TRACKNR_TOT];
char (*ipodGetPointer_strTimePlayed(void))[IPOD_STRLEN_TIME_PLAYED];
char (*ipodGetPointer_strTimeRemain(void))[IPOD_STRLEN_TIME_REMAIN];
char (*ipodGetPointer_strTimeTotal(void))[IPOD_STRLEN_TIME_TOTAL];
char (*ipodGetPointer_strPlayStatus(void))[IPOD_STRLEN_PLAY_STATUS];

uint32_t ipodGetTimePlayed(void);
uint32_t ipodGetInfoTracksCurrent(void);

void ipodSendLogo(void);
