/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "prjAcpIpod.h"

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// main initialization
void mainInit(void)
{
	// I/O init (LED's and DIP's)

	// configure DIP-pins as input
	DDR(DIP_DATA0_PORT) &= ~_BV(DIP_DATA0_PIN);
	DDR(DIP_DATA1_PORT) &= ~_BV(DIP_DATA1_PIN);
	DDR(DIP_DATA2_PORT) &= ~_BV(DIP_DATA2_PIN);
	DDR(DIP_DATA3_PORT) &= ~_BV(DIP_DATA3_PIN);

	// pull inputs high when not connected
	DIP_DATA0_PORT |= _BV(DIP_DATA0_PIN);
	DIP_DATA1_PORT |= _BV(DIP_DATA1_PIN);
	DIP_DATA2_PORT |= _BV(DIP_DATA2_PIN);
	DIP_DATA3_PORT |= _BV(DIP_DATA3_PIN);

	// configure LED-pins as output
	DDR(LED_DATA0_PORT) |= _BV(LED_DATA0_PIN);
	DDR(LED_DATA1_PORT) |= _BV(LED_DATA1_PIN);
	DDR(LED_DATA2_PORT) |= _BV(LED_DATA2_PIN);
	DDR(LED_DATA3_PORT) |= _BV(LED_DATA3_PIN);

	// defaults
	statusLeds = STA_CLEAR_ALL;
	statusDips = SW_CLEAR_ALL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset slave
void resetSlave(void)
{
	// reset slave
	DDR(SLAVE_RESET_PORT) |= _BV(SLAVE_RESET_PIN);
	SLAVE_RESET_PORT &= ~_BV(SLAVE_RESET_PIN);
	_delay_us(10);
	SLAVE_RESET_PORT |= _BV(SLAVE_RESET_PIN);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// read DIP-switches
void readDips(void)
{
	statusDips = SW_SET_ALL;

	// read values
    if ( PIN(DIP_DATA0_PORT) & _BV(DIP_DATA0_PIN) )
	{
		statusDips &= ~(1 << SW_PLAYER_TYPE_BIT0);
	}

    if ( PIN(DIP_DATA1_PORT) & _BV(DIP_DATA1_PIN) )
	{
		statusDips &= ~(1 << SW_PLAYER_TYPE_BIT1);
	}

    if ( PIN(DIP_DATA2_PORT) & _BV(DIP_DATA2_PIN) )
	{
		statusDips &= ~(1 << SW_LCD_ON_BIT0);
	}

    if ( PIN(DIP_DATA3_PORT) & _BV(DIP_DATA3_PIN) )
	{
		statusDips &= ~(1 << SW_DEBUG_ON_BIT0);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write status LED's
void writeLeds(void)
{
   	if ( statusLeds & (_BV(STA_INIT_BIT0)) )
	{
		LED_DATA0_PORT |= _BV(LED_DATA0_PIN);
	}
	else
	{
		LED_DATA0_PORT &= ~_BV(LED_DATA0_PIN);
	}

   	if ( statusLeds & (_BV(STA_INIT_BIT1)) )
	{
		LED_DATA1_PORT |= _BV(LED_DATA1_PIN);
	}
	else
	{
		LED_DATA1_PORT &= ~_BV(LED_DATA1_PIN);
	}

   	if ( statusLeds & (_BV(STA_TXRX_HU_BIT0)) )
	{
		LED_DATA2_PORT |= _BV(LED_DATA2_PIN);
	}
	else
	{
		LED_DATA2_PORT &= ~_BV(LED_DATA2_PIN);
	}

   	if ( statusLeds & (_BV(STA_TXRX_PLAYER_BIT0)) )
	{
		LED_DATA3_PORT |= _BV(LED_DATA3_PIN);
	}
	else
	{
		LED_DATA3_PORT &= ~_BV(LED_DATA3_PIN);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// update display info
void updateDisplayInfo(void)
{
	// get flags
	uint16_t ipodStringFlags = ipodGetStringFlags();

	if (ipodStringFlags & IPOD_STA_STR_ARTIST)
	{
		SPI_sendString(SPI_MSG_ARTIST, *ipodGetPointer_strArtist(), IPOD_STRLEN_ARTIST);
	}

	if (ipodStringFlags & IPOD_STA_STR_ALBUM)
	{
		SPI_sendString(SPI_MSG_ALBUM, *ipodGetPointer_strAlbum(), IPOD_STRLEN_ALBUM);
	}

	if (ipodStringFlags & IPOD_STA_STR_TRACK)
	{
		SPI_sendString(SPI_MSG_TRACKNAME, *ipodGetPointer_strTrack(), IPOD_STRLEN_TRACK);
	}

	if (ipodStringFlags & IPOD_STA_STR_TRACKNR_CUR)
	{
		SPI_sendString(SPI_MSG_TRACKNR_CUR, *ipodGetPointer_strTrackNrCur(), IPOD_STRLEN_TRACKNR_CUR);
	}

	if (ipodStringFlags & IPOD_STA_STR_TRACKNR_TOT)
	{
		SPI_sendString(SPI_MSG_TRACKNR_TOT, *ipodGetPointer_strTrackNrTot(), IPOD_STRLEN_TRACKNR_TOT);
	}

	if (ipodStringFlags & IPOD_STA_STR_TIME_PLAYED)
	{
		SPI_sendString(SPI_MSG_TIME_PLAYED, *ipodGetPointer_strTimePlayed(), IPOD_STRLEN_TIME_PLAYED);

		uint32_t timePlayed = ipodGetTimePlayed();

		timePlayed /= 1000;
		if (timePlayed > 3599)
		{
			// do nothing
		}
		else
		{
			acpSetDiscInfo(0, 1, timePlayed / 60, timePlayed % 60);
		}
		acpSendDiscInfo();
	}

	if (ipodStringFlags & IPOD_STA_STR_TIME_REMAIN)
	{
		SPI_sendString(SPI_MSG_TIME_REMAIN, *ipodGetPointer_strTimeRemain(), IPOD_STRLEN_TIME_REMAIN);
	}

	if (ipodStringFlags & IPOD_STA_STR_TIME_TOTAL)
	{
		SPI_sendString(SPI_MSG_TIME_TOTAL, *ipodGetPointer_strTimeTotal(), IPOD_STRLEN_TIME_TOTAL);
	}

	if (ipodStringFlags & IPOD_STA_STR_PLAY_STATUS)
	{
		SPI_sendString(SPI_MSG_PLAY_STATUS, *ipodGetPointer_strPlayStatus(), IPOD_STRLEN_PLAY_STATUS);
	}

	// reset flags
	ipodSetStringFlags(IPOD_STA_STR_NONE);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// send initial play status
void sendInitialPlayStatus(void)
{
	char strPlayStatus[IPOD_STRLEN_PLAY_STATUS];
	strPlayStatus[0] = SPI_MSG_STA_STOP + SPI_MSG_STA_SHUFFLE_OFF;
	SPI_sendString(SPI_MSG_PLAY_STATUS, strPlayStatus, IPOD_STRLEN_PLAY_STATUS);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// main program
int main(void)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// general init
	////////////////////////////////////////////////////////////////////////////////////////////////

	// disable all interrupts
	cli();

	// declaration of variables
	// status switches
	uint8_t statusDipsOld = statusDips;
	uint8_t statusDipsNew = statusDips;
	// status leds
	uint8_t statusLedsOld = statusLeds;
	uint8_t statusLedsNew = statusLeds;

	// check counter flags
	uint8_t flTimer = 0;

	// ACP TX/RX bytes
	uint8_t acpTXBytesOld = 0;
	uint8_t acpTXBytesNew = 0;
	uint8_t acpRXBytesOld = 0;
	uint8_t acpRXBytesNew = 0;

	// delay after last RX of ACP-command (periods of 4 x 25ms)
	#define ACP_DELAY_LAST_RX			30		// 30 x (4 x 25ms)
	uint8_t acpDelayLastRX = 0;

	// ipod TX/RX bytes
	uint8_t ipodTXBytesOld = 0;
	uint8_t ipodTXBytesNew = 0;
	uint8_t ipodRXBytesOld = 0;
	uint8_t ipodRXBytesNew = 0;

	// info about skip of albums
	#define IPOD_STA_SKIP_NONE			0x00
	#define IPOD_STA_SKIP_REV_3ALB		0x10
	#define IPOD_STA_SKIP_REV_1ALB		0x20
	#define IPOD_STA_SKIP_FWD_1ALB		0x40
	#define IPOD_STA_SKIP_FWD_3ALB		0x80
	// first nibble contains info on REV/FWD/1ALB/3ALB; second nibble contains counter for delay
	uint8_t ipodStatusSkipAlbum = IPOD_STA_SKIP_NONE;

	// retrieve basic and full player info
	uint8_t ipodGetBasicInfo = 0;				// boolean
	uint8_t ipodGetStringInfo = 0;				// boolean
	uint32_t ipodTrackNr = 0xFFFFFFFF;

	// main init
	mainInit();

	// read DIP-switches
	readDips();

	// update status of DIP-switches
	statusDipsOld = statusDipsNew;
	statusDipsNew = statusDips;

	// update status of LED's
	statusLedsOld = statusLedsNew;
	statusLedsNew = statusLeds;

	// timer init
	tmrInitGeneralCounter();

	// SPI init
	SPI_init();

	//	statusLeds: 01: passed main init
	statusLeds = ((statusLeds & ~(1 << STA_INIT_BIT1 | 1 << STA_INIT_BIT0)) | (1 << STA_INIT_BIT0));
	writeLeds();

	// HU init
	acpInit();
	// disc: 0; track: 0; time: 0:00
	acpSetDiscInfo(0, 1, 0, 0);

	// statusLeds: 10: passed HU init
	statusLeds = ((statusLeds & ~(1 << STA_INIT_BIT1 | 1 << STA_INIT_BIT0)) | (1 << STA_INIT_BIT1));
	writeLeds();

	// PLAYER init
	ipodInit();

	// statusLeds: 11: passed PLAYER init
	statusLeds = ((statusLeds & ~(1 << STA_INIT_BIT1 | 1 << STA_INIT_BIT0)) | (1 << STA_INIT_BIT1 | 1 << STA_INIT_BIT0));
	writeLeds();

	// enable all interrupts
	sei();

	// start counter
	ENABLE_TIMER1A_INTERRUPT();

	////////////////////////////////////////////////////////////////////////////////////////////////
	// infinite loop
	////////////////////////////////////////////////////////////////////////////////////////////////

	while (1)
	{
		////////////////////////////////////////////////////////////////////////////////////////////////
		// changes in DIP-switches
		////////////////////////////////////////////////////////////////////////////////////////////////

		// read DIP-switches
		readDips();

		// update status of DIP-switches
		statusDipsOld = statusDipsNew;
		statusDipsNew = statusDips;

		// look if some dip switches have changed
		if (statusDipsNew != statusDipsOld)
		{
		}

		////////////////////////////////////////////////////////////////////////////////////////////////
		// changes with the counter
		////////////////////////////////////////////////////////////////////////////////////////////////

		// look if a counter has been reached
		flTimer = tmrReadGeneralCounterFlags();

#ifdef TMR_GENERAL_FL1	// 1 x 25ms
		if (flTimer & TMR_GENERAL_FL1)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL1);

			// update leds: TX or RX on HU
			if ((acpTXBytesOld == acpTXBytesNew) && (acpRXBytesOld == acpRXBytesNew))
			{
				// no TX or RX
				statusLeds &= ~_BV(STA_TXRX_HU_BIT0);
			}
			else
			{
				// TX or RX
				statusLeds |= _BV(STA_TXRX_HU_BIT0);
			}

			// update leds: TX or RX on ipod
			if ((ipodTXBytesOld == ipodTXBytesNew) && (ipodRXBytesOld == ipodRXBytesNew))
			{
				// no TX or RX
				statusLeds &= ~_BV(STA_TXRX_PLAYER_BIT0);
			}
			else
			{
				// TX or RX
				statusLeds |= _BV(STA_TXRX_PLAYER_BIT0);
			}
		}
#endif

#ifdef TMR_GENERAL_FL2	// 2 x 25ms
		if (flTimer & TMR_GENERAL_FL2)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL2);
		}
#endif

#ifdef TMR_GENERAL_FL3	// 4 x 25ms
		if (flTimer & TMR_GENERAL_FL3)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL3);

			// look if we received data or not (ACP)
			acpRXBytesOld = acpRXBytesNew;
			acpTXBytesOld = acpTXBytesNew;
			acpRXBytesNew = acpGetTotalRXBytes();
			acpTXBytesNew = acpGetTotalTXBytes();

			// look if we received data or not (ipod)
			ipodRXBytesOld = ipodRXBytesNew;
			ipodTXBytesOld = ipodTXBytesNew;
			ipodRXBytesNew = ipodGetTotalRXBytes();
			ipodTXBytesNew = ipodGetTotalTXBytes();

			// check ACP status
			uint8_t acpStatusFlags = acpGetStatusFlags();
			uint16_t acpPlayerCommands = acpGetCommandFlags();

			// check ipod status
			uint8_t ipodStatusFlags = ipodGetStatusFlags();
			uint32_t ipodCommands = ipodGetCommandFlags();

			// do ACP-stuff
			if (acpRXBytesOld == acpRXBytesNew)
			{
				// we received no new data

				// so we can transmit ACP commands
				// send ACP messages
				acpSendMessages();

				if (acpStatusFlags & ACP_STA_SENDDISCINFO)
				{
					// we need to send disc, track and time info
					acpSendDiscInfo();
					acpSetStatusFlags(acpStatusFlags &= ~ACP_STA_SENDDISCINFO);
				}

				// timout of ACP commands?
				if (ipodStatusFlags & IPOD_STA_ON)							// if ipod is on
				{
					acpDelayLastRX++;										// delay for last RX: increment
					if (acpDelayLastRX == ACP_DELAY_LAST_RX)				// if delay has been reached
					{
						ipodCommands |= (IPOD_CMD_OFF);						// default remote mode and turn off
						ipodStatusFlags = IPOD_STA_CLEAR;					// reset ipodStatusFlags
						sendInitialPlayStatus();							// send initial play status
					}
				}
			}
			else
			{
				// we did receive new data
				acpDelayLastRX = 0;											// delay for last RX: set to zero
				if (!(ipodStatusFlags & IPOD_STA_ON))						// if ipod is off
				{
					ipodCommands |= (IPOD_CMD_ON);							// advanced mode and turn on
					ipodStatusFlags = IPOD_STA_ON;							// set IPOD_STA_ON flag (only this flag)
					ipodGetBasicInfo = 1;
					ipodGetStringInfo = 1;
					resetSlave();
				}
			}

			// check if we need to send ipod-commands
			if (acpPlayerCommands != ACP_CMD_CLEAR)
			{
				if (acpPlayerCommands & ACP_CMD_PLAY)						// we got a play command
				{
					if (!(ipodStatusFlags & IPOD_STA_PLAYING))				// check if we're playing
					{
						if (!(ipodStatusFlags & IPOD_STA_PP_TOGGLE))		// check if we paused by the user
						{
							ipodCommands |= IPOD_CMD_PLAY;					// play
							ipodStatusFlags &= ~IPOD_STA_PP_TOGGLE;			// reset IPOD_STA_PP_TOGGLE flag
							ipodStatusFlags |= IPOD_STA_PLAYING;			// set IPOD_STA_PLAYING flag
						}
					}
				}

				if (acpPlayerCommands & ACP_CMD_PAUSE)						// we got a pause command
				{
					if (ipodStatusFlags & IPOD_STA_PLAYING)					// check if we're playing
					{
						ipodCommands |= IPOD_CMD_PAUSE;						// pause
						ipodStatusFlags &= ~IPOD_STA_PLAYING;				// reset IPOD_STA_PLAYING flag
					}
				}

				if (acpPlayerCommands & ACP_CMD_TOGGLE_PLAY)				// we got a toggle play command
				{
					if (ipodStatusFlags & IPOD_STA_PLAYING)					// check if we're playing
					{
						ipodCommands |= IPOD_CMD_PAUSE;						// pause
						ipodStatusFlags |= IPOD_STA_PP_TOGGLE;				// set IPOD_STA_PP_TOGGLE flag
						ipodStatusFlags &= ~IPOD_STA_PLAYING;				// reset IPOD_STA_PLAYING flag
					}
					else
					{
						ipodCommands |= IPOD_CMD_PLAY;						// play
						ipodStatusFlags &= ~IPOD_STA_PP_TOGGLE;				// reset IPOD_STA_PP_TOGGLE flag
						ipodStatusFlags |= IPOD_STA_PLAYING;				// set IPOD_STA_PLAYING flag
					}
					ipodGetStringInfo = 1;
				}

				if (acpPlayerCommands & ACP_CMD_TOGGLE_SHUFFLE)				// we got a toggle shuffle command
				{
					ipodCommands |= IPOD_CMD_SET_SHUFFLE_MODE;
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_REV_3ALB)				// we got a skip 3 albums rev command
				{
					if (ipodStatusSkipAlbum == IPOD_STA_SKIP_NONE)
					{
						ipodStatusSkipAlbum = IPOD_STA_SKIP_REV_3ALB;
						ipodCommands |= IPOD_CMD_SKIP_ALB_PREPARE;
					}
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_FWD_3ALB)				// we got a skip 3 album fwd command
				{
					if (ipodStatusSkipAlbum == IPOD_STA_SKIP_NONE)
					{
						ipodStatusSkipAlbum = IPOD_STA_SKIP_FWD_3ALB;
						ipodCommands |= IPOD_CMD_SKIP_ALB_PREPARE;
					}
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_REV_1ALB)				// we got a skip 1 album rev command
				{
					if (ipodStatusSkipAlbum == IPOD_STA_SKIP_NONE)
					{
						ipodStatusSkipAlbum = IPOD_STA_SKIP_REV_1ALB;
						ipodCommands |= IPOD_CMD_SKIP_ALB_PREPARE;
					}
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_FWD_1ALB)				// we got a skip 1 album fwd command
				{
					if (ipodStatusSkipAlbum == IPOD_STA_SKIP_NONE)
					{
						ipodStatusSkipAlbum = IPOD_STA_SKIP_FWD_1ALB;
						ipodCommands |= IPOD_CMD_SKIP_ALB_PREPARE;
					}
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_REV)					// we got a skip rev command
				{
					ipodCommands |= (IPOD_CMD_SKIP_REV);
				}

				if (acpPlayerCommands & ACP_CMD_SKIP_FWD)					// we got a skip fwd command
				{
					ipodCommands |= (IPOD_CMD_SKIP_FWD);
				}

				if (acpPlayerCommands & ACP_CMD_FAST_REV)					// we got a fast rev command
				{
					ipodCommands |= IPOD_CMD_FAST_REV;
					ipodStatusFlags |= IPOD_STA_SEEKING;					// set IPOD_STA_SEEKING flag
				}

				if (acpPlayerCommands & ACP_CMD_FAST_FWD)					// we got a fast fwd command
				{
					ipodCommands |= IPOD_CMD_FAST_FWD;
					ipodStatusFlags |= IPOD_STA_SEEKING;					// set IPOD_STA_SEEKING flag
				}
			}
			else
			{
				if (ipodStatusFlags & IPOD_STA_SEEKING)						// if we're currently seeking
				{
					if (!(acpStatusFlags & ACP_STA_SEEKING))
					{
						ipodCommands |= IPOD_CMD_FAST_STOP;					// release button
						ipodStatusFlags &= ~IPOD_STA_SEEKING;				// reset IPOD_STA_SEEKING flag
					}
				}

				if (ipodStatusSkipAlbum != IPOD_STA_SKIP_NONE)				// if we're currently in the operation of an album skip
				{
					if ((ipodStatusSkipAlbum & 0x0F) == 5)					// check delay counter
					{
						if ((ipodStatusSkipAlbum & 0xF0) & IPOD_STA_SKIP_REV_3ALB)
						{
							ipodCommands |= IPOD_CMD_SKIP_REV_3ALB;
						}

						if ((ipodStatusSkipAlbum & 0xF0) & IPOD_STA_SKIP_REV_1ALB)
						{
							ipodCommands |= IPOD_CMD_SKIP_REV_1ALB;
						}

						if ((ipodStatusSkipAlbum & 0xF0) & IPOD_STA_SKIP_FWD_1ALB)
						{
							ipodCommands |= IPOD_CMD_SKIP_FWD_1ALB;
						}

						if ((ipodStatusSkipAlbum & 0xF0) & IPOD_STA_SKIP_FWD_3ALB)
						{
							ipodCommands |= IPOD_CMD_SKIP_FWD_3ALB;
						}
					}

					if ((ipodStatusSkipAlbum & 0x0F) == 10)					// check delay counter
					{
						ipodCommands |= IPOD_CMD_SKIP_ALB_FINISH;
						ipodStatusSkipAlbum = IPOD_STA_SKIP_NONE;
					}

					if (ipodStatusSkipAlbum != IPOD_STA_SKIP_NONE)
					{
						ipodStatusSkipAlbum++;								// increase delay counter
					}
				}
			}

			if ((ipodStatusFlags & IPOD_STA_ON) && (ipodGetBasicInfo == 1))
			{
				ipodCommands |= IPOD_CMD_GET_BASIC_INFO;					// get basic player info
				ipodGetBasicInfo = 0;
			}

			if ((ipodStatusFlags & IPOD_STA_ON) && (ipodGetStringInfo == 1))
			{
				ipodCommands |= IPOD_CMD_GET_STRING_INFO;					// get string player info
				ipodGetStringInfo = 0;
			}

			// send data
			ipodSetCommandFlags(ipodCommands);
			ipodSendCommands();

			// update flags and commands
			ipodSetStatusFlags(ipodStatusFlags);							// apply status flags

			if (ipodGetLogoStatusFlags() == IPOD_STA_LOGO_SEND)
			{
				ipodSendLogo();												// send logo; flag is cleared here
			}

			if (ipodTrackNr != ipodGetInfoTracksCurrent())					// if track number changed: retrieve full info
			{
				ipodTrackNr = ipodGetInfoTracksCurrent();
				ipodGetStringInfo = 1;
			}
		}
#endif

#ifdef TMR_GENERAL_FL4	// 8 x 25ms
		if (flTimer & TMR_GENERAL_FL4)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL4);

			ipodGetBasicInfo = 1;
		}
#endif

#ifdef TMR_GENERAL_FL5	// 16 x 25ms
		if (flTimer & TMR_GENERAL_FL5)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL5);
		}
#endif

#ifdef TMR_GENERAL_FL6	// 32 x 25ms
		if (flTimer & TMR_GENERAL_FL6)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL6);
		}
#endif

#ifdef TMR_GENERAL_FL7	// 64 x 25ms
		if (flTimer & TMR_GENERAL_FL7)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL7);
		}
#endif

#ifdef TMR_GENERAL_FL8	// 128 x 25ms
		if (flTimer & TMR_GENERAL_FL8)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL8);
		}
#endif

		////////////////////////////////////////////////////////////////////////////////////////////////
		// processing of received ACP-data
		////////////////////////////////////////////////////////////////////////////////////////////////

		acpProcessReceivedMessages();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// processing of received IPOD-data
		////////////////////////////////////////////////////////////////////////////////////////////////

		ipodProcessReceivedMessages();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// update display info
		////////////////////////////////////////////////////////////////////////////////////////////////

		updateDisplayInfo();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// update LED's
		////////////////////////////////////////////////////////////////////////////////////////////////

		// update status of LED's
		statusLedsOld = statusLedsNew;
		statusLedsNew = statusLeds;

		// update LED's
		if (statusLedsNew != statusLedsOld)
		{
			writeLeds();
		}
	}

	// should not come here
	statusLeds = 0x00;
	writeLeds();
		
	return -1;
}
