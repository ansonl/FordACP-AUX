/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"
#include "acp.h"
#include "ipod.h"
#include "timer.h"
#include "spiComm.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

#define DIP_PORT        PORTC		// port for the DIP-switches
#define DIP_DATA0_PORT	DIP_PORT	// the pin is "1" when connected to ground
#define DIP_DATA1_PORT	DIP_PORT	// the pin is "0" when not connected (pulled high)
#define DIP_DATA2_PORT	DIP_PORT
#define DIP_DATA3_PORT	DIP_PORT
#define DIP_DATA0_PIN	0
#define DIP_DATA1_PIN	1
#define DIP_DATA2_PIN	2
#define DIP_DATA3_PIN	3

#define LED_PORT		PORTD		// port for the status LED's
#define LED_DATA0_PORT	LED_PORT
#define LED_DATA1_PORT	LED_PORT
#define LED_DATA2_PORT	LED_PORT
#define LED_DATA3_PORT	LED_PORT
#define LED_DATA0_PIN	4
#define LED_DATA1_PIN	5
#define LED_DATA2_PIN	6
#define LED_DATA3_PIN	7

#define SLAVE_RESET_PORT	PORTC
#define SLAVE_RESET_PIN		4

// states for the status leds
// clear/set all
#define STA_CLEAR_ALL			0x00
#define STA SET_ALL				0x0F
// init states:
//		00: on-boot value
//		01: passed main init
//		10: passed HU init
//		11: passed PLAYER init
#define STA_INIT_BIT0			0
#define STA_INIT_BIT1			1
// head unit tx/rx
#define STA_TXRX_HU_BIT0		2
// player tx/rx
#define STA_TXRX_PLAYER_BIT0	3

// states for the dip switches
// clear/set all
#define SW_CLEAR_ALL			0x00
#define SW_SET_ALL				0x0F
// player type
#define SW_PLAYER_TYPE_BIT0		0
#define SW_PLAYER_TYPE_BIT1		1
// LCD on/off
#define SW_LCD_ON_BIT0			2
// debug on/off
#define SW_DEBUG_ON_BIT0		3

// variables for storing the status of the DIP-switches and the status-LED's
uint8_t statusDips = 0x00;
uint8_t statusLeds = 0x00;

// init levels
#define INIT_LCD_OFF			0
#define INIT_LCD_ON				1

// debug sign
#define DEBUG_SIGN_OFF			0
#define DEBUG_SIGN_ON			1

// general flags
#define FL_LCD					0x01
#define FL_DEBUG				0x02
