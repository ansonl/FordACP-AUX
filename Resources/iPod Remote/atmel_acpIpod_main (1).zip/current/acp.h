/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// ACP UART on microcontroller
#define ACP_UART_RECV			SIG_USART0_RECV		// interrupt for receiving data on UART
#define ACP_UART_UCSRA			UCSR0A				// UART control and status register A
#define ACP_UART_UCSRB			UCSR0B				// UART control and status register B
#define ACP_UART_UCSRC			UCSR0C				// UART control and status register C
#define ACP_UART_UDR			UDR0				// UART data register
#define ACP_UART_FE				FE0					// UART frame error
#define ACP_UART_DOR			DOR0				// UART data overrun
#define ACP_UART_PE				UPE0				// UART parity error
#define ACP_UART_UBRRH			UBRR0H				// UART baud rate register H
#define ACP_UART_UBRRL			UBRR0L				// UART baud rate register L
#define ACP_UART_RXCIE			RXCIE0				// UART RX complete interrupt
#define ACP_UART_RXEN			RXEN0				// UART RX enable
#define ACP_UART_TXEN			TXEN0				// UART TX enable
#define ACP_UART_UCSZ0			UCSZ00				// UART character size 0
#define ACP_UART_UCSZ1			UCSZ01				// UART character size 1
#define ACP_UART_UCSZ2			UCSZ02				// UART character size 2
#define ACP_UART_URSEL			URSEL0				// UART register select
#define ACP_UART_UDRE			UDRE0				// UART data register empty
#define ACP_UART_RXB8			RXB80				// UART ninth bit RX
#define ACP_UART_TXB8			TXB80				// UART ninth bit TX
#define ACP_UART_TXC			TXC0				// UART TX complete

// ACP port and pins on microcontroller
#define ACP_PORT				PORTD				// ACP port
#define ACP_RX_PIN				0					// UART RX pin
#define ACP_TX_PIN				1					// UART TX pin
#define ACP_TX_ENABLE_PIN		2					// UART TX ENABLE pin

// ACP baud rate: 9600 bps (asynchronous normal mode)
#define ACP_UART_BAUD_RATE		9600
#define ACP_UART_BAUD_SELECT	((uint32_t)((uint32_t)F_CPU/(ACP_UART_BAUD_RATE*16L)-1))

// status of the ACP communication
#define ACP_RX_READY			0
#define ACP_RX_RECEIVING		1
#define ACP_RX_MSG_COMPLETE		2
#define ACP_RX_BUFFERS_FULL		3

#define ACP_TX_READY			0
#define ACP_TX_MSG_COMPOSING	1
#define ACP_TX_MSG_COMPLETE		2
#define ACP_TX_BUFFERS_FULL		3

// ACP_ACK = 0x06
#define	ACP_ACK					0x06

// ACP timings
#define ACP_BTI					104						// 104 �s
#define ACP_ACK_PRE_DELAY		(5 * ACP_BTI / 1000)	// delay in ms before ACK
#define ACP_ACK_POST_DELAY		(30 * ACP_BTI / 1000)	// delay in ms after ACK
#define ACP_MSG_PRE_DELAY		(30 * ACP_BTI / 1000)	// delay in ms before message
#define ACP_MSG_POST_DELAY		(30 * ACP_BTI / 1000)	// delay in ms after message

// number of data buffers for TX and RX
#define ACP_DATA_BUFFERS		8
#define ACP_EMPTY_RX_BUFFER		0x00
#define ACP_EMPTY_TX_BUFFER		0x00
#define ACP_FULL_RX_BUFFER		0xff
#define ACP_FULL_TX_BUFFER		0xff

// max. length of an ACP message: 12 bytes
#define ACP_MAX_MSG_LENGTH		12

// ACP status flags
#define ACP_STA_CLEAR			0x00
#define ACP_STA_SENDDISCINFO	_BV(0)
#define ACP_STA_SEEKING			_BV(1)

// ACP command flags (commands for player)
#define ACP_CMD_CLEAR			0x0000
#define ACP_CMD_PLAY			_BV(0)
#define ACP_CMD_PAUSE			_BV(1)
#define ACP_CMD_TOGGLE_PLAY		_BV(2)
#define ACP_CMD_TOGGLE_SHUFFLE	_BV(3)
#define ACP_CMD_SKIP_REV_3ALB	_BV(4)
#define ACP_CMD_SKIP_REV_1ALB	_BV(5)
#define ACP_CMD_SKIP_FWD_1ALB	_BV(6)
#define ACP_CMD_SKIP_FWD_3ALB	_BV(7)
#define ACP_CMD_SKIP_REV		_BV(8)
#define ACP_CMD_SKIP_FWD		_BV(9)
#define ACP_CMD_FAST_REV		_BV(10)
#define ACP_CMD_FAST_FWD		_BV(11)

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

void acpUartInit(void);
void acpResetRXStatus(void);
void acpResetTXStatus(void);
void acpResetRXData(void);
void acpResetTXData(void);
void acpResetProcData(void);
void acpInit(void);

uint8_t acpGetTotalRXBytes(void);
uint8_t acpGetTotalTXBytes(void);

void acpSetStatusFlags(uint8_t);
uint8_t acpGetStatusFlags(void);
void acpSetCommandFlags(uint16_t);
uint16_t acpGetCommandFlags(void);

void acpProcessReceivedData(uint8_t, uint8_t);
void acpProcessReceivedMessages(void);
void acpSendAck(void);
void acpSendDiscInfo(void);
void acpSendMessages(void);
void acpSendMessage(void);

uint8_t bin2bcd(uint8_t);
void acpSetDiscInfo(uint8_t, uint8_t, uint8_t, uint8_t);
