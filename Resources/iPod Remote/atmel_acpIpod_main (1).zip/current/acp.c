/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "acp.h"

////////////////////////////////////////////////
// defines/constants/declarations
////////////////////////////////////////////////

// status of the ACP communication
uint8_t acpRXStatus;
uint8_t acpTXStatus;

// RX data
uint8_t acpRXTotalBytes;
uint8_t acpRXActiveData;
uint8_t acpRXCurrentData;
uint8_t acpRXData[ACP_DATA_BUFFERS][ACP_MAX_MSG_LENGTH];
uint8_t acpRXDataCount[ACP_DATA_BUFFERS];
uint8_t acpRXChecksum[ACP_DATA_BUFFERS];

// TX data
uint8_t acpTXTotalBytes;
uint8_t acpTXActiveData;
uint8_t acpTXCurrentData;
uint8_t acpTXData[ACP_DATA_BUFFERS][ACP_MAX_MSG_LENGTH];
uint8_t acpTXDataCount[ACP_DATA_BUFFERS];
uint8_t acpTXChecksum[ACP_DATA_BUFFERS];
uint8_t acpTXDiscInfo[ACP_MAX_MSG_LENGTH];

// processing data
uint8_t acpProcRXData;
uint8_t acpProcTXData;

// disc, track and time info
uint8_t acpCurrentDisc = 0;
uint8_t acpCurrentTrack = 0;
uint8_t acpCurrentHour = 0;
uint8_t acpCurrentMinute = 0;

// acp status flags
uint8_t acpStatusFlags = ACP_STA_CLEAR;
// acp command flags
uint16_t acpCommandFlags = ACP_CMD_CLEAR;

////////////////////////////////////////////////
// interrupt handling
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// data received on uart
ISR(ACP_UART_RECV)
{
	// variables
	uint8_t uartStatus;
	uint8_t rxByteH;
	uint8_t rxByteL;

	// status uart
	uartStatus = ACP_UART_UCSRA;

	// rxByteH
	// 9th bit is received in UCSRB
	rxByteH = ACP_UART_UCSRB;
	// rxByteL
	// 8 other data bits
	rxByteL = ACP_UART_UDR;

	// check if there is a frame error, data overrun or parity error
	if ((uartStatus & ((1<<ACP_UART_FE)|(1<<ACP_UART_DOR)|(1<<ACP_UART_PE))) != 0x00)
	{
		return;
	}

	// increment total RX bytes
	acpRXTotalBytes++;

	// filter the 9th data bit; rxByteH can now be 1 or 0
	// rxByteH contains eod-bit
	rxByteH = (rxByteH >> ACP_UART_RXB8) & 0x01;

	// process the received data
	acpProcessReceivedData(rxByteH, rxByteL);
}

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// initializes the ACP uart
void acpUartInit(void)
{
	// we will use ACP_UART for communication with the head unit
	// ACP_TX: DDR set low; PORT set low
	// ACP_RX: DDR set low; PORT set low
	// ACP_TX_ENABLE: DDR set high; PORT set low
	DDR(ACP_PORT) &= ~_BV(ACP_TX_PIN);
	DDR(ACP_PORT) &= ~_BV(ACP_RX_PIN);
	DDR(ACP_PORT) |= _BV(ACP_TX_ENABLE_PIN);
	ACP_PORT &= ~_BV(ACP_TX_PIN);
	ACP_PORT &= ~_BV(ACP_RX_PIN);
	ACP_PORT &= ~_BV(ACP_TX_ENABLE_PIN);

	// set UART baud rate
	ACP_UART_UBRRH = (uint8_t)(ACP_UART_BAUD_SELECT>>8);
	ACP_UART_UBRRL = (uint8_t)(ACP_UART_BAUD_SELECT);

	// set UART for:
	//		ACP_UART_UCSRA
	//		- asynchronous normal mode (default)
	//		ACP_UART_UCSRB/ACP_UART_UCSRC
	//		- RXCIE (RX complete interrupt enable)
	//		- RXEN (RX enable)
	//		- TXEN (TX enable)
	//		- 9 data bits
	//		- no parity (default)
	//		- 1 stop bit (default)
	ACP_UART_UCSRB = (uint8_t)((1<<ACP_UART_RXCIE) | (1<<ACP_UART_RXEN) | (1<<ACP_UART_TXEN) | (1<<ACP_UART_UCSZ2));
	ACP_UART_UCSRC = (uint8_t)((1<<ACP_UART_URSEL) | (1<<ACP_UART_UCSZ1) | (1<<ACP_UART_UCSZ0));
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the ACP variables

////////////////////////////////////////////////////////////////////////////////////////////////
// acpRXStatus
void acpResetRXStatus(void)
{
	acpRXStatus = ACP_RX_READY;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// acpRXStatus
void acpResetTXStatus(void)
{
	acpTXStatus = ACP_TX_READY;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the RX data
void acpResetRXData(void)
{
	uint8_t i, j;

	acpRXTotalBytes = 0;
	acpRXActiveData = 0x00;
	acpRXCurrentData = 0;

	for (i = 0; i < ACP_DATA_BUFFERS; i++)
	{
		// reset the counters
		acpRXDataCount[i] = 0;

		// reset the checksums
		acpRXChecksum[i] = 0;

		for (j = 0; j < ACP_MAX_MSG_LENGTH; j++)
		{
			acpRXData[i][j] = 0x00;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the TX data
void acpResetTXData(void)
{
	uint8_t i, j;

	acpTXTotalBytes = 0;
	acpTXActiveData = 0x00;
	acpTXCurrentData = 0;

	for (i = 0; i < ACP_DATA_BUFFERS; i++)
	{
		// reset the counters
		acpTXDataCount[i] = 0;

		// reset the checksums
		acpTXChecksum[i] = 0;

		for (j = 0; j < ACP_MAX_MSG_LENGTH; j++)
		{
			acpTXData[i][j] = 0x00;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the processing data
void acpResetProcData(void)
{
	acpProcRXData = 0;
	acpProcTXData = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// general initialization
void acpInit(void)
{
	acpResetRXStatus();
	acpResetTXStatus();
	acpResetRXData();
	acpResetTXData();
	acpResetProcData();
	acpUartInit();
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return total RX bytes
uint8_t acpGetTotalRXBytes(void)
{
	return acpRXTotalBytes;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return total TX bytes
uint8_t acpGetTotalTXBytes(void)
{
	return acpTXTotalBytes;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get status flags
uint8_t acpGetStatusFlags(void)
{
	return acpStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set status flags
void acpSetStatusFlags(uint8_t acpNewStatusFlags)
{
	acpStatusFlags = acpNewStatusFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// get command flags
uint16_t acpGetCommandFlags(void)
{
	uint16_t acpTemp;
	acpTemp = acpCommandFlags;
	acpCommandFlags = ACP_CMD_CLEAR;
	return acpTemp;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set command flags
void acpSetCommandFlags(uint16_t acpNewCommandFlags)
{
	acpCommandFlags = acpNewCommandFlags;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// process the received ACP-data
void acpProcessReceivedData(uint8_t rxByteH, uint8_t rxByteL)
{
	switch (acpRXStatus)
	{
		case ACP_RX_READY:
		case ACP_RX_RECEIVING:
		{
			if (acpRXStatus == ACP_RX_READY)
			{
				// change status: receiving data
				acpRXStatus = ACP_RX_RECEIVING;

				// prepare buffer variables
				acpRXActiveData &= ~(1<<acpRXCurrentData);
				acpRXDataCount[acpRXCurrentData] = 0;
				acpRXChecksum[acpRXCurrentData] = 0;
			}

			// process the data
			if (acpRXDataCount[acpRXCurrentData] < ACP_MAX_MSG_LENGTH)
			{
				// if received <= ACP_MAX_MSG_LENGTH bytes
				acpRXData[acpRXCurrentData][acpRXDataCount[acpRXCurrentData]] = rxByteL;
				// increase the received data counter
				acpRXDataCount[acpRXCurrentData] += 1;

				if (rxByteH == 0)
				{
					// check eod-bit: if 0: continue receiving
					acpRXChecksum[acpRXCurrentData] += rxByteL;
				}
				else
				{
					// check eod-bit: if 1: check checksum
					if (acpRXChecksum[acpRXCurrentData] == rxByteL)
					{
						// valid ACP-message

						// set current data active data
						acpRXActiveData |= (1<<acpRXCurrentData);

						// next buffer to use
						acpRXCurrentData = (acpRXCurrentData + 1) % ACP_DATA_BUFFERS;

						// change status and send an ACK
						acpRXStatus = ACP_RX_MSG_COMPLETE;

						acpSendAck();

						if (acpRXActiveData != ACP_FULL_RX_BUFFER)
						{
							acpRXStatus = ACP_RX_READY;
						}
						else
						{
							acpRXStatus = ACP_RX_BUFFERS_FULL;
						}
					}
					else
					{
						// no valid ACP-message: start over again

						// reset RX status
						acpResetRXStatus();
					}
				}
			}
			else
			{
				// if received > ACP_MAX_MSG_LENGTH bytes: message too long; start over again

				// reset RX status
				acpResetRXStatus();
			}

			break;
		}
		case ACP_RX_MSG_COMPLETE:			// should not come here
		case ACP_RX_BUFFERS_FULL:
		{
			// messages needs to be handled first; ignore data
			break;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	process one received message
void acpProcessReceivedMessages(void)
{
	// if we've got data in the RX buffer
	if (acpRXActiveData != ACP_EMPTY_RX_BUFFER)
	{
		switch(acpTXStatus)
		{
			case ACP_TX_READY:
			{
				// change status: composing TX data
				acpTXStatus = ACP_TX_MSG_COMPOSING;

				// prepare buffer variables
				acpTXActiveData &= ~(1<<acpTXCurrentData);
				acpTXDataCount[acpTXCurrentData] = 0;
				acpTXChecksum[acpTXCurrentData] = 0;

				// generate TX data
		    	acpTXData[acpTXCurrentData][0] = 0x71;											// priority
				acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][0];
				acpTXData[acpTXCurrentData][1] = 0x9b;						//
				acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][1];
				acpTXData[acpTXCurrentData][2] = 0x82;						//
				acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][2];

				if (acpRXData[acpProcRXData][2] == 0x80)										// message from the head unit
				{
					if (acpRXData[acpProcRXData][1] == 0x9a)									// commands
					{
						if (acpRXData[acpProcRXData][3] == 0x43)								// previous track
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							acpCommandFlags |= ACP_CMD_SKIP_REV;								// previous track

							// send back status to head unit
							acpTXData[acpTXCurrentData][3] = 0x43;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = bin2bcd(acpCurrentTrack);			// current track number
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xc1)							// control command
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							uint8_t acpMode = acpRXData[acpProcRXData][4];						// change mode: play/pause/rev/ff

							if (acpMode & 0x40)
							{
								acpCommandFlags |= ACP_CMD_PLAY;
							}
							else
							{
								acpCommandFlags |= ACP_CMD_PAUSE;
							}

							if (acpMode & 0x01)
							{
								if (acpMode & 0x04)
								{
									acpCommandFlags |= ACP_CMD_FAST_REV;
									acpStatusFlags |= ACP_STA_SEEKING;
								}
								else if (acpMode & 0x02)
								{
									acpCommandFlags |= ACP_CMD_FAST_FWD;
									acpStatusFlags |= ACP_STA_SEEKING;
								}
							}
							else
							{
								acpCommandFlags &= ~(ACP_CMD_FAST_REV | ACP_CMD_FAST_FWD);
								acpStatusFlags &= ~ACP_STA_SEEKING;
							}

							acpTXData[acpTXCurrentData][3] = 0xc1;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = acpRXData[acpProcRXData][4];		// should be acpRXData[4]
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xc2)							// change disk
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							switch(acpRXData[acpProcRXData][4])									// determine the button pressed
							{
								case 1:		// toggle play/pause
								{
									acpCommandFlags |= ACP_CMD_TOGGLE_PLAY;
									break;
								}
								case 2:		// toggle shuffle
								{
									acpCommandFlags |= ACP_CMD_TOGGLE_SHUFFLE;
									break;
								}
								case 3:		// skip 3 albums reverse
								{
									acpCommandFlags |= ACP_CMD_SKIP_REV_3ALB;
									break;
								}
								case 4:		// skip 1 album reverse
								{
									acpCommandFlags |= ACP_CMD_SKIP_REV_1ALB;
									break;
								}
								case 5:		// skip 1 album forward
								{
									acpCommandFlags |= ACP_CMD_SKIP_FWD_1ALB;
									break;
								}
								case 6:		// skip 3 albums forward
								{
									acpCommandFlags |= ACP_CMD_SKIP_FWD_3ALB;
									break;
								}
							}

							// send back status to head unit
							acpTXData[acpTXCurrentData][3] = 0xc2;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = acpCurrentDisc;					// current disc
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xc3)							// next track
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							acpCommandFlags |= ACP_CMD_SKIP_FWD;								// next track

							// send back status to head unit
							acpTXData[acpTXCurrentData][3] = 0xc3;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = bin2bcd(acpCurrentTrack);			// current track number
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xfc)							// handshake 2
						{
							acpTXData[acpTXCurrentData][3] = 0xfc;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = acpRXData[acpProcRXData][4];		// should be acpRXData[4]
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xc8)							// handshake 3
						{
							acpTXData[acpTXCurrentData][3] = 0xc8;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = acpRXData[acpProcRXData][4];		// should be acpRXData[4]
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
					}
					else if (acpRXData[acpProcRXData][1] == 0x9b)								// requests
					{
						if (acpRXData[acpProcRXData][3] == 0xc2)								// request current disk
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							acpTXData[acpTXCurrentData][3] = 0xc2;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = acpCurrentDisc;					// current disc
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xe0)							// handshake 1
						{
							acpTXData[acpTXCurrentData][3] = 0xe0;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = 0x04;								// should be 0x04
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
						else if (acpRXData[acpProcRXData][3] == 0xff)							// current disk status
						{
							acpStatusFlags |= ACP_STA_SENDDISCINFO;								// set flag to send disc info

							acpTXData[acpTXCurrentData][3] = 0xff;								// we send back the received command
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][3];
							acpTXData[acpTXCurrentData][4] = 0x00;								// always: disk ok
																								// 0x00 - disc ok
																								// 0x01 - no disc in current slot
																								// 0x02 - no discs
																								// 0x03 - check disc in current slot
																								// 0x04 - check all discs
							acpTXChecksum[acpTXCurrentData] += acpTXData[acpTXCurrentData][4];
							acpTXData[acpTXCurrentData][5] = acpTXChecksum[acpTXCurrentData];	// checksum
							acpTXDataCount[acpTXCurrentData] = 6;								// number of message bytes
						}
					}
				}

				// check if we've got a message to send
				if (acpTXDataCount[acpTXCurrentData] != 0)
				{
					// set current data active data					
					acpTXActiveData |= (1<<acpTXCurrentData);

					// next buffer to use
					acpTXCurrentData = (acpTXCurrentData + 1) % ACP_DATA_BUFFERS;
				}

				// clear the processed buffer bit
				acpRXActiveData &= ~(1<<acpProcRXData);

				// next buffer to use
				acpProcRXData = (acpProcRXData + 1) % ACP_DATA_BUFFERS;

				// if we had a full buffer
				if (acpRXActiveData != ACP_FULL_RX_BUFFER)
				{
					if (acpRXStatus == ACP_RX_BUFFERS_FULL)
					{
						acpRXStatus = ACP_RX_READY;
					}
				}

				// change status: complete
				acpTXStatus = ACP_TX_MSG_COMPLETE;

				if (acpTXActiveData != ACP_FULL_TX_BUFFER)
				{
					acpTXStatus = ACP_TX_READY;
				}
				else
				{
					acpTXStatus = ACP_TX_BUFFERS_FULL;
				}

				break;
			}

			case ACP_TX_MSG_COMPOSING:		// should not come here
			case ACP_TX_MSG_COMPLETE:		// should not come here
			case ACP_TX_BUFFERS_FULL:
			{
				// messages need to be sent first
				break;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	send ACP-ack
void acpSendAck(void)
{
	// wait until RX line goes high (idle)
	while (!(PIN(ACP_PORT) & _BV(ACP_RX_PIN)))
	{
		;
	}

	// wait for before ACK
	_delay_ms(ACP_ACK_PRE_DELAY);

	// enable ACP-TX
	ACP_PORT |= _BV(ACP_TX_ENABLE_PIN);

	// wait for empty TX-buffer
	while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
	{
		;
	}

	// send ACK
	ACP_UART_UCSRB &= ~_BV(ACP_UART_TXB8);		// ninth bit: zero
	ACP_UART_UDR = ACP_ACK;						// bit 1-8: ACP_ACK

	// wait for empty TX-buffer
	while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
	{
		;
	}

	// wait for after ACK
	_delay_ms(ACP_ACK_POST_DELAY);

	// disable ACP-TX
	ACP_PORT &= ~_BV(ACP_TX_ENABLE_PIN);
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	send disc, track and time info
void acpSendDiscInfo(void)
{
	// prepare data to send
	acpTXDiscInfo[0] = 0x71;
	acpTXDiscInfo[8] = acpTXDiscInfo[0];
	acpTXDiscInfo[1] = 0x9b;
	acpTXDiscInfo[8] += acpTXDiscInfo[1];
	acpTXDiscInfo[2] = 0x82;
	acpTXDiscInfo[8] += acpTXDiscInfo[2];
	acpTXDiscInfo[3] = 0xd0;
	acpTXDiscInfo[8] += acpTXDiscInfo[3];
	acpTXDiscInfo[4] = acpCurrentDisc;
	acpTXDiscInfo[8] += acpTXDiscInfo[4];
	acpTXDiscInfo[5] = bin2bcd(acpCurrentTrack);
	acpTXDiscInfo[8] += acpTXDiscInfo[5];
	acpTXDiscInfo[6] = bin2bcd(acpCurrentHour);
	acpTXDiscInfo[8] += acpTXDiscInfo[6];
	acpTXDiscInfo[7] = bin2bcd(acpCurrentMinute) | _BV(7);
	acpTXDiscInfo[8] += acpTXDiscInfo[7];

	// init send
	// delay for new message
	_delay_ms(ACP_MSG_PRE_DELAY);

	// wait until RX line goes high (idle)
	while (!(PIN(ACP_PORT) & _BV(ACP_RX_PIN)))
	{
		;
	}

	// enable ACP-TX
	ACP_PORT |= _BV(ACP_TX_ENABLE_PIN);

	// actual data send
	uint8_t i;
	for (i = 0; i < 9; i++)
	{
		// wait for empty TX-buffer
		while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
		{
			;
		}

		// send data
		if (i == 8)		// last byte: eod = 1
		{
			ACP_UART_UCSRB |= _BV(ACP_UART_TXB8);
		}
		else
		{
			ACP_UART_UCSRB &= ~_BV(ACP_UART_TXB8);
		}
		ACP_UART_UDR = acpTXDiscInfo[i];

		// increment total TX bytes
		acpTXTotalBytes++;
	}

	// wait for empty TX-buffer
	while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
	{
		;
	}

	// wait for complete data TX
	_delay_ms(ACP_MSG_POST_DELAY);

	// disable ACP-TX (send is now complete)
	ACP_PORT &= ~_BV(ACP_TX_ENABLE_PIN);
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	send all ACP-messages
void acpSendMessages(void)
{
	// if we've got data in the TX buffer
	while (acpTXActiveData != ACP_EMPTY_TX_BUFFER)
	{
		acpSendMessage();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	send one ACP-message
void acpSendMessage(void)
{
	// if we've got data in the TX buffer
	if (acpTXActiveData != ACP_EMPTY_TX_BUFFER)
	{
		// init send
		// delay for new message
		_delay_ms(ACP_MSG_PRE_DELAY);

		// wait until RX line goes high (idle)
		while (!(PIN(ACP_PORT) & _BV(ACP_RX_PIN)))
		{
			;
		}

		// enable ACP-TX
		ACP_PORT |= _BV(ACP_TX_ENABLE_PIN);

		// actual data send
		uint8_t i;
		for (i = 0; i < acpTXDataCount[acpProcTXData]; i++)
		{
			// wait for empty TX-buffer
			while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
			{
				;
			}

			// send data
			if (i == (acpTXDataCount[acpProcTXData] - 1))		// last byte: eod = 1
			{
				ACP_UART_UCSRB |= _BV(ACP_UART_TXB8);
			}
			else
			{
				ACP_UART_UCSRB &= ~_BV(ACP_UART_TXB8);
			}
			ACP_UART_UDR = acpTXData[acpProcTXData][i];

			// increment total TX bytes
			acpTXTotalBytes++;
		}

		// wait for empty TX-buffer
		while(!(ACP_UART_UCSRA & _BV(ACP_UART_UDRE)))
		{
			;
		}

		// wait for complete data TX
		_delay_ms(ACP_MSG_POST_DELAY);

		// disable ACP-TX (send is now complete)
		ACP_PORT &= ~_BV(ACP_TX_ENABLE_PIN);

		// clear the processed buffer bit
		acpTXActiveData &= ~(1<<acpProcTXData);

		// next buffers to use
		acpProcTXData = (acpProcTXData + 1) % ACP_DATA_BUFFERS;

		// if we had a full buffer
		if (acpTXActiveData != ACP_FULL_TX_BUFFER)
		{
			if (acpTXStatus == ACP_TX_BUFFERS_FULL)
			{
				acpTXStatus = ACP_TX_READY;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	convert data to bcd
uint8_t bin2bcd(uint8_t dataIn)
{
    return ((dataIn/10)*16) + (dataIn % 10) ;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//	set disc info
void acpSetDiscInfo(uint8_t acpNewDisc, uint8_t acpNewTrack, uint8_t acpNewHour, uint8_t acpNewMinute)
{
	acpCurrentDisc = acpNewDisc;
	acpCurrentTrack = acpNewTrack;
	acpCurrentHour = acpNewHour;
	acpCurrentMinute = acpNewMinute;
}
