/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "t6963c.h"

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// delay function
void GLCD_delay(void)
{
	volatile unsigned char i;
	for(i = 0; i < (F_CPU/2000000); i++)
	{
//		asm("nop");
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reads dispay status
uint8_t GLCD_checkStatus(void)
{
	GLCD_DATA_DDR = 0x00;
	GLCD_CTRL_PORT &= ~((1 << GLCD_RD) | (1 << GLCD_CE));
	GLCD_delay();
	uint8_t d = GLCD_DATA_PIN;
	GLCD_DATA_DDR = 0xFF;
	GLCD_CTRL_PORT |= ((1 << GLCD_RD) | (1 << GLCD_CE));

	return d;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes instruction 
void GLCD_writeCommand(uint8_t command)
{
	while (!(GLCD_checkStatus() & 0x03))
	{
		;
	}

	GLCD_DATA_PORT = command;
	GLCD_CTRL_PORT &= ~((1 << GLCD_WR) | (1 << GLCD_CE));
	GLCD_delay();
	GLCD_CTRL_PORT |= ((1 << GLCD_WR) | (1 << GLCD_CE));
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes data
void GLCD_writeData(uint8_t data)
{
	while (!(GLCD_checkStatus() & 0x03))
	{
		;
	}

	GLCD_DATA_PORT = data;
	GLCD_CTRL_PORT &= ~((1 << GLCD_WR) | (1 << GLCD_CE) | (1 << GLCD_CD));
	GLCD_delay();
	GLCD_CTRL_PORT |= ((1 << GLCD_WR) | (1 << GLCD_CE) | (1 << GLCD_CD));
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reads data
uint8_t GLCD_readData(void)
{
	while (!(GLCD_checkStatus() & 0x03))
	{
		;
	}

	GLCD_DATA_DDR = 0x00;
	GLCD_CTRL_PORT &= ~((1 << GLCD_RD) | (1 << GLCD_CE) | (1 << GLCD_CD));
	GLCD_delay();
	uint8_t d = GLCD_DATA_PIN;
	GLCD_DATA_DDR = 0xFF;
	GLCD_CTRL_PORT |= ((1 << GLCD_RD) | (1 << GLCD_CE) | (1 << GLCD_CD));

	return d;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// sets address pointer for display RAM memory
void GLCD_setAddressPointer(uint16_t address)
{
	GLCD_writeData(address & 0xFF);
	GLCD_writeData(address >> 8);
	GLCD_writeCommand(T6963_SET_ADDRESS_POINTER);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes display data and increment address pointer
void GLCD_writeDisplayData(uint8_t d)
{
	GLCD_writeData(d);
	GLCD_writeCommand(T6963_DATA_WRITE_AND_INCREMENT);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// ports intalization
void GLCD_initializeInterface(void)
{
	// data port
	GLCD_DATA_DDR = 0xFF;

	// control port
	GLCD_CTRL_DDR |= ((1 << GLCD_WR) | (1 << GLCD_RD) | (1 << GLCD_CE) | (1 << GLCD_CD) | (1 << GLCD_RESET) | (1 << GLCD_FS));
	GLCD_CTRL_PORT |= ((1 << GLCD_WR) | (1 << GLCD_RD) | (1 << GLCD_CE) | (1 << GLCD_CD) | (1 << GLCD_RESET));

	// font width
	if (GLCD_FONT_WIDTH == GLCD_FONT_WIDTH_8)
	{
		GLCD_CTRL_PORT &= ~(1 << GLCD_FS);
	}
	else
	{
		GLCD_CTRL_PORT |= (1 << GLCD_FS);
	}

	// reset
	GLCD_CTRL_PORT &= ~(1 << GLCD_RESET);
	_delay_ms(1);
	GLCD_CTRL_PORT |= (1 << GLCD_RESET);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// memory intalization
void GLCD_initializeMemory(void)
{
	// display off
	GLCD_writeCommand(T6963_DISPLAY_OFF);

	// base address text mode
	GLCD_writeData(GLCD_TEXT_HOME);
	GLCD_writeData(GLCD_TEXT_HOME >> 8);
	GLCD_writeCommand(T6963_SET_TEXT_HOME_ADDRESS);

	// set text area
	GLCD_writeData(GLCD_TEXT_AREA);
	GLCD_writeData(0x00);
	GLCD_writeCommand(T6963_SET_TEXT_AREA);

	// base address graphic mode
	GLCD_writeData(GLCD_GRAPHIC_HOME & 0xFF);
	GLCD_writeData(GLCD_GRAPHIC_HOME >> 8);
	GLCD_writeCommand(T6963_SET_GRAPHIC_HOME_ADDRESS);

	// set graphic area
	GLCD_writeData(GLCD_GRAPHIC_AREA);
	GLCD_writeData(0x00);
	GLCD_writeCommand(T6963_SET_GRAPHIC_AREA);

	// set offset register
	GLCD_writeData(GLCD_OFFSET_REGISTER);
	GLCD_writeData(0x00);
	GLCD_writeCommand(T6963_SET_OFFSET_REGISTER);

	// display mode: OR and ROM generator
	GLCD_writeCommand(T6963_MODE_OR | T6963_MODE_ROM);

	// cursor-height: 8 pixels
	GLCD_writeCommand(T6963_CURSOR_8_LINE);

	// cursor op (0,0)
	GLCD_cursorGoTo(0, 0);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// display initialization
void GLCD_initializeDisplay(void)
{
	// init interface
	GLCD_initializeInterface();

	// init memory
	GLCD_initializeMemory();

	// clear text memory
	GLCD_clearTextMemory();

	// clear graphic memory
	GLCD_clearGraphicMemory();

	// clear CG memory
	GLCD_clearCGMemory();

	// turn display on
	GLCD_writeCommand(T6963_TEXT_DISPLAY_ON | T6963_GRAPHIC_DISPLAY_ON);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// clear CG memory
void GLCD_clearCGMemory(void)
{
	GLCD_setAddressPointer(GLCD_EXTERNAL_CG_HOME);

	uint16_t i;
	for(i = 0; i < 128 * 8; i++)
	{
		GLCD_writeDisplayData(0x00);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// clear text memory
void GLCD_clearTextMemory(void)
{
	GLCD_setAddressPointer(GLCD_TEXT_HOME);

	uint16_t i;
	for(i = 0; i < GLCD_TEXT_SIZE; i++)
	{
		GLCD_writeDisplayData(0x00);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// clear graphic memory
void GLCD_clearGraphicMemory(void)
{
	GLCD_setAddressPointer(GLCD_GRAPHIC_HOME);

	uint16_t i;
	for(i = 0; i < GLCD_GRAPHIC_SIZE; i++)
	{
		GLCD_writeDisplayData(0x00);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes single char pattern to character generator area of display RAM memory
void GLCD_defineCharacter(uint8_t charCode, uint8_t *charDefinition)
{
	uint16_t address = GLCD_EXTERNAL_CG_HOME + (8 * (charCode - 0x80));

	GLCD_setAddressPointer(address);

	uint8_t i; 
	for (i = 0; i < 8 ; i++)
	{
		GLCD_writeDisplayData(*(charDefinition + i));
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes a single character (ASCII code) to display RAM memory
void GLCD_writeChar(uint8_t c)
{
	GLCD_writeDisplayData(c - GLCD_ASCII_OFFSET);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// writes null-terminated string to display RAM memory
void GLCD_writeString(uint8_t *str)
{
	while(*str)
	{
		GLCD_writeChar(*str++);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// sets display coordinates (for cursor)
void GLCD_cursorGoTo(uint8_t x, uint8_t y)
{
	GLCD_writeData(x);
	GLCD_writeData(y);
	GLCD_writeCommand(T6963_SET_CURSOR_POINTER);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// sets display coordinates (for text)
void GLCD_textGoTo(uint8_t x, uint8_t y)
{
	uint16_t address = GLCD_TEXT_HOME +  x + (GLCD_TEXT_AREA * y);

	GLCD_setAddressPointer(address);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// sets graphic coordinates
void GLCD_graphicGoTo(uint8_t x, uint8_t y)
{
	uint16_t address = GLCD_GRAPHIC_HOME + (x / GLCD_FONT_WIDTH) + (GLCD_GRAPHIC_AREA * y);

	GLCD_setAddressPointer(address);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// puts pixel on screen (set if color == 1; clear if color == 0)
void GLCD_putPixel(uint8_t x, uint8_t y, uint8_t color)
{
	GLCD_graphicGoTo(x, y);

	// first read existing value
	GLCD_writeCommand(T6963_DATA_READ_AND_NONVARIABLE);
	uint8_t tmpChar = GLCD_readData();

	switch (color)
	{
		case 0:
		{
			tmpChar &= ~(1 <<  (GLCD_FONT_WIDTH - 1 - (x % GLCD_FONT_WIDTH)));
			break;
		}
		case 1:
		{
			tmpChar |= (1 <<  (GLCD_FONT_WIDTH - 1 - (x % GLCD_FONT_WIDTH)));
			break;
		}
		break;
	}

	GLCD_writeDisplayData(tmpChar);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// draws a filled box (set if color == 1; clear if color == 0)
void GLCD_drawBox(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color)
{
	uint8_t xStart, yStart, xStop, yStop, x, y;

	if (x1 < x2)
	{
		xStart = x1;
		xStop = x2;
	}
	else
	{
		xStart = x2;
		xStop = x1;
	}

	if (y1 < y2)
	{
		yStart = y1;
		yStop = y2;
	}
	else
	{
		yStart = y2;
		yStop = y1;
	}

	for (x = xStart; x <= xStop; x++)
	{
		for (y = yStart; y <= yStop; y++)
		{
			GLCD_putPixel(x, y, color);
		}
	}
}
