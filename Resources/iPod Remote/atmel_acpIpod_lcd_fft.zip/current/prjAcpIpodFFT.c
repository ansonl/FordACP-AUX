/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "prjAcpIpodFFT.h"

////////////////////////////////////////////////
// defines/constants/declarations
////////////////////////////////////////////////

#ifdef FFT_USE_8BIT_SAMPLES
int8_t aSamplesL[FFT_SAMPLECOUNT];						// FFT sample buffer L (8 bits)
int8_t aSamplesR[FFT_SAMPLECOUNT];						// FFT sample buffer R (8 bits)
#else
int16_t aSamplesL[FFT_SAMPLECOUNT];						// FFT sample buffer L (16 bits)
int16_t aSamplesR[FFT_SAMPLECOUNT];						// FFT sample buffer R (16 bits)
#endif

complex_t aSamplesBflyBuff[FFT_SAMPLECOUNT];			// FFT temp buffer
uint16_t aSpectrumFull[FFT_SPECTRUMCOUNT];				// FFT full spectrum buffer

uint8_t aSpectrumConvL[FFT_SPECTRUM_GRAPH_WIDTH];		// FFT converted spectrum buffer L
uint8_t aSpectrumConvR[FFT_SPECTRUM_GRAPH_WIDTH];		// FFT converted spectrum buffer R

uint8_t aSpectrumGraphL[FFT_SPECTRUM_GRAPH_BYTECOUNT];	// FFT graph spectrum buffer L
uint8_t aSpectrumGraphR[FFT_SPECTRUM_GRAPH_BYTECOUNT];	// FFT graph spectrum buffer R

// strings variables
uint8_t (*p_SPI_strArtist)[SPI_STRLEN_ARTIST];
uint8_t (*p_SPI_strAlbum)[SPI_STRLEN_ALBUM];
uint8_t (*p_SPI_strTrack)[SPI_STRLEN_TRACK];
uint8_t (*p_SPI_strGenre)[SPI_STRLEN_GENRE];
uint8_t (*p_SPI_strTrackNrCur)[SPI_STRLEN_TRACKNR_CUR];
uint8_t (*p_SPI_strTrackNrTot)[SPI_STRLEN_TRACKNR_TOT];
uint8_t (*p_SPI_strTimePlayed)[SPI_STRLEN_TIME_PLAYED];
uint8_t (*p_SPI_strTimeRemain)[SPI_STRLEN_TIME_REMAIN];
uint8_t (*p_SPI_strTimeTotal)[SPI_STRLEN_TIME_TOTAL];
uint8_t (*p_SPI_strPlayStatus)[SPI_STRLEN_PLAY_STATUS];

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// init 8-bit array
void initArray_8bit(uint8_t *aValues, uint8_t value, uint16_t count)
{
	uint16_t i;
	for (i = 0; i < count; i++)
	{
		aValues[i] = value;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// init 16-bit array
void initArray_16bit(uint16_t *aValues, uint16_t value, uint16_t count)
{
	uint16_t i;
	for (i = 0; i < count; i++)
	{
		aValues[i] = value;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// init SPI-string
void initSPIString(uint8_t *aValues, uint8_t value, uint16_t count)
{
	initArray_8bit(aValues, value, count);
	if (count >= 3)
	{
		aValues[count - 3] = 0;	// \0
		aValues[count - 2] = 0;	// length
		aValues[count - 1] = 0;	// position
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set clock for external LPF
void setLPFClock(void)
{
	// F_CPU		PRESCALER	OCR0		F_CL = F_CPU / (2 * PRESCALER * (1 + OCR0))
	// 14.7456 MHz	1			2			2457600 Hz

	DDRB = 0x08;															// we use PB3 (OC0A) for output clock

	OCR0A = 2;																// output compare match = 2
	TCNT0 = 0;																// clear the counter
		
	TCCR0A = _BV(COM0A0) | _BV(WGM01);										// waveform: clear timer on compare match (CTC)
																			// toggle OC0 on compare match
	TCCR0B = _BV(CS00);														// no clock prescaling
}

////////////////////////////////////////////////////////////////////////////////////////////////
// capture samples
#ifdef FFT_USE_8BIT_SAMPLES
void captureSamples(int8_t *aSampleBuffer, uint8_t side)
#else
void captureSamples(int16_t *aSampleBuffer, uint8_t side)
#endif
{
	uint16_t i = 0;

	if (side == FFT_LEFT)
	{
		ADMUX = _BV(REFS0)|_BV(ADLAR);									// ADC0: left channel
	}
	else
	{
		ADMUX = _BV(REFS0)|_BV(ADLAR)|_BV(MUX0);						// ADC1: right channel
	}

	for (i = 0; i < FFT_SAMPLECOUNT; i++)
	{
		ADCSRA = _BV(ADEN)|_BV(ADSC)|_BV(ADIF)|_BV(ADPS2)|_BV(ADPS0);	// prescaler = 32
																		// F_CPU		SAMPLECNT	SPECTRUMCNT	f_sample	f_max		SPECTRUM RESOLUTION
																		// 14.7456 MHz	128			64			35.44 kHz	17.72 kHz	64 * 277 Hz

		while(!(ADCSRA & (1<<ADIF)))									// wait for sample
		{
		;
		}

		int16_t s = ADC - 32768;										// new sample (13 cycles)
																		// samples go from 0000 0000 0000 0000 to
																		// 1111 1111 1100 0000 with ADLAR = 1
																		// (10 bit precesion), and are referenced from
																		// 0 to 2.5V, so we need to substract
																		// DC-offset of 1.25V, which equals 2 ^ 15
																		
#ifdef FFT_USE_8BIT_SAMPLES
		aSampleBuffer[i] = s >> 8;
#else
		aSampleBuffer[i] = s;
#endif
	}

	ADCSRA = 0;															// reset status register
}

////////////////////////////////////////////////////////////////////////////////////////////////
// corrects and converts FFT values values from logarithmic to linear values (for graph)
// optimal values found experimentally
uint8_t convertFFTValue(uint16_t i)
{
#ifdef FFT_USE_8BIT_SAMPLES
	if (i > 870) return 23;
	if (i > 741) return 22;
	if (i > 630) return 21;
	if (i > 537) return 20;
	if (i > 457) return 19;
	if (i > 389) return 18;
	if (i > 331) return 17;
	if (i > 281) return 16;
	if (i > 239) return 15;
	if (i > 204) return 14;
	if (i > 173) return 13;
	if (i > 147) return 12;
	if (i > 125) return 11;
	if (i > 107) return 10;
	if (i > 91) return 9;
	if (i > 77) return 8;
	if (i > 66) return 7;
	if (i > 56) return 6;
	if (i > 47) return 5;
	if (i > 40) return 4;
	if (i > 34) return 3;
	if (i > 29) return 2;
	if (i > 25) return 1;
#else
	if (i > 1188 ) return 23;
	if (i > 1000 ) return 22;
	if (i > 894  ) return 21;
	if (i > 707  ) return 20;
	if (i > 595  ) return 19;
	if (i > 501  ) return 18;
	if (i > 421  ) return 17;
	if (i > 354  ) return 16;
	if (i > 298  ) return 15;
	if (i > 251  ) return 14;
	if (i > 211  ) return 13;
	if (i > 177  ) return 12;
	if (i > 149  ) return 11;
	if (i > 125  ) return 10;
	if (i > 105  ) return 9;
	if (i > 89   ) return 8;
	if (i > 74   ) return 7;
	if (i > 63   ) return 6;
	if (i > 53   ) return 5;
	if (i > 44   ) return 4;
	if (i > 37   ) return 3;
	if (i > 31   ) return 2;
	if (i > 26   ) return 1;
#endif

	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// regenerates output spectrum, for use on graphical grid
void generateOutputSpectrum(uint16_t *aSpectrumIn, uint8_t *aSpectrumOut)
{
	uint8_t i;

	for (i = 0; i < FFT_SPECTRUM_GRAPH_WIDTH; i++)
	{
		uint8_t k = convertFFTValue(aSpectrumIn[i + FFT_SPECTRUM_CALC_GRAPH_OFFSET]);
		uint8_t l = aSpectrumOut[i];

		// eleminate noise; found experimentally
		if (i >= FFT_SPECTRUM_GRAPH_WIDTH - 4)
		{
			if (k >= 5)
			{
				k = k - 5;
			}
			else
			{
				k = 0;
			}
		}

		if (k > l)
		{
			aSpectrumOut[i] = k;
		}
		else
		{
			aSpectrumOut[i] = (k >> 1) + (l >> 1);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// generates a bitmap representing the spectrum
void generateGraphicalSpectrum(uint8_t *aSpectrumIn, uint8_t *aSpectrumOut)
{
	uint8_t i, j;

	// clear grid
	for (i = 0; i < FFT_SPECTRUM_GRAPH_BYTECOUNT; i++)
	{
		aSpectrumOut[i] = 0;
	}

	// fill grid
	for (i = 0; i < FFT_SPECTRUM_GRAPH_HEIGHT; i++)
	{
		for (j = 0; j < FFT_SPECTRUM_GRAPH_WIDTH; j++)
		{
			if (aSpectrumIn[j] >= (FFT_SPECTRUM_GRAPH_HEIGHT - i))
			{
				aSpectrumOut[(i * (FFT_SPECTRUM_GRAPH_WIDTH / GLCD_FONT_WIDTH)) + (j / GLCD_FONT_WIDTH)] |= 0x01 << (GLCD_FONT_WIDTH - 1 - (j % GLCD_FONT_WIDTH));
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// draws the spectrum
void drawGraphicalSpectrum(uint8_t *aSpectrum, uint8_t graphTopX, uint8_t graphTopY)
{
	uint8_t i, j;

	// draw bitmap
	for (i = 0; i < FFT_SPECTRUM_GRAPH_HEIGHT; i++)
	{
		GLCD_graphicGoTo(graphTopX, graphTopY + i);

		for (j = 0; j < (FFT_SPECTRUM_GRAPH_WIDTH / GLCD_FONT_WIDTH); j++)
		{
			GLCD_writeDisplayData(aSpectrum[(i * (FFT_SPECTRUM_GRAPH_WIDTH / GLCD_FONT_WIDTH)) + j]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// draws the spectrum grid
void drawSpectrumGrid(uint8_t graphTopX, uint8_t graphTopY)
{
	GLCD_drawBox(graphTopX, graphTopY + FFT_SPECTRUM_GRAPH_HEIGHT, graphTopX + FFT_SPECTRUM_GRAPH_WIDTH - 1, graphTopY + FFT_SPECTRUM_GRAPH_HEIGHT, 1);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// define CG-chars
void defineCGChars(void)
{
	// CG RAM
	uint8_t cgRAMChar[8];
	eeprom_read_block((void *)&cgRAMChar, (const void *)&cgROMChar80, 8);
	GLCD_defineCharacter(0x80, cgRAMChar);
	eeprom_read_block((void *)&cgRAMChar, (const void *)&cgROMChar81, 8);
	GLCD_defineCharacter(0x81, cgRAMChar);
	eeprom_read_block((void *)&cgRAMChar, (const void *)&cgROMChar82, 8);
	GLCD_defineCharacter(0x82, cgRAMChar);
	eeprom_read_block((void *)&cgRAMChar, (const void *)&cgROMChar83, 8);
	GLCD_defineCharacter(0x83, cgRAMChar);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write constant text strings
void writeConstantTextStrings(void)
{
	uint8_t strArtist[STRLEN_TAGS] = STR_ARTIST;
	uint8_t strAlbum[STRLEN_TAGS] = STR_ALBUM;
	uint8_t strTrack[STRLEN_TAGS] = STR_TRACK;

	GLCD_textGoTo(0,0);
	GLCD_writeString(strTrack);
	GLCD_textGoTo(0,1);
	GLCD_writeString(strArtist);
	GLCD_textGoTo(0,2);
	GLCD_writeString(strAlbum);
	GLCD_textGoTo(10,4);
	GLCD_writeChar('/');
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write play status chars
void writePlayStatusChars(uint8_t playStatus)
{
	// play status
	GLCD_textGoTo(1,6);

	if (playStatus >= 0xA0)
	{
		switch (playStatus & 0x0F)
		{
			case SPI_MSG_STA_PLAY:
			{
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeDisplayData(0x81);
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				break;
			}
			case SPI_MSG_STA_PAUSE:
			{
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeDisplayData(0x82);
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				break;
			}
			case SPI_MSG_STA_STOP:
			{
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeDisplayData(0x83);
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				break;
			}
			case SPI_MSG_STA_FAST_REV:
			{
				GLCD_writeDisplayData(0x80);
				GLCD_writeDisplayData(0x80);
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				break;
			}
			case SPI_MSG_STA_FAST_FWD:
			{
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeDisplayData(0x81);
				GLCD_writeDisplayData(0x81);
				break;
			}
			default: // stop
			{
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				GLCD_writeDisplayData(0x83);
				GLCD_writeChar(' ');
				GLCD_writeChar(' ');
				break;
			}
		}
	}

	// shuffle status
	GLCD_textGoTo(1,3);

	switch (playStatus & 0xF0)
	{
		case SPI_MSG_STA_SHUFFLE_OFF:
		{
			GLCD_writeChar(' ');
			GLCD_writeChar(' ');
			GLCD_writeChar(' ');
			GLCD_writeChar('S');
			GLCD_writeChar('h');
			GLCD_writeChar('u');
			GLCD_writeChar('f');
			GLCD_writeChar('f');
			GLCD_writeChar('l');
			GLCD_writeChar('e');
			GLCD_writeChar(' ');
			GLCD_writeChar('O');
			GLCD_writeChar('f');
			GLCD_writeChar('f');
			break;
		}

		case SPI_MSG_STA_SHUFFLE_TRACK:
		{
			GLCD_writeChar(' ');
			GLCD_writeChar('S');
			GLCD_writeChar('h');
			GLCD_writeChar('u');
			GLCD_writeChar('f');
			GLCD_writeChar('f');
			GLCD_writeChar('l');
			GLCD_writeChar('e');
			GLCD_writeChar(' ');
			GLCD_writeChar('T');
			GLCD_writeChar('r');
			GLCD_writeChar('a');
			GLCD_writeChar('c');
			GLCD_writeChar('k');
			break;
		}

		case SPI_MSG_STA_SHUFFLE_ALBUM:
		{
			GLCD_writeChar(' ');
			GLCD_writeChar('S');
			GLCD_writeChar('h');
			GLCD_writeChar('u');
			GLCD_writeChar('f');
			GLCD_writeChar('f');
			GLCD_writeChar('l');
			GLCD_writeChar('e');
			GLCD_writeChar(' ');
			GLCD_writeChar('A');
			GLCD_writeChar('l');
			GLCD_writeChar('b');
			GLCD_writeChar('u');
			GLCD_writeChar('m');
			break;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write scrolling text string
void writeTextStringScroll(uint8_t *p_Str, uint8_t iStrDispLen, uint8_t iStrLen)
{
	uint8_t i = 0;
	uint8_t j = 0;

	for (i = 0; i < iStrDispLen; i++)
	{
		if (i < p_Str[iStrLen - 2])
		{
			j =  (i + p_Str[iStrLen - 1]) % (p_Str[iStrLen - 2] + 3);
			if (j < p_Str[iStrLen - 2])
			{
				GLCD_writeChar(p_Str[j]);
			}
			else
			{
				switch (j % p_Str[iStrLen - 2])
				{
					case 0: GLCD_writeChar(SPI_EMPTY_CHAR); break;
					case 1: GLCD_writeChar(SPI_SEP_CHAR); break;
					case 2: GLCD_writeChar(SPI_EMPTY_CHAR); break;
				}
			}
		}
		else
		{
			GLCD_writeChar(SPI_EMPTY_CHAR);
		}
	}
	if (p_Str[iStrLen - 2] > iStrDispLen)
	{
		p_Str[iStrLen - 1] = (p_Str[iStrLen - 1] + 1) % (p_Str[iStrLen - 2] + 3);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write scrolling text string, right aligned
void writeTextStringFixed(uint8_t *p_Str, uint8_t iStrDispLen, uint8_t iStrLen)
{
	uint8_t i = 0;

	for (i = 0; i < (iStrDispLen - p_Str[iStrLen - 2]); i++)
	{
		GLCD_writeChar(SPI_EMPTY_CHAR);
	}
	for (i = 0; i < p_Str[iStrLen - 2]; i++)
	{
		GLCD_writeChar(p_Str[i]);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// write variable text strings
void writeVariableTextStrings(uint8_t flStrings)
{
	if (flStrings & WRITE_STRINGS)
	{
		// strTrack
		GLCD_textGoTo(9,0);
		writeTextStringScroll(*p_SPI_strTrack, SPI_STRDISPLEN_TRACK, SPI_STRLEN_TRACK);
	
		// strArtist
		GLCD_textGoTo(9,1);
		writeTextStringScroll(*p_SPI_strArtist, SPI_STRDISPLEN_ARTIST, SPI_STRLEN_ARTIST);

		// strAlbum
		GLCD_textGoTo(9,2);
		writeTextStringScroll(*p_SPI_strAlbum, SPI_STRDISPLEN_ALBUM, SPI_STRLEN_ALBUM);

		// strGenre
		// not used
/*
		GLCD_textGoTo(1,3);
		writeTextStringScroll(*p_SPI_strGenre, SPI_STRDISPLEN_GENRE, SPI_STRLEN_GENRE);
*/
	}

	if (flStrings & WRITE_TIME)
	{
		// strTrackNrCur
		GLCD_textGoTo(6,4);
		writeTextStringFixed(*p_SPI_strTrackNrCur, SPI_STRDISPLEN_TRACKNR_CUR, SPI_STRLEN_TRACKNR_CUR);

		// strTrackNrTot
		GLCD_textGoTo(11,4);
		writeTextStringFixed(*p_SPI_strTrackNrTot, SPI_STRDISPLEN_TRACKNR_TOT, SPI_STRLEN_TRACKNR_TOT);

		// strTimePlayed
		GLCD_textGoTo(2,5);
		writeTextStringFixed(*p_SPI_strTimePlayed, SPI_STRDISPLEN_TIME_PLAYED, SPI_STRLEN_TIME_PLAYED);

		// strTimeRemain
		GLCD_textGoTo(9,5);
		writeTextStringFixed(*p_SPI_strTimeRemain, SPI_STRDISPLEN_TIME_REMAIN, SPI_STRLEN_TIME_REMAIN);

		// strTimeTotal
		GLCD_textGoTo(9,6);
		writeTextStringFixed(*p_SPI_strTimeTotal, SPI_STRDISPLEN_TIME_TOTAL, SPI_STRLEN_TIME_TOTAL);

		// play status
		writePlayStatusChars((*p_SPI_strPlayStatus)[0]);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// init arrays, draw spectrum grid
void fftInit(void)
{
	// init arrays
	initArray_8bit(aSpectrumConvL, 0, FFT_SPECTRUM_GRAPH_WIDTH);
	initArray_8bit(aSpectrumConvR, 0, FFT_SPECTRUM_GRAPH_WIDTH);

	// draw spectrum grid
	drawSpectrumGrid(FFT_SPECTRUM_GRAPH_X_L, FFT_SPECTRUM_GRAPH_Y_L);
	drawSpectrumGrid(FFT_SPECTRUM_GRAPH_X_R, FFT_SPECTRUM_GRAPH_Y_R);

	// define CG-chars
	defineCGChars();
	// write constant text strings
	writeConstantTextStrings();
}

////////////////////////////////////////////////////////////////////////////////////////////////
// init variables for strings
void initStrings(void)
{
	// get pointers of SPI-strings
	p_SPI_strArtist			= SPI_getPointer_strArtist();
	p_SPI_strAlbum			= SPI_getPointer_strAlbum();
	p_SPI_strTrack			= SPI_getPointer_strTrack();
	p_SPI_strGenre			= SPI_getPointer_strGenre();
	p_SPI_strTrackNrCur		= SPI_getPointer_strTrackNrCur();
	p_SPI_strTrackNrTot		= SPI_getPointer_strTrackNrTot();
	p_SPI_strTimePlayed		= SPI_getPointer_strTimePlayed();
	p_SPI_strTimeRemain		= SPI_getPointer_strTimeRemain();
	p_SPI_strTimeTotal		= SPI_getPointer_strTimeTotal();
	p_SPI_strPlayStatus		= SPI_getPointer_strPlayStatus();

	// init string arrays
	initSPIString(*p_SPI_strArtist, SPI_EMPTY_CHAR, SPI_STRLEN_ARTIST);
	initSPIString(*p_SPI_strAlbum, SPI_EMPTY_CHAR, SPI_STRLEN_ALBUM);
	initSPIString(*p_SPI_strTrack, SPI_EMPTY_CHAR, SPI_STRLEN_TRACK);
	initSPIString(*p_SPI_strGenre, SPI_EMPTY_CHAR, SPI_STRLEN_GENRE);
	initSPIString(*p_SPI_strTrackNrCur, SPI_EMPTY_CHAR, SPI_STRLEN_TRACKNR_CUR);
	initSPIString(*p_SPI_strTrackNrTot, SPI_EMPTY_CHAR, SPI_STRLEN_TRACKNR_TOT);
	initSPIString(*p_SPI_strTimePlayed, SPI_EMPTY_CHAR, SPI_STRLEN_TIME_PLAYED);
	initSPIString(*p_SPI_strTimeRemain, SPI_EMPTY_CHAR, SPI_STRLEN_TIME_REMAIN);
	initSPIString(*p_SPI_strTimeTotal, SPI_EMPTY_CHAR, SPI_STRLEN_TIME_TOTAL);
	initSPIString(*p_SPI_strPlayStatus, SPI_EMPTY_CHAR, SPI_STRLEN_PLAY_STATUS);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// does sampling, fft transform, spectrum generation and spectrum draw
void fftFullProcess(void)
{
	// capture samples
	captureSamples(aSamplesL, FFT_LEFT);
	captureSamples(aSamplesR, FFT_RIGHT);

	// calculate fourier
	fft_input(aSamplesL, aSamplesBflyBuff);
	fft_execute(aSamplesBflyBuff);
	fft_output(aSamplesBflyBuff, aSpectrumFull);

	// generate spectrum
	generateOutputSpectrum(aSpectrumFull, aSpectrumConvL);
	generateGraphicalSpectrum(aSpectrumConvL, aSpectrumGraphL);

	// calculate fourier
	fft_input(aSamplesR, aSamplesBflyBuff);
	fft_execute(aSamplesBflyBuff);
	fft_output(aSamplesBflyBuff, aSpectrumFull);

	// generate spectrum
	generateOutputSpectrum(aSpectrumFull, aSpectrumConvR);
	generateGraphicalSpectrum(aSpectrumConvR, aSpectrumGraphR);

	// draw spectrum
	drawGraphicalSpectrum(aSpectrumGraphL, FFT_SPECTRUM_GRAPH_X_L, FFT_SPECTRUM_GRAPH_Y_L);
	drawGraphicalSpectrum(aSpectrumGraphR, FFT_SPECTRUM_GRAPH_X_R, FFT_SPECTRUM_GRAPH_Y_R);
}

////////////////////////////////////////////////////////////////////////////////////////////////
// main
int main(void)
{
	// disable all interrupts
	cli();

	// check counter flags
	uint8_t flTimer = 0;

	// timer init
	tmrInitGeneralCounter();

	// set LPF clock
	setLPFClock();

	// initalize LCD
	GLCD_initializeDisplay();

	// init SPI
	SPI_init();

	// init strings
	initStrings();

	// init FFT
	fftInit();

	// enable all interrupts
	sei();

	// start counter
	ENABLE_TIMER1A_INTERRUPT();

	while(1)
	{
		// look if a counter has been reached
		flTimer = tmrReadGeneralCounterFlags();

#ifdef TMR_GENERAL_FL1	// 1 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL1)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL1);
		}
#endif

#ifdef TMR_GENERAL_FL2	// 2 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL2)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL2);
		}
#endif

#ifdef TMR_GENERAL_FL3	// 4 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL3)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL3);

			fftFullProcess();
//			SPI_processReceivedMessages();
		}
#endif

#ifdef TMR_GENERAL_FL4	// 8 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL4)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL4);

			writeVariableTextStrings(WRITE_TIME);
		}
#endif

#ifdef TMR_GENERAL_FL5	// 16 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL5)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL5);

			writeVariableTextStrings(WRITE_STRINGS);
		}
#endif

#ifdef TMR_GENERAL_FL6	// 32 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL6)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL6);
		}
#endif

#ifdef TMR_GENERAL_FL7	// 64 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL7)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL7);
		}
#endif

#ifdef TMR_GENERAL_FL8	// 128 x TMR_GENERAL_DELAY
		if (flTimer & TMR_GENERAL_FL8)
		{
			tmrWriteGeneralCounterFlags(flTimer &= ~TMR_GENERAL_FL8);
		}
#endif
	}

	return -1;
}
