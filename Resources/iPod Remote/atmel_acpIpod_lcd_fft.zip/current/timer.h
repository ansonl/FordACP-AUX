/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// enable and disable timer1
#define ENABLE_TIMER1A_INTERRUPT()  	(TIMSK1 |= (1<< OCIE1A))
#define DISABLE_TIMER1A_INTERRUPT()		(TIMSK1 &= ~(1<< OCIE1A))

// general delay in ms
#define TMR_GENERAL_DELAY				20
#define TMR_GENERAL_DELAY_TICKS			((uint32_t)((uint32_t)F_CPU/(1024000 / TMR_GENERAL_DELAY)))

// timer multipliers for general flags
// timer general flags
//	#define TMR_GENERAL_MP1					1
//	#define TMR_GENERAL_FL1					0x01
//	#define TMR_GENERAL_MP2					2
//	#define TMR_GENERAL_FL2					0x02
#define TMR_GENERAL_MP3					4
#define TMR_GENERAL_FL3					0x04
#define TMR_GENERAL_MP4					8
#define TMR_GENERAL_FL4					0x08
#define TMR_GENERAL_MP5					16
#define TMR_GENERAL_FL5					0x10
//	#define TMR_GENERAL_MP6					32
//	#define TMR_GENERAL_FL6					0x20
//	#define TMR_GENERAL_MP7					64
//	#define TMR_GENERAL_FL7					0x40
//	#define TMR_GENERAL_MP8					128
//	#define TMR_GENERAL_FL8					0x80

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

void tmrInitGeneralCounter(void);
uint8_t tmrReadGeneralCounterFlags(void);
void tmrWriteGeneralCounterFlags(uint8_t);
