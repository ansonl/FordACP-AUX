/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "spiComm.h"

// status of the SPI communication
uint8_t SPI_RXStatus;

// RX data
uint8_t SPI_RXTotalBytes;
uint8_t SPI_RXActiveData;
uint8_t SPI_RXCurrentData;
uint8_t SPI_RXData[SPI_DATA_BUFFERS][SPI_MAX_MSG_LENGTH];
uint8_t SPI_RXDataCount[SPI_DATA_BUFFERS];
uint8_t SPI_RXChecksum[SPI_DATA_BUFFERS];
uint8_t SPI_RXChecksumExpected[SPI_DATA_BUFFERS];

// processing data
uint8_t SPI_procRXData;

// string variables
uint8_t SPI_strArtist[SPI_STRLEN_ARTIST];
uint8_t SPI_strAlbum[SPI_STRLEN_ALBUM];
uint8_t SPI_strTrack[SPI_STRLEN_TRACK];
uint8_t SPI_strGenre[SPI_STRLEN_GENRE];
uint8_t SPI_strTrackNrCur[SPI_STRLEN_TRACKNR_CUR];
uint8_t SPI_strTrackNrTot[SPI_STRLEN_TRACKNR_TOT];
uint8_t SPI_strTimePlayed[SPI_STRLEN_TIME_PLAYED];
uint8_t SPI_strTimeRemain[SPI_STRLEN_TIME_REMAIN];
uint8_t SPI_strTimeTotal[SPI_STRLEN_TIME_TOTAL];
uint8_t SPI_strPlayStatus[SPI_STRLEN_PLAY_STATUS];

////////////////////////////////////////////////
// interrupt handling
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// SPI interrupt
ISR(SIG_SPI)
{
	uint8_t rxByte = SPDR;

	// increment total RX bytes
	SPI_RXTotalBytes++;

	// process the received data
	SPI_processReceivedData(rxByte);
}

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// initialize SPI slave
void SPI_initSlave(void)
{
	// set MISO as output, all others input
	SPI_DDR |= (1 << SPI_MISO);

	// enable SPI and SPI interrupt
	SPCR = ((1<<SPE) | (1<<SPIE));
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the SPI variables

////////////////////////////////////////////////////////////////////////////////////////////////
// SPI_RXStatus
void SPI_resetRXStatus(void)
{
	SPI_RXStatus = SPI_RX_READY;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the RX data
void SPI_resetRXData(void)
{
	uint8_t i, j;

	SPI_RXTotalBytes = 0;
	SPI_RXActiveData = 0x00;
	SPI_RXCurrentData = 0;

	for (i = 0; i < SPI_DATA_BUFFERS; i++)
	{
		// reset the counters
		SPI_RXDataCount[i] = 0;

		// reset the checksums
		SPI_RXChecksum[i] = 0;
		SPI_RXChecksumExpected[i] = 0;

		for (j = 0; j < SPI_MAX_MSG_LENGTH; j++)
		{
			SPI_RXData[i][j] = 0x00;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// reset the processing data
void SPI_resetProcData(void)
{
	SPI_procRXData = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// general initialization
void SPI_init(void)
{
	SPI_resetRXStatus();
	SPI_resetRXData();
	SPI_resetProcData();
	SPI_initSlave();
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return total RX bytes
uint8_t SPI_getTotalRXBytes(void)
{
	return SPI_RXTotalBytes;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// process the received SPI-data
void SPI_processReceivedData(uint8_t rxByte)
{
	switch (SPI_RXStatus)
	{
		case SPI_RX_READY:
		case SPI_RX_RECEIVING:
		{
			if (SPI_RXStatus == SPI_RX_READY)
			{
				// we expect a start byte
				if (rxByte != SPI_MSG_START)
				{
					// no valid SPI-message: start over again
					break;
				}
				else
				{
					// change status: receiving data
					SPI_RXStatus = SPI_RX_RECEIVING;

					// prepare buffer variables
					SPI_RXActiveData &= ~(1<<SPI_RXCurrentData);
					SPI_RXDataCount[SPI_RXCurrentData] = 0;
					SPI_RXChecksum[SPI_RXCurrentData] = 0;
					SPI_RXChecksumExpected[SPI_RXCurrentData] = 0;
				}
			}

			// process the data
			if (SPI_RXDataCount[SPI_RXCurrentData] < SPI_MAX_MSG_LENGTH)
			{
				// if received <= SPI_MAX_MSG_LENGTH bytes
				SPI_RXData[SPI_RXCurrentData][SPI_RXDataCount[SPI_RXCurrentData]] = rxByte;
				// increase the received data counter
				SPI_RXDataCount[SPI_RXCurrentData] += 1;

				// do we expect a checksum?
				if (SPI_RXChecksumExpected[SPI_RXCurrentData] == 1)
				{
					// we do: check checksum
					if (SPI_RXChecksum[SPI_RXCurrentData] == rxByte)
					{
						// valid SPI-message

						// set current data active data
						SPI_RXActiveData |= (1<<SPI_RXCurrentData);

						// next buffer to use
						SPI_RXCurrentData = (SPI_RXCurrentData + 1) % SPI_DATA_BUFFERS;

						// change status
						SPI_RXStatus = SPI_RX_MSG_COMPLETE;

						if (SPI_RXActiveData != SPI_FULL_RX_BUFFER)
						{
							SPI_RXStatus = SPI_RX_READY;
						}
						else
						{
							SPI_RXStatus = SPI_RX_BUFFERS_FULL;
						}

						// process the messages
						SPI_processReceivedMessages();
					}
					else
					{
						// no valid SPI-message: start over again

						// reset RX status
						SPI_resetRXStatus();
					}
				}
				else
				{
					// we don't: continue receiving
					if (rxByte == SPI_MSG_STOP)
					{
						// the following byte transmitted will be the checksum
						SPI_RXChecksumExpected[SPI_RXCurrentData] = 1;
					}
					else
					{
						// otherwise, it is a normal byte
						SPI_RXChecksum[SPI_RXCurrentData] += rxByte;
					}
				}
			}
			else
			{
				// if received > SPI_MAX_MSG_LENGTH bytes: message too long; start over again

				// reset RX status
				SPI_resetRXStatus();
			}

			break;
		}
		case SPI_RX_MSG_COMPLETE:			// should not come here
		case SPI_RX_BUFFERS_FULL:
		{
			// messages needs to be handled first; ignore data
			break;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// process received messages
void SPI_processReceivedMessages(void)
{
	// if we've got data in the RX buffer
	while (SPI_RXActiveData != SPI_EMPTY_RX_BUFFER)
	{
		uint8_t i = 0;

		// process data in SPI_RXData[SPI_procRXData]
		switch (SPI_RXData[SPI_procRXData][1])
		{
			case SPI_MSG_ARTIST:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					if (SPI_strArtist[i] != SPI_RXData[SPI_procRXData][i + 2])
					{
						SPI_strArtist[SPI_STRLEN_ARTIST - 1] = 0;	// reset position if new content
					}
					SPI_strArtist[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strArtist[SPI_STRLEN_ARTIST - 2] = i;	// length
				while (i < SPI_STRLEN_ARTIST - 2)
				{
					SPI_strArtist[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_ALBUM:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					if (SPI_strAlbum[i] != SPI_RXData[SPI_procRXData][i + 2])
					{
						SPI_strAlbum[SPI_STRLEN_ALBUM - 1] = 0;		// reset position if new content
					}
					SPI_strAlbum[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strAlbum[SPI_STRLEN_ALBUM - 2] = i;		// length
				while (i < SPI_STRLEN_ALBUM - 2)
				{
					SPI_strAlbum[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TRACKNAME:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					if (SPI_strTrack[i] != SPI_RXData[SPI_procRXData][i + 2])
					{
						SPI_strTrack[SPI_STRLEN_TRACK - 1] = 0;		// reset position if new content
					}
					SPI_strTrack[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTrack[SPI_STRLEN_TRACK - 2] = i;		// length
				while (i < SPI_STRLEN_TRACK - 2)
				{
					SPI_strTrack[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_GENRE:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strGenre[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strGenre[SPI_STRLEN_GENRE - 2] = i;		// length
				SPI_strGenre[SPI_STRLEN_GENRE - 1] = 0;		// position
				while (i < SPI_STRLEN_GENRE - 2)
				{
					SPI_strGenre[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TRACKNR_CUR:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strTrackNrCur[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTrackNrCur[SPI_STRLEN_TRACKNR_CUR - 2] = i;	// length
				SPI_strTrackNrCur[SPI_STRLEN_TRACKNR_CUR - 1] = 0;	// position
				while (i < SPI_STRLEN_TRACKNR_CUR - 2)
				{
					SPI_strTrackNrCur[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TRACKNR_TOT:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strTrackNrTot[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTrackNrTot[SPI_STRLEN_TRACKNR_TOT - 2] = i;	// length
				SPI_strTrackNrTot[SPI_STRLEN_TRACKNR_TOT - 1] = 0;	// position
				while (i < SPI_STRLEN_TRACKNR_TOT - 2)
				{
					SPI_strTrackNrTot[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TIME_PLAYED:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strTimePlayed[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTimePlayed[SPI_STRLEN_TIME_PLAYED - 2] = i;	// length
				SPI_strTimePlayed[SPI_STRLEN_TIME_PLAYED - 1] = 0;	// position
				while (i < SPI_STRLEN_TIME_PLAYED - 2)
				{
					SPI_strTimePlayed[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TIME_REMAIN:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strTimeRemain[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTimeRemain[SPI_STRLEN_TIME_REMAIN - 2] = i;	// length
				SPI_strTimeRemain[SPI_STRLEN_TIME_REMAIN - 1] = 0;	// position
				while (i < SPI_STRLEN_TIME_REMAIN - 2)
				{
					SPI_strTimeRemain[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_TIME_TOTAL:
			{
				while (SPI_RXData[SPI_procRXData][i + 2] != SPI_MSG_STOP)
				{
					SPI_strTimeTotal[i] = SPI_RXData[SPI_procRXData][i + 2];
					i++;
				}
				SPI_strTimeTotal[SPI_STRLEN_TIME_TOTAL - 2] = i;	// length
				SPI_strTimeTotal[SPI_STRLEN_TIME_TOTAL - 1] = 0;	// position
				while (i < SPI_STRLEN_TIME_TOTAL - 2)
				{
					SPI_strTimeTotal[i] = SPI_EMPTY_CHAR;
					i++;
				}

				break;
			}
			case SPI_MSG_PLAY_STATUS:
			{
//				only one byte
				SPI_strPlayStatus[i] = SPI_RXData[SPI_procRXData][i + 2];

				break;
			}
		}

		// clear the processed buffer bit
		SPI_RXActiveData &= ~(1<<SPI_procRXData);

		// next buffer to use
		SPI_procRXData = (SPI_procRXData + 1) % SPI_DATA_BUFFERS;

		// if we had a full buffer
		if (SPI_RXActiveData != SPI_FULL_RX_BUFFER)
		{
			if (SPI_RXStatus == SPI_RX_BUFFERS_FULL)
			{
				SPI_RXStatus = SPI_RX_READY;
			}
		}

	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return string pointers
uint8_t (*SPI_getPointer_strArtist(void))[SPI_STRLEN_ARTIST]
{
	return &SPI_strArtist;
}

uint8_t (*SPI_getPointer_strAlbum(void))[SPI_STRLEN_ALBUM]
{
	return &SPI_strAlbum;
}

uint8_t (*SPI_getPointer_strTrack(void))[SPI_STRLEN_TRACK]
{
	return &SPI_strTrack;
}

uint8_t (*SPI_getPointer_strGenre(void))[SPI_STRLEN_GENRE]
{
	return &SPI_strGenre;
}

uint8_t (*SPI_getPointer_strTrackNrCur(void))[SPI_STRLEN_TRACKNR_CUR]
{
	return &SPI_strTrackNrCur;
}

uint8_t (*SPI_getPointer_strTrackNrTot(void))[SPI_STRLEN_TRACKNR_TOT]
{
	return &SPI_strTrackNrTot;
}

uint8_t (*SPI_getPointer_strTimePlayed(void))[SPI_STRLEN_TIME_PLAYED]
{
	return &SPI_strTimePlayed;
}

uint8_t (*SPI_getPointer_strTimeRemain(void))[SPI_STRLEN_TIME_REMAIN]
{
	return &SPI_strTimeRemain;
}

uint8_t (*SPI_getPointer_strTimeTotal(void))[SPI_STRLEN_TIME_TOTAL]
{
	return &SPI_strTimeTotal;
}

uint8_t (*SPI_getPointer_strPlayStatus(void))[SPI_STRLEN_PLAY_STATUS]
{
	return &SPI_strPlayStatus;
}
