/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"

////////////////////////////////////////////////
// defines/constants/declarations
////////////////////////////////////////////////

// SPI port
#define SPI_PORT	PORTB
#define SPI_PIN		PINB
#define SPI_DDR 	DDRB

// signals
#define SPI_SS		PB4
#define SPI_MOSI	PB5
#define SPI_MISO	PB6
#define SPI_SCK		PB7

// status of the SPI communication
#define SPI_RX_READY			0
#define SPI_RX_RECEIVING		1
#define SPI_RX_MSG_COMPLETE		2
#define SPI_RX_BUFFERS_FULL		3

// number of data buffers for TX and RX
#define SPI_DATA_BUFFERS		2
#define SPI_EMPTY_RX_BUFFER		0x00
#define SPI_FULL_RX_BUFFER		0x03

/*
//	SPI-message:
	byte 0		start msg		(always 0x0F)
	byte 1		msg type		(0x10 - 0x1F)
	byte 2->n-2	msg content 	(0x20 - 0x9F (ASCII-values) / 0xA0-0xA4 (Play Status))
	byte n-1	stop msg		(always 0x00)
	byte n		chksum			sum of msg type + msg content bytes

//	msg type determines the type of content that follows
//	each message is presented as a full string (also numbers), only the play status contains 1 byte
//		strings can contain values 0x20-0x9F (ASCII-values; needed for compatibility with display)
//		play status can contain values 0xA0-0xA4

//	msg types:
	msg type	max length	content
	0x10		64			Artist
	0x11		64			Album
	0x12		64			Track Name
	0x13		32			Genre
	0x14		4			Track nr.
	0x15		4			Total track nr.
	0x16		6			Time played
	0x17		6			Time remaining
	0x18		6			Time total
	0x19		1			Play status:
								play	0xA0
								pause	0xA1
								stop	0xA2
								rew 	0xA3
								ff		0xA4
	0x1A->0x1F				future use
*/

// max. length of an SPI message: 68 bytes
#define SPI_MAX_MSG_LENGTH		68
// min. length of an SPI message: 3 bytes (start, stop, checksum)
#define SPI_MIN_MSG_LENGTH		3

// SPI msg control
#define SPI_MSG_START			0x0F
#define SPI_MSG_STOP			0x00

// SPI msg content
#define SPI_MSG_ARTIST			0x10
#define SPI_MSG_ALBUM			0x11
#define SPI_MSG_TRACKNAME		0x12
#define SPI_MSG_GENRE			0x13
#define SPI_MSG_TRACKNR_CUR		0x14
#define SPI_MSG_TRACKNR_TOT		0x15
#define SPI_MSG_TIME_PLAYED		0x16
#define SPI_MSG_TIME_REMAIN		0x17
#define SPI_MSG_TIME_TOTAL		0x18
#define SPI_MSG_PLAY_STATUS		0x19

// SPI msg - play status
#define SPI_MSG_STA_PLAY			0x00
#define SPI_MSG_STA_PAUSE			0x01
#define SPI_MSG_STA_STOP			0x02
#define SPI_MSG_STA_FAST_REV		0x03
#define SPI_MSG_STA_FAST_FWD		0x04
#define SPI_MSG_STA_SHUFFLE_OFF		0xA0
#define SPI_MSG_STA_SHUFFLE_TRACK	0xB0
#define SPI_MSG_STA_SHUFFLE_ALBUM	0xC0

#define SPI_EMPTY_CHAR			' '
#define SPI_SEP_CHAR			'~'

// SPI msg content - max lengths
#define SPI_STRLEN_ARTIST			67		// 64 bytes + \0 + length + position
#define SPI_STRLEN_ALBUM			67		// 64 bytes + \0 + length + position
#define SPI_STRLEN_TRACK			67		// 64 bytes + \0 + length + position
#define SPI_STRLEN_GENRE			35		// 32 bytes + \0 + length + position
#define SPI_STRLEN_TRACKNR_CUR		7		// 4 bytes + \0 + length + position
#define SPI_STRLEN_TRACKNR_TOT		7		// 4 bytes + \0 + length + position
#define SPI_STRLEN_TIME_PLAYED		9		// 6 bytes + \0 + length + position
#define SPI_STRLEN_TIME_REMAIN		9		// 6 bytes + \0 + length + position
#define SPI_STRLEN_TIME_TOTAL		9		// 6 bytes + \0 + length + position
#define SPI_STRLEN_PLAY_STATUS		1

// strings max. length shown on display
#define SPI_STRDISPLEN_ARTIST		30
#define SPI_STRDISPLEN_ALBUM		30
#define SPI_STRDISPLEN_TRACK		30
#define SPI_STRDISPLEN_GENRE		14
#define SPI_STRDISPLEN_TRACKNR_CUR	4
#define SPI_STRDISPLEN_TRACKNR_TOT	4
#define SPI_STRDISPLEN_TIME_PLAYED	6
#define SPI_STRDISPLEN_TIME_REMAIN	6
#define SPI_STRDISPLEN_TIME_TOTAL	6

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

void SPI_initSlave(void);

void SPI_resetRXStatus(void);
void SPI_resetRXData(void);
void SPI_resetProcData(void);
void SPI_init(void);

uint8_t SPI_getTotalRXBytes(void);

void SPI_processReceivedData(uint8_t);
void SPI_processReceivedMessages(void);

uint8_t (*SPI_getPointer_strArtist(void))[SPI_STRLEN_ARTIST];
uint8_t (*SPI_getPointer_strAlbum(void))[SPI_STRLEN_ALBUM];
uint8_t (*SPI_getPointer_strTrack(void))[SPI_STRLEN_TRACK];
uint8_t (*SPI_getPointer_strGenre(void))[SPI_STRLEN_GENRE];
uint8_t (*SPI_getPointer_strTrackNrCur(void))[SPI_STRLEN_TRACKNR_CUR];
uint8_t (*SPI_getPointer_strTrackNrTot(void))[SPI_STRLEN_TRACKNR_TOT];
uint8_t (*SPI_getPointer_strTimePlayed(void))[SPI_STRLEN_TIME_PLAYED];
uint8_t (*SPI_getPointer_strTimeRemain(void))[SPI_STRLEN_TIME_REMAIN];
uint8_t (*SPI_getPointer_strTimeTotal(void))[SPI_STRLEN_TIME_TOTAL];
uint8_t (*SPI_getPointer_strPlayStatus(void))[SPI_STRLEN_PLAY_STATUS];
