/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// data port
#define GLCD_DATA_PORT						PORTC
#define GLCD_DATA_PIN						PINC
#define GLCD_DATA_DDR						DDRC

// control port
#define GLCD_CTRL_PORT						PORTD
#define GLCD_CTRL_PIN						PIND
#define GLCD_CTRL_DDR						DDRD

// control signals
#define GLCD_WR								PD7
#define GLCD_RD								PD2
#define GLCD_CE								PD4
#define GLCD_CD								PD3
#define GLCD_RESET							PD5
#define GLCD_FS								PD6

// display properties
#define GLCD_NUMBER_OF_LINES				64
#define GLCD_PIXELS_PER_LINE				240
#define GLCD_FONT_WIDTH_6					6
#define GLCD_FONT_WIDTH_8					8
#define GLCD_FONT_WIDTH						GLCD_FONT_WIDTH_6
#define GLCD_FONT_HEIGHT					8

#define GLCD_TEXT_AREA						(GLCD_PIXELS_PER_LINE / GLCD_FONT_WIDTH)
#define GLCD_GRAPHIC_AREA					(GLCD_PIXELS_PER_LINE / GLCD_FONT_WIDTH)
#define GLCD_TEXT_SIZE						(GLCD_TEXT_AREA * (GLCD_NUMBER_OF_LINES/8))
#define GLCD_GRAPHIC_SIZE					(GLCD_GRAPHIC_AREA * GLCD_NUMBER_OF_LINES)

#define GLCD_TEXT_HOME						0
#define GLCD_GRAPHIC_HOME					(GLCD_TEXT_HOME + GLCD_TEXT_SIZE)

// The OFFSET-register = 0x02, so external RAM is defined from 0x1000 - 0x17FF.
// Because we use ROM-mode, we can only use characters 0x80 - 0xFF.
// The address of the first character is 0x1000 + 0x80 x 8 (= 0x1400).
#define GLCD_OFFSET_REGISTER				2
#define GLCD_EXTERNAL_CG_HOME				((GLCD_OFFSET_REGISTER << 11) + 0x0400)

#define GLCD_ASCII_OFFSET					32

// display commands
#define T6963_SET_CURSOR_POINTER			0x21
#define T6963_SET_OFFSET_REGISTER			0x22
#define T6963_SET_ADDRESS_POINTER			0x24

#define T6963_SET_TEXT_HOME_ADDRESS			0x40
#define T6963_SET_TEXT_AREA					0x41
#define T6963_SET_GRAPHIC_HOME_ADDRESS		0x42
#define T6963_SET_GRAPHIC_AREA				0x43

#define T6963_MODE_OR						0x80
#define T6963_MODE_EXOR						0x81
#define T6963_MODE_AND						0x83
#define T6963_MODE_ATTR						0x84
#define T6963_MODE_ROM						0x80
#define T6963_MODE_RAM						0x88

#define T6963_DISPLAY_OFF					0x90
#define T6963_BLINK_ON						0x91
#define T6963_CURSOR_ON						0x92
#define T6963_TEXT_DISPLAY_ON				0x94
#define T6963_GRAPHIC_DISPLAY_ON			0x98				

#define T6963_CURSOR_1_LINE					0xA0
#define T6963_CURSOR_2_LINE					0xA1
#define T6963_CURSOR_3_LINE					0xA2
#define T6963_CURSOR_4_LINE					0xA3
#define T6963_CURSOR_5_LINE					0xA4
#define T6963_CURSOR_6_LINE					0xA5
#define T6963_CURSOR_7_LINE					0xA6
#define T6963_CURSOR_8_LINE					0xA7

#define T6963_SET_DATA_AUTO_WRITE			0xB0
#define T6963_SET_DATA_AUTO_READ			0xB1
#define T6963_AUTO_RESET					0xB2

#define T6963_DATA_WRITE_AND_INCREMENT		0xC0
#define T6963_DATA_READ_AND_INCREMENT		0xC1
#define T6963_DATA_WRITE_AND_DECREMENT		0xC2
#define T6963_DATA_READ_AND_DECREMENT		0xC3
#define T6963_DATA_WRITE_AND_NONVARIALBE	0xC4
#define T6963_DATA_READ_AND_NONVARIABLE		0xC5

#define T6963_SCREEN_PEEK					0xE0
#define T6963_SCREEN_COPY					0xE8

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

void GLCD_delay(void);

uint8_t GLCD_checkStatus(void);
void GLCD_writeCommand(uint8_t);
void GLCD_writeData(uint8_t);
uint8_t GLCD_readData(void);

void GLCD_setAddressPointer(uint16_t);
void GLCD_writeDisplayData(uint8_t);

void GLCD_initializeInterface(void);
void GLCD_initializeMemory(void);
void GLCD_initializeDisplay(void);

void GLCD_clearCGMemory(void);
void GLCD_clearTextMemory(void);
void GLCD_clearGraphicMemory(void);

void GLCD_defineCharacter(uint8_t, uint8_t *);

void GLCD_writeChar(uint8_t c);
void GLCD_writeString(uint8_t *);

void GLCD_cursorGoTo(uint8_t x, uint8_t y);
void GLCD_textGoTo(uint8_t x, uint8_t y);
void GLCD_graphicGoTo(uint8_t x, uint8_t y);

void GLCD_putPixel(uint8_t, uint8_t, uint8_t);
void GLCD_drawBox(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
