/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "common.h"
#include "t6963c.h"
#include "ffft.h"
#include "timer.h"
#include "spiComm.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

// FFT-related
#define FFT_SAMPLECOUNT					FFT_N
#define FFT_SPECTRUMCOUNT				(FFT_N / 2)
#define FFT_LEFT						0
#define FFT_RIGHT						1

#define FFT_SPECTRUM_GRAPH_WIDTH		60		// dividable by GLCD_FONT_WIDTH
#define FFT_SPECTRUM_GRAPH_HEIGHT		24		// dividable by GLCD_FONT_HEIGHT
#define FFT_SPECTRUM_GRAPH_X_L			108		// dividable by GLCD_FONT_WIDTH
#define FFT_SPECTRUM_GRAPH_Y_L			28
#define FFT_SPECTRUM_GRAPH_X_R			174		// dividable by GLCD_FONT_WIDTH
#define FFT_SPECTRUM_GRAPH_Y_R			28

#define FFT_SPECTRUM_GRAPH_BYTECOUNT	((FFT_SPECTRUM_GRAPH_WIDTH / GLCD_FONT_WIDTH) * FFT_SPECTRUM_GRAPH_HEIGHT)

// found experimentally:
#define FFT_SPECTRUM_CALC_GRAPH_OFFSET	2		// spectrum bands not to count in output spectrum
//#define FFT_SPECTRUM_CALC_DIV_FACT		5		// bit shifts for calculation from 16-bit value to FFT_GRID_HEIGHT
//#define FFT_SPECTRUM_CALC_OFFSET		32		// subtract offset from 16-bit value

// own characters for CG
uint8_t EEMEM cgROMChar80[8] = {0x02, 0x06, 0x0E, 0x1E, 0x0E, 0x06, 0x02, 0x00};	// <|
uint8_t EEMEM cgROMChar81[8] = {0x10, 0x18, 0x1C, 0x1E, 0x1C, 0x18, 0x10, 0x00};	// |>
uint8_t EEMEM cgROMChar82[8] = {0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x00};	// ||
uint8_t EEMEM cgROMChar83[8] = {0x00, 0x1F, 0x1F, 0x1F, 0x1F, 0x1F, 0x00, 0x00};	// []

// constant strings; should have length of STRLEN_TAGS
#define STRLEN_TAGS		10
#define STR_ARTIST		" ARTIST: \0"
#define STR_ALBUM		"  ALBUM: \0"
#define STR_TRACK		"  TRACK: \0"

#define WRITE_TIME		0x01
#define WRITE_STRINGS	0x02
