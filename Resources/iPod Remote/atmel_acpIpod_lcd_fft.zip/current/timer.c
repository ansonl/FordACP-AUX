/*
** *************************************************************************
**
** Copyright (C) 2008 by Stephan Orban <stephan.orban@telenet.be>
**
** Credits go to:
**   Andrew Hammond for his Yampp3/USB MP3 player with ACP protocol support
**   Simon J Fisher for cracking the ACP-protocol
**   Radoslaw Kwiecien for his T6963 LCD Library: <http://en.radzio.dxp.pl/t6963/>
**   the iPod Linux website for info on the iPod: <http://www.ipodlinux.org>
**
** You should read the REFERENCS.TXT file for a complete list of references.
**
** *************************************************************************
**
** This file is part of the ACP-IPOD-project.
**
** The ACP-IPOD-project is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License as
** published by the Free Software Foundation; either version 3 of the
** License, or (at your option) any later version.
**
** The ACP-IPOD-project is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
** *************************************************************************
*/

////////////////////////////////////////////////
// includes
////////////////////////////////////////////////

#include "timer.h"

////////////////////////////////////////////////
// defines/constants
////////////////////////////////////////////////

#ifdef TMR_GENERAL_FL1
uint8_t tmrGeneralCounter1 = 0;
#endif

#ifdef TMR_GENERAL_FL2
uint8_t tmrGeneralCounter2 = 0;
#endif

#ifdef TMR_GENERAL_FL3
uint8_t tmrGeneralCounter3 = 0;
#endif

#ifdef TMR_GENERAL_FL4
uint8_t tmrGeneralCounter4 = 0;
#endif

#ifdef TMR_GENERAL_FL5
uint8_t tmrGeneralCounter5 = 0;
#endif

#ifdef TMR_GENERAL_FL6
uint8_t tmrGeneralCounter6 = 0;
#endif

#ifdef TMR_GENERAL_FL7
uint8_t tmrGeneralCounter7 = 0;
#endif

#ifdef TMR_GENERAL_FL8
uint8_t tmrGeneralCounter8 = 0;
#endif

uint8_t tmrGeneralFlags = 0;

////////////////////////////////////////////////
// interrupt handling
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// counter 1A interrupt
ISR(SIG_OUTPUT_COMPARE1A)
{
	// clear counter register
	TCNT1 = 0;

	// increase the counters
	// check if we need to set a flag
#ifdef TMR_GENERAL_FL1
	tmrGeneralCounter1++;
	if (tmrGeneralCounter1 == TMR_GENERAL_MP1) { tmrGeneralFlags |= TMR_GENERAL_FL1; tmrGeneralCounter1 = 0;};
#endif

#ifdef TMR_GENERAL_FL2
	tmrGeneralCounter2++;
	if (tmrGeneralCounter2 == TMR_GENERAL_MP2) { tmrGeneralFlags |= TMR_GENERAL_FL2; tmrGeneralCounter2 = 0;};
#endif

#ifdef TMR_GENERAL_FL3
	tmrGeneralCounter3++;
	if (tmrGeneralCounter3 == TMR_GENERAL_MP3) { tmrGeneralFlags |= TMR_GENERAL_FL3; tmrGeneralCounter3 = 0;};
#endif

#ifdef TMR_GENERAL_FL4
	tmrGeneralCounter4++;
	if (tmrGeneralCounter4 == TMR_GENERAL_MP4) { tmrGeneralFlags |= TMR_GENERAL_FL4; tmrGeneralCounter4 = 0;};
#endif

#ifdef TMR_GENERAL_FL5
	tmrGeneralCounter5++;
	if (tmrGeneralCounter5 == TMR_GENERAL_MP5) { tmrGeneralFlags |= TMR_GENERAL_FL5; tmrGeneralCounter5 = 0;};
#endif

#ifdef TMR_GENERAL_FL6
	tmrGeneralCounter6++;
	if (tmrGeneralCounter6 == TMR_GENERAL_MP6) { tmrGeneralFlags |= TMR_GENERAL_FL6; tmrGeneralCounter6 = 0;};
#endif

#ifdef TMR_GENERAL_FL7
	tmrGeneralCounter7++;
	if (tmrGeneralCounter7 == TMR_GENERAL_MP7) { tmrGeneralFlags |= TMR_GENERAL_FL7; tmrGeneralCounter7 = 0;};
#endif

#ifdef TMR_GENERAL_FL8
	tmrGeneralCounter8++;
	if (tmrGeneralCounter8 == TMR_GENERAL_MP8) { tmrGeneralFlags |= TMR_GENERAL_FL8; tmrGeneralCounter8 = 0;};
#endif
}

////////////////////////////////////////////////
// functions
////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
// init the general counter
void tmrInitGeneralCounter(void)
{
	TCCR1B = (1<<CS12) | (1<<CS10);					// prescaler = 1024

	TCNT1 = 0;										// clear counter register

	OCR1AH = (uint8_t)(TMR_GENERAL_DELAY_TICKS>>8);	// compare match value
	OCR1AL = (uint8_t)(TMR_GENERAL_DELAY_TICKS);

	TIFR1 |= (1 << OCF1A);							// clear compare flag
}

////////////////////////////////////////////////////////////////////////////////////////////////
// return counter flags
uint8_t tmrReadGeneralCounterFlags(void)
{
	return tmrGeneralFlags;							// return counter flags
}

////////////////////////////////////////////////////////////////////////////////////////////////
// set/reset counter flags
void tmrWriteGeneralCounterFlags(uint8_t tmrFlagsNew)
{
	tmrGeneralFlags = tmrFlagsNew;					// set/reset counter flags
}
