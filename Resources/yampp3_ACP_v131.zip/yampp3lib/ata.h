/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> and 
**			Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - low level support library
**
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS      initial public release
**
*********************************************************************** */

//----------------------------------------------------------------------------
// Constants...
//----------------------------------------------------------------------------

#define TRUE     1 
#define FALSE    0 
#define CTRL     0
#define CMD      1
#define DRIVE0   0


#define STANDBY	0
#define SLEEP	1
#define IDLE	2


 // Read/Write Select
#define DIOW 0
#define DIOR 1


// ATA status register bits

#define SR_BUSY		0x80
#define SR_DRDY		0x40
#define SR_DF		0x20
#define SR_DSC		0x10
#define SR_DRQ		0x08
#define SR_CORR		0x04
#define SR_IDX		0x02
#define SR_ERR		0x01

// ATA error register bits

#define ER_UNC		0x40
#define ER_MC		0x20
#define ER_IDNF		0x10
#define ER_MCR		0x08
#define ER_ABRT		0x04
#define ER_TK0NF	0x02
#define ER_AMNF		0x01




#define ATAPI_AltStat	0xEE		// Control Block Register, READ
#define ATAPI_DevCtrl	0xEE		// Control Block Register, WRITE

#define ATAPI_Data	0xF0		// Command Block Register, READ
#define ATAPI_ErrReg	0xF1		// Command Block Register, READ
#define ATAPI_IRQReason	0xF2		// Command Block Register, READ

#define ATA_Sector	0xF3
#define ATA_SectorCount 0xF2

#define ATAPI_CountLSB	0xF4		// Command Block Register, READ
#define ATAPI_CountMSB	0xF5		// Command Block Register, READ
#define ATAPI_DRVSelect	0xF6		// Command Block Register, READ
#define ATAPI_Stat	0xF7		// Command Block Register, READ

#define ATAPI_Feat	0xF1		// Command Block Register, WRITE
#define ATAPI_Cmd	0xF7		// Command Block Register, WRITE


#ifndef ATA_ASM




/* IDENTIFY data */

typedef struct _IDENTIFY_DATA {
	u16 GeneralConfiguration;			// 00 00
	u16 NumberOfCylinders;				// 02  1
	u16 Reserved1;						// 04  2
	u16 NumberOfHeads;					// 06  3
	u16 UnformattedBytesPerTrack;		// 08  4
	u16 UnformattedBytesPerSector;		// 0A  5
	u16 SectorsPerTrack;				// 0C  6
	u16 VendorUnique1[3];				// 0E  7-9
	u16 SerialNumber[10];				// 14  10-19
	u16 BufferType;						// 28  20
	u16 BufferSectorSize;				// 2A  21
	u16 NumberOfEccBytes;				// 2C  22
	u16 FirmwareRevision[4];			// 2E  23-26
    u16 ModelNumber[20];				// 36  27-46
    u08 MaximumBlockTransfer;			// 5E  47
	u08 VendorUnique2;					// 5F
    u16 DoubleWordIo;					// 60  48
    u16 Capabilities;					// 62  49
    u16 Reserved2;						// 64  50
    u08 VendorUnique3;					// 66  51
    u08 PioCycleTimingMode;				// 67
    u08 VendorUnique4;					// 68  52
    u08 DmaCycleTimingMode;				// 69
    u16 TranslationFieldsValid:1;		// 6A  53
    u16 Reserved3:15;
    u16 NumberOfCurrentCylinders;		// 6C  54
    u16 NumberOfCurrentHeads;			// 6E  55
    u16 CurrentSectorsPerTrack;			// 70  56
    u32 CurrentSectorCapacity;			// 72  57-58
    u16 CurrentMultiSectorSetting;		//     59
    u32 UserAddressableSectors;			//     60-61
    u16 SingleWordDMASupport : 8;		//     62
    u16 SingleWordDMAActive : 8;
    u16 MultiWordDMASupport : 8;		//     63
    u16 MultiWordDMAActive : 8;
    u16 AdvancedPIOModes : 8;			//     64
    u16 Reserved4 : 8;
    u16 MinimumMWXferCycleTime;			//     65
    u16 RecommendedMWXferCycleTime;		//     66
	u16 MinimumPIOCycleTime;			//     67
	u16 MinimumPIOCycleTimeIORDY;		//     68
    u16 Reserved5[2];					//     69-70
    u16 ReleaseTimeOverlapped;			//     71
    u16 ReleaseTimeServiceCommand;		//     72
    u16 MajorRevision;					//     73
    u16 MinorRevision;					//     74
    u16 Reserved6[50];					//     75-126
    u16 SpecialFunctionsEnabled;		//     127
    u16 Reserved7[128];					//     128-255
} IDENTIFY_DATA;


#define IDENTIFY_DATA_SIZE sizeof(IDENTIFY_DATA)


/* IDENTIFY capability bit definitions. */
#define IDENTIFY_CAPABILITIES_DMA_SUPPORTED 0x0100
#define IDENTIFY_CAPABILITIES_LBA_SUPPORTED 0x0200


/* IDENTIFY DMA timing cycle modes. */
#define IDENTIFY_DMA_CYCLES_MODE_0 0x00
#define IDENTIFY_DMA_CYCLES_MODE_1 0x01
#define IDENTIFY_DMA_CYCLES_MODE_2 0x02




//----------------------------------------------------------------------------
// Prototypes
//----------------------------------------------------------------------------


u08 ReadBYTE(u08 adr);
void WriteBYTE(u08 adr, u08 dat);
u08 IdentifyDrive(u08 *pBuffer);


//
// ASM functions
//
void ATA_SetDrive(u08 Drive);
u08  ATA_Read(  u32 lba, u08 numsectors, u08 *Buffer);
u08  ATA_Write(  u32 lba, u08 numsectors, u08 *Buffer);
u08  ATA_Read_USB(  u32 lba, u08 numsectors );
u08  ATA_Write_USB( u32 lba, u08 numsectors );

u08 ATA_ReadStat(void);
u08 ATA_WaitBusy(void);
u08 ATA_WaitReady(void);

#endif
