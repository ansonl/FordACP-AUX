/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> 
**
**
**  Yampp-3/USB - output formating routines
**
**  File usb.h
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS	initial public release
**
*********************************************************************** */

//
// Command block structures
//

typedef struct 
{
	u32 parm1;
	u32 parm2;
	u32 parm3;
} ucb_general;

typedef struct 
{
	u32 sector;
	u32 nsectors;
} ucb_sector_rw; 

typedef struct 
{
	u32 sector;
	u08 data;
} ucb_sector_fill; 


typedef struct 
{
	u08 left;
	u08 right;
} ucb_volume; 

typedef struct 
{
	u32 buffersize;
} ucb_buffer_info; 


typedef struct
{
	u32 command;
	union {
		ucb_general 		general;
		ucb_sector_rw 		sector_rw;
		ucb_sector_fill 	sector_fill;
		ucb_volume 			volume;
		ucb_buffer_info 	buffer_info;
	} data;
} usb_cmd_block;	// 16 bytes





//
// yampp device command codes

#define USB_TEST_POLL		0x5401
#define USB_ENTER_BOOT		0x5405

#define USB_EEPROM_READ		0x5411
#define USB_EEPROM_WRITE	0x5412

#define USB_SECTOR_READ		0x5301
#define USB_SECTOR_WRITE	0x5302
#define USB_SECTOR_FILL		0x5303
#define USB_IDENTIFY		0x5304

#define USB_PLAY		0x5310
#define USB_BUFFER		0x5311
#define USB_STOP		0x5312
#define USB_ENTER_LINK		0x5320	// YAPC link start
#define USB_EXIT_LINK		0x5321	// YAPC link end

#define USB_GETVOLUME		0x5601
#define USB_SETVOLUME		0x5602

#define USB_BUFFERINFO		0x5701



//
// Command return codes
//

#define ACK	6
#define NAK	15
#define UNK	9



//
// prototypes
//

void usb_response(u08 err);
void identify(usb_cmd_block *ucb);
void sectorread(usb_cmd_block *ucb);
void sectorfill(usb_cmd_block *ucb);
void sectorwrite(usb_cmd_block *ucb);
void bufferfill(usb_cmd_block *ucb);
void usb_handler(void);
