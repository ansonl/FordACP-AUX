/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> and 
**			Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - main header file
**
**  File yampp3_usb.h
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS	initial public release
**
*********************************************************************** */

#ifndef GCC_VERSION
 #define GCC_VERSION (__GNUC__ * 1000 + __GNUC_MINOR__)
#endif /* GCC_VERSION */

#if (GCC_VERSION < 3003)
 #error __Wrong compiler version. Use GCC 3.3 !___
#endif

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/signal.h>

#include <avr/wdt.h>
#include <avr/timer.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

#include "types.h"
#include "Constants.h"
#include "yampp3lib.h"
#include "mem.h"
#include "printf.h"
#include "yadl.h"
#include "usb.h"

#ifdef SATTELITE
 void Vlcd_clrscr(void);
 void lcd_clrline(u08 line);
 void Vlcd_gotoxy(u08 x, u08 y);
 void Vlcd_bar(u08 val, u08 len);
 void Vlcd_puts(char s[]);
 void Vlcd_progputs(char s[]);
 u08 Vlcd_logo(void);
 void Vlcd_invert(void);
 void Vlcd_normal(void);
 void Vlcd_wrdata(u08 data); 
 u08 Sattelite_init(void);
 void Send_state(u08 state);

 #define Vlcd_putchar(s)	uart_putchar(s)
 #define both_putchar(s)	uart_putchar(s)
 #define both_progputs(s)	Vlcd_progputs(s)
 #define Vlcd_data(data)	Vlcd_wrdata(data)
 #define Vlcd_contrast(contrast);
 #define uart_EOL();
#else

#define Send_state(state)

#ifdef GRAPH_LCD
 extern void Vlcd_putchar(u08 data);
 extern void Vlcd_gotoxy(u08 x, u08 y);
 extern void Vlcd_wrdata(u08 data);
 extern void Vlcd_puts(char s[]);
 extern void Vlcd_progputs(char s[]);
 extern void Vlcd_clrscr(void);
 extern void Vlcd_init(u08 cursor, u08 fnc, u16 xymax);
 extern void Vlcd_bar(u08 pos, u08 len);
 extern void Vlcd_invert(void);
 extern void Vlcd_normal(void);
 extern void Vlcd_contrast(u08 contrast);
 extern u08 Vlcd_logo(void);
#else
 #define Vlcd_putchar(s)	lcd_putchar(s)
 #define Vlcd_clrscr()		lcd_clrscr()
 #define Vlcd_gotoxy(x,y) 	lcd_gotoxy(x,y)
 #define Vlcd_puts(s) 		lcd_puts(s)
 #define Vlcd_progputs(s) 	lcd_progputs(s)
 #define Vlcd_init(a,b,c) 	lcd_init(a,b,c)
 #define Vlcd_data(d)		lcd_data(d)
 #define Vlcd_command(c)	lcd_command(c)
#endif //GRAPH
#endif //SATTELITE

#ifdef ENABLE_FORD_ACP
 void acp_handler(u08, u08, u08); 
 void acp_process(void);
 void acp_reset(void);
 void acp_txenable(u08);
 void acp_sendmsg(void);
 void acp_chksum_send(u08);
 void acp_displaytime(u08, u16, u16);
 void usb_hex(u08);
 void usb_string(u08[], u08);
 u08 BCD(u08);
 u08 plist_change(u08);
 u08 set_disc(YADL_PLAY_LIST_ENTRY *);
 u08 get_disc(void);
 u08 getIndex(void);
 void acp_nodisc(void);
 void acp_uart_init(u16);
#endif

u08 *SectorBuffer;

extern u08 *updbuf;
extern u08 *buffer1;

u08 nKeyTime;
u08 ir_standard;
u08 usb_link;

#define	EV_IDLE		0
#define	EV_PLAY		1
#define	EV_STOP		2
#define	EV_NEXT		3
#define	EV_PREV		4
#define	EV_NEXTPL	5	// next playlist
#define	EV_PREVPL	6	// prevous playlist
#define	EV_FFWD		7
#define	EV_FREW		8
#define	EV_BALANCE	9
#define	EV_MBASS	10	// old loudness or equalizer mode
#define	EV_RANDOM	11	// random on/off
#define	EV_REPEAT	12	// repeat mode
#define	EV_TIME		13	// time display (normal <-> remain)
#define	EV_INFO		14	// info about playlist, song, bitrate, ect.
#define	EV_UP		15	// volume or search UP
#define	EV_DOWN		16	// volume or search DOWN
#define	EV_PLAYLIST	17	// browse playlists
#define	EV_MENU		18	// Enter Menu
#define	EV_LDS		19	// loudness on/off from direct keyboard
#define	EV_PLAY_USB	20	// playing via USB
#define	EV_REMOTE_CFG	21	// setup remote codes
#define	EV_NUMBER	22	// number key detect
#define	EV_LASTEVENT	23	// for events count calculation

#define event_e	u08

#define STANDARDS_COUNT 5	// number of IR remote standards


// CONTROL CODES FOR YAMPP REMOTE DISPLAY (SATTELITE) COMMUNICATION
// START "SAT_CMD_MARKER" code

#define SAT_CMD_MARKER	0xfe	// SPECIAL COMMAND MARKER

#define SAT_CLRSCR	0x01	// no parameters
#define SAT_CLRLINE	0x02	// line number
#define SAT_GOTOXY	0x03	// x, y 
#define SAT_BAR		0x04	// pos, len - display progressbar on graph LCD 
#define SAT_VOLUME	0x05	// volume, MIN_VOLUME, NUM_VOL_STEPS
#define SAT_LOGO	0x06	// no parameters - display logo
#define SAT_INVERS	0x07	// no parameters - negative mode
#define SAT_NORMAL	0x08	// no parameters - normal mode
#define SAT_RAWDAT	0x09	// byte data - raw data for graphics LCD
#define SAT_LCDTYPE	0x10	// lcd type, xmax, ymax, contrast, options, vk1, vk2, ffk1, ffk2
#define SAT_EEPROM_WR	0x11	// start address H:L, data length H:L , datas...
#define SAT_STATE	0x12	// player state (stop, playing, pause...)
#define SAT_IRSTAND	0x13	// set ir standard
#define SAT_LINKHOLDER	0xff	// no parameters - for link up signalisation

#define STATE_UNFEF	0x00
#define STATE_STOP	0x01
#define STATE_PLAYING	0x02
#define STATE_PAUSED	0x03
#define STATE_IR_LEARN	0x04
#define STATE_IR_ENDL	0x05
#define STATE_ERROR	0x0f
#define STATE_MENU	0x10
#define STATE_PL_SELECT	0x20
#define STATE_SO_SELECT	0x30
#define STATE_INFO	0x40
#define STATE_RETURN	0xf0

event_e get_event(void);
void set_event(event_e e);
void send_sinewave_beeps(void);
void eeprom_ww(u16 address, u16 value);
void lcd_clrline(u08 line);

extern void control_handler(void);

extern u08 rec80_active(void);
extern u16 get_rec80(u08 std);
extern void setup_rem(void);
extern void rotary_init(void);
void next_song(u08 mode);
void next_playlist(void);
