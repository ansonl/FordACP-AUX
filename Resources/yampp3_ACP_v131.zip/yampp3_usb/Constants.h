/* ***********************************************************************
**
**  Copyright (C) 2002 	Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - Constants and options definition file
**
**  File Constants.c
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who   why
**
**  2002-09-01   1.0   MIS   initial public release
**  2002-11-10   1.1   MIS   added some constants for graphisc LCD
**  2003-10-06	 1.3   andyh added support for acp
**
*********************************************************************** */

// ************************************************************************
// *		WARNING !!!   WARNING !!!   WARNING !!!			  *
// * After recompilation, please check "yampp3_usb.bin" file size ! 	  *
// * This MUST BE LESS than 15360 bytes !!!				  *
// * If not - you overwrite the bootloader! - DO NOT TRY load to big file *
// ************************************************************************

// ************************************************************************
// *		WARNING !!!   WARNING !!!   WARNING !!!			  *
// *  Starting from version 1.30 of this firmware, for recompilation you  *
// *  must use AVR-GCC in version 3.3 !!!				  *
// ************************************************************************

#ifndef __CONST_H__
#define __CONST_H__

// Here is some constants are defined.

//============================================================================
// VS1001
//============================================================================
//
// Define F_VS1001 constant according to your VS1001 clock divided by 2000.
// Add 0x8000 if you use clock doubler.
#define F_VS1001	(6144 + 0x8000)			/* 12,288MHz x2 */
//#define F_VS1001	(12288 + 0x0000)		/* 24.576Mhz */

//#define OLD_VS1001

//============================================================================
// DEFINITION OF LCD ORGANIZATION AND VISUALISATION OPTIONS
//============================================================================
// Check code size after change LCD type!! This MUST BE LESS than 15360 bytes.
//

#define LCD_TYPE 	1		// 2x16 LCD
//#define LCD_TYPE 	2		// 2x20 LCD
//#define LCD_TYPE 	3		// 2x24 LCD
//#define LCD_TYPE 	4		// 2x40 LCD
//#define LCD_TYPE 	5		// 4x16 LCD
//#define LCD_TYPE 	6		// 4x20 LCD
//#define LCD_TYPE 	7		// Graphics LCD from Nokia GSM
//#define LCD_TYPE 	8		// 128x64 Graphics LCD

//----------------------------------------------------------------------------
// In case you need alternative scroll method - uncomment the following line
// By disabling this option you can save 22 bytes of code.
#define ALTERNATE_SCROLL

//----------------------------------------------------------------------------
// This constant defines speed of scroll's. Range is from 1 to 10, and
// lower value is faster.
#define SCROLL_SPEED		5

//----------------------------------------------------------------------------
// If you want additional playlist and song info - uncomment the following line
// By disabling this option you can save 314 bytes of code.
#define ENABLE_INFO

//----------------------------------------------------------------------------
// This constant defines contrast of Nokia LCD display. 
// Range is from 0x10 to 0x60.
#define GRAPHICS_LCD_CONTRAST	0x48

//----------------------------------------------------------------------------
// In case you need negative screen on Nokia LCD display
// - uncomment the following line
//#define LCD_NEGATIV

//----------------------------------------------------------------------------
// In case you need alternative progressbar style on Graphics LCD displays
// - uncomment the following line
//#define ALT_BAR_STYLE


//============================================================================
// YAMPP SATTELITE DISPLAY
//============================================================================
//
// In case you have Yampp Sattelite Display connected to yampp via RS232
// - uncomment the following line
//#define SATTELITE

// Events key definition for Sattelite - first is EV_PLAY, second is EV_STOP
// ect (for Events list see "yampp3_usb.h" file). A * chars mean not used.
// At second line you may define keys with the same function in short and
// longpress - eg. Volume keys. These definitions are not needed if 
// Rottary Controller is used.
// Characters from "A" to "O" for shortkeypress of key 1 to 16
// Characters from "a" to "o" for longkeypress of key 1 to 16
#define SAT_CONTROL1 	"ABCDEFcdIefJKLGHbaM*!*"
#define SAT_CONTROL2	"**************gh******"

// For complete the sattelite configuration - set designed LCD type,
// needed visualisation options, application and infrared options 
// and (if you need) enable the Rotary Switch control.


//============================================================================
// HDD OPTIONS
//============================================================================
//
// Enter here time (in seconds) to spindown yampp HDD after STOP command 
// (0 = dont'stop, 1200 max = about 20 minutes)
#define HDD_STANDBY_TIME 30

//----------------------------------------------------------------------------
// In case your disk very fast enter in idle mode and you hear sound dropout - 
// uncomment the following line
// By disabling this option you can save 34 bytes of code.
//#define FAST_IDLE_DISK

//============================================================================
// FORD ACP
//============================================================================
//
// Enabling this option will disable RS232 UART and SATELLITE display
// The UART is now used for RS485 9 bit data.
// If ACP_DEBUG is enabled you must have a terminal session established
// with the USB COM Port in order to view the ACP traffic else the yampp3
// will hang. 

#define ENABLE_FORD_ACP
//#define ACP_DEBUG

//============================================================================
// UART OPTIONS - Not used if Sattelite Display or Rotary Swith is enabled.
//============================================================================
//
// By disabling this option you can save about 1000 bytes of code.
//#define ENABLE_UART

//----------------------------------------------------------------------------
// In case you need uart progressbar - uncomment the following line
// By disabling this option you can save 40 bytes of code (if uart is enabled).
#define UART_PROGRESSBAR

//----------------------------------------------------------------------------
// In case you need uart song time displaying - uncomment the following line
// By disabling this option you can save 74 bytes of code (if uart is enabled).
//#define UART_SONGTIME

//----------------------------------------------------------------------------
// Uart control Evevts definition - first is EV_PLAY, second is EV_STOP ect...
// For Events list see "yampp3_usb.h" file.
#define UART_CHARS 	"gGnpsSfFabretiudlmwN#!"


//============================================================================
// Infra Red Controls
//============================================================================
//
// If you need some more codespace, you may disable this option, and set
// your remote protocol standard directly.
// By disabling this option you can save about 470 bytes of code.
#define AUTODETECT_STANDARD

//----------------------------------------------------------------------------
// Here please define your remote controller protocol.
// This option is needed only if AUTODETECT_STANDARD option is disabled.
// 0 - REC80, 1 - NEC80, 2 - SONY15, 3 - SONY12, 4 - RC5
#define REMOTE_STANDARD		1

//----------------------------------------------------------------------------
// In case you have a problems with volume keys - comment the following line.
#define ENABLE_AUTOREPEAT

//----------------------------------------------------------------------------
// In case you have a problems with double interpretted random, loudness
// and numerical keys - set following constants value to 2,3 or 4.
// Note:  Increase this value slow down AUTOREPEAT function too.
#define DOUBLE_TRAP 1

//----------------------------------------------------------------------------
// In case you need direct Playlist and Song number entering with remote
// number keys (in "Playlist" function) - uncomment the following line
// By disabling this option you can save 246 bytes of code.
#define NUMERICAL_KEYS


//============================================================================
// Local keys control and layout definitions -Not used if Sattelite is enabled
//============================================================================
//
// If you need player control only from four local keys - uncomment the
// following line
//#define FOUR_KEYS_CONTROL
//----------------------------------------------------------------------------
//
#ifndef FOUR_KEYS_CONTROL
//
// Here is local keys layout definitions for 8 keys control
//
// Shortpress
#define KBD_SHORT { EV_IDLE, EV_PLAY, EV_STOP,     EV_NEXT, EV_PREV, EV_NEXTPL, EV_PREVPL, EV_UP, EV_DOWN };
// Longpress
#define KBD_LONG  { EV_IDLE, EV_MENU, EV_PLAYLIST, EV_FFWD, EV_FREW, EV_RANDOM, EV_LDS,    EV_UP, EV_DOWN };
//
//
#else
//
//
// Here is local keys layout definitions for 4 keys control
//
// Shortpress
#define KBD_SHORT { EV_IDLE, EV_PLAY, EV_STOP,     EV_UP, EV_DOWN, EV_IDLE,EV_IDLE,EV_IDLE,EV_IDLE};
// Longpress
#define KBD_LONG  { EV_IDLE, EV_MENU, EV_PLAYLIST, EV_UP, EV_DOWN, EV_IDLE,EV_IDLE,EV_IDLE,EV_IDLE};
//
//
#endif

//
// This is my crazy keyboard layout :-)
//#define KBD_SHORT { EV_IDLE, EV_DOWN, EV_STOP,     EV_UP, EV_PREV, EV_PLAY, EV_NEXT, EV_PREVPL, EV_NEXTPL };
//#define KBD_LONG  { EV_IDLE, EV_DOWN, EV_PLAYLIST, EV_UP, EV_FREW, EV_MENU, EV_FFWD, EV_LDS,    EV_RANDOM };


//============================================================================
// ROTARY SWITCH CONTROL
//============================================================================
//
// In case you need control with Rotary Switch - uncomment the following line
//#define ROTTARY_CONTROL


//============================================================================
// APPLICATION
//============================================================================
//
// This constant defines minimum volume level - to decrease unnessesary
// steps in volume control
// note that 0 is max volume and 0xfe is minimum volume
#define MIN_VOLUME 	95

//----------------------------------------------------------------------------
// Number of volume steps 
#define NUM_VOL_STEPS	24

//----------------------------------------------------------------------------
// In case you need slow volume level ramp-up after startup the player
// - uncomment the following definition.
// By disabling this option you can save about 160 bytes of code.
//#define VOL_UP_RAMP

//----------------------------------------------------------------------------
// In case you can hear three power up beeps - uncomment the following line:
// By disabling this option you can save 140 bytes of code.
//#define PWR_BEEPS

//----------------------------------------------------------------------------
// In case you need start playing from saved position inside of song
// - uncomment the following definition
// For save current position you must power-off the yampp in PAUSED state.
// By disabling this option you can save 212 bytes of code.
#define SONGPOS_RESTORE

//----------------------------------------------------------------------------
// In case you need new "PREVOUS" key functionality (like normal CD players) -
// uncomment the following line:
#define NEW_PREW

//----------------------------------------------------------------------------
// In case you need direct playing via USB- uncomment the following definition
// Note: Current PC software not support this function
// By disabling this option you can save about 550 bytes of code.
//#define ENABLE_USB_PLAYING

//----------------------------------------------------------------------------
// CPU crystal frequency definition
//
#define F_CPU               7372800		// CPU speed 

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//
// Some checks and calculations - DON'T change it !
//

#define VOL_STEP	( (MIN_VOLUME + 1) / NUM_VOL_STEPS )


#ifdef SATTELITE
 #define UART_BAUD_RATE		19200      // SATTELITE baud rate
 #undef	 AUTODETECT_STANDARD 
 #undef  ENABLE_UART
 #undef  UART_PROGRESSBAR
 #undef  UART_SONGTIME
 #define AUTODETECT_STANDARD
#else
 #define UART_BAUD_RATE		115200     // normal UART baud rate
#endif

#ifdef ENABLE_FORD_ACP
 #undef  UART_BAUD_RATE
 #undef  SATTELITE
 #undef	 AUTODETECT_STANDARD 
 #undef  ENABLE_UART
 #undef  UART_PROGRESSBAR
 #undef  UART_SONGTIME
 #define AUTODETECT_STANDARD
 #define UART_BAUD_RATE 	9600		// Fords ACP baud rate
#endif

// UART Baud rate calculation 
#define UART_BAUD_SELECT       ((u32)((u32)F_CPU/(UART_BAUD_RATE*16L)-1))

#if HDD_STANDBY_TIME > 1200
 #error Invalid HDD_STANDBY_TIME !
#endif

#if F_VS1001 < 10000 || F_VS1001 > 65536
 #error Invalid F_VS1001 !
#endif

#if SCROLL_SPEED < 1 || SCROLL_SPEED > 10
 #error Invalid SCROLL_SPEED !
#endif

#ifndef ENABLE_UART
 #undef UART_PROGRESSBAR
 #undef UART_SONGTIME
#endif

#if (LCD_TYPE == 1)
 #define LCD_LINES 2
 #define LCD_LINE_LENGTH  16
#endif
#if (LCD_TYPE == 2)
 #define LCD_LINES 2
 #define LCD_LINE_LENGTH  20
#endif
#if (LCD_TYPE == 3)
 #define LCD_LINES 2
 #define LCD_LINE_LENGTH  24
#endif
#if (LCD_TYPE == 4)
 #define LCD_LINES 2
 #define LCD_LINE_LENGTH  40
#endif
#if (LCD_TYPE == 5)
 #define LCD_LINES 4
 #define LCD_LINE_LENGTH  16
#endif
#if (LCD_TYPE == 6)
 #define LCD_LINES 4
 #define LCD_LINE_LENGTH  20
#endif
#if (LCD_TYPE == 7)
 #define LCD_LINES 4
 #define LCD_LINE_LENGTH  14
 #define GRAPH_LCD
 #if GRAPHICS_LCD_CONTRAST < 0x10 || GRAPHICS_LCD_CONTRAST > 0x60
  #error Invalid GRAPHICS_LCD_CONTRAST !
 #endif
#endif
#if (LCD_TYPE == 8)
 #define LCD_LINES 6
 #define LCD_LINE_LENGTH  21
 #define GRAPH_LCD
#endif

#ifdef ROTTARY_CONTROL
 #undef  SAT_CONTROL1
 #undef  SAT_CONTROL2
 #undef  FOUR_KEYS_CONTROL
 #undef  ENABLE_UART
 #undef  UART_PROGRESSBAR
 #undef  UART_SONGTIME
 #define FOUR_KEYS_CONTROL

 // Evevts key definition for Sattelite - if you need use Rottary switch
 // Q is Rottary Left, R is Rottary Right Event
 #define SAT_CONTROL1 	"AB************QRba**!*"
 #define SAT_CONTROL2	"**********************"
#endif

#endif // __CONST_H__
