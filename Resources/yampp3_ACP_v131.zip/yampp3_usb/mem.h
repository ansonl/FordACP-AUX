/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> and 
**			Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - memory layout file
**
**  File mem.h
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS   initial public release
**
*********************************************************************** */

#ifndef __MEM_H__
#define __MEM_H__

// 32 k External RAM

#define EXTRAM_START		0x460
#define EXTRAM_END		0x7FFF	

#define SCROLL_LINE		0x0500	// length 128
#define ARTISTNAME_BUF		0x0580	// length 64
#define SONGNAME_BUF		0x05C0	// length 64
#define FAT_CACHE		0x0600	// length 512
#define PL_CACHE		0x0800	// length 512
#define SE_CACHE		0x0A00	// length 512
#define LO_CACHE		0x0C00	// length 1024
#define BACK_STEP_TAB		0x1000	// length max 1024 steps * 4B = 4096
#define RANDOM_TABLE		0x2000	// length max 4096 (0x1000) for 32768 songs limit
#define BBK_MEMORY		0x3000	// length 512
#define LANGTAB_MEMORY		0x3200	// length 256

// free from 0x3300 to 0x3fff

// define memory for the double buffers
// each buffer is 8k (16 sectors) long
// 
// buffer_1	0x4000 - 0x5FFF
// buffer_2	0x6000 - 0x7FFF

#define BUFFERSTART		0x4000
#define BUFFERSIZE		0x2000

#define Rev_Table ((u32*)BACK_STEP_TAB)
#define MAX_REV_STEPS	1024

#define RANDOM_TAB ((u08*)RANDOM_TABLE)

// EEPROM structure

#define EEPROM_VOLUME		0x010	// 1 byte - volume
#define EEPROM_AUTOPLAY		0x011	// 1 byte - autoplay flag
#define EEPROM_RANDOM		0x012  	// 1 byte
#define EEPROM_SONGPOS		0x013	// 2 bytes (* 7) - last song number
#define EEPROM_LOUDNESS		0x021  	// 1 byte
#define EEPROM_IRSTAND		0x022	// 1 byte - standard of remote codes
#define EEPROM_PLAYLIST		0x023	// 2 bytes (* 7) - last playlist number
#define EEPROM_REPEAT		0x031  	// 1 byte
#define EEPROM_TIME			0x032  	// 1 byte
#define EEPROM_BALANCE		0x033  	// 1 byte
#define EEPROM_STARTPOS		0x034	// 2 bytes - position inside song
#define EEPROM_DISC			0x036   // 1 byte - current 'disc'

#define EEPROM_RemCodes		0x038	// each code - 2 bytes
#define EEPROM_LOGO_S		0x0C6	// 4*84 + 2 bytes - small logo
#define EEPROM_LOGO_L		0x072	// 5*84 + 2 bytes - large logo

#endif //__MEM_H__
