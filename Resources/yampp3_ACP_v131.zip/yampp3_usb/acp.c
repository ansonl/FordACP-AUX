/* ***********************************************************************
**
**  Copyright (C) 2003  Andrew Hammond <andyh@mindcode.co.uk>
**
**   Special thanks to Simon J Fisher for cracking the ACP protocol
**   and supplying the original code this work is based on.
**   
**   Thanks also to Dez Ellis for his part in providing the CD Changer
**   and logging the protocol.
**
**  Yampp-3/USB - Ford ACP 'CD Changer' control
**
**  File acp.c
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2003-10-13   1.31   andyh    -initial public release

*/

#include <avr/interrupt.h>
#include "yampp3_usb.h"

#ifdef ENABLE_FORD_ACP

u08 acp_status;
u08 acp_rx[12];
u08 acp_tx[12];
u08 acp_rxindex;
u08 acp_txindex;
u08 acp_txsize;
u08 acp_timeout;
u08 acp_checksum;
u08 acp_retries;
u08 acp_mode;
u16 acp_ltimeout;
u08 isPlaying;
u08 bLoudness;
u08 bRandom;
u08 bFRSearch;

#define ACP_LISTEN  0
#define ACP_SENDACK 1
#define ACP_MSGREADY 2
#define ACP_WAITACK 3
#define ACP_SENDING 4

SIGNAL(SIG_UART0_RECV)	
{
	u08 eod;
	u08 ch;
	
	eod = (inp(UCSR0B) & _BV(RXB8));
    ch = inp(UDR0);
	
/*	FOR SOME REASON THE HU DOES NOT APPEAR TO SEND ACKS

	if (acp_status == ACP_WAITACK)
	{
		if (ch==0x06) // Received ACK, listen for new messages
		{
#ifdef ACP_DEBUG
			usb_string("ACK",3);
#endif
			acp_reset();
			return;
		}
	}
*/

	if (acp_status != ACP_LISTEN)
	{
		return;	// ignore incoming msgs if still busy processing
	}
		
	
	if(!eod) acp_checksum += ch;
	acp_rx[acp_rxindex++] = ch;
	
	if(acp_rxindex>12)
	{
		acp_reset();		
	} 
	
	else if (eod)	
	{
		if (acp_checksum == ch)    // Valid ACP message - send an ack
		{
			acp_status=ACP_SENDACK;
		}
		else 
		{
#ifdef ACP_DEBUG
			usb_writebyte('!');
#endif
			acp_reset();		// Abort message
		}
	}

	return;
}

void acp_uart_init(u16 baudrate)
{
	cli();
	outp((u08) (baudrate>>8), UBRRH);                  
	outp((u08) baudrate, UBRR0);
	outp((1<<RXCIE) | (1<<RXEN) | (1<<TXEN) | (1<<CHR9), UCSR0B);	// 9 bit data 
	sei();
}

void acp_txenable(u08 enable)
{	
	if (enable)	sbi(PORTD,2);			// TXENABLE = 1 	
	else      	cbi(PORTD,2); 			// TXENABLE = 0
	asm volatile("nop");		
}

void acp_sendack(void)
{
		while(!(inp(PORTD) & 0x01)); // Wait till RX line goes high (idle)
		acp_txenable(TRUE);
		sbi(UCSR0A, TXC);		// Set TXC to clear it!!
		cbi(UCSR0B, TXB8);
		outp(0x06, UDR0);
		while(!(inp(UCSR0A) & _BV(TXC)));			// wait till buffer clear
		acp_txenable(FALSE);
}

void acp_reset(void)
{
	acp_retries=0;
	acp_timeout=0;
	acp_checksum=0;
	acp_rxindex=0;
	acp_txindex=0;
	acp_txsize=0;
	acp_status=ACP_LISTEN;
}

void acp_sendmsg(void)
{
	u08 i;
		
	while(!(inp(PORTD) & 0x01)) // Wait till RX line goes high (idle)
	cbi(UCSR0B, RXCIE);	 // disable rx interrupt
	acp_txenable(TRUE);
	
	delay(104*16); // Delay 1664us (16 Bit Time Intervals) to signify start of message (ACP spec says 14, but doesn't work!)
	
	for(i=0; i <= acp_txsize; i++)
	{
		while(!(inp(UCSR0A) & _BV(UDRE)));			// wait till tx buffer empty

		cbi(UCSR0B, TXB8);
		if(i==acp_txsize) 
		{
			sbi(UCSR0A, TXC);	// set TXC to clear it!
			sbi(UCSR0B, TXB8);  // set 9th bit at end of message
		}
		
		outp(acp_tx[i], UDR0);	
	}
	while(!(inp(UCSR0A) & _BV(TXC))); // wait till last character tx complete
	acp_txenable(FALSE); // switch back to rx mode immediately
	
	acp_status = ACP_WAITACK;	// wait for ACK
#ifdef ACP_DEBUG
	for(i=0;i<=acp_txsize;i++) usb_hex(acp_tx[i]);
	usb_writebyte(0x0d);
	usb_writebyte(0x0a);
#endif
	sbi(UCSR0B, RXCIE);
}

void acp_handler(u08 p1, u08 p2, u08 p3)
{
	isPlaying = p1;
	bLoudness = p2;
	bRandom = p3;
	
	if (acp_status == ACP_LISTEN)
	{
		if(++acp_ltimeout == 1000)	// Send FFWD/FREW events periodically 
		{
			acp_ltimeout=0;
			
			switch(bFRSearch)
			{
			case 0x03:
				set_event(EV_FFWD);
				break;
				
			case 0x05:
				set_event(EV_FREW);
			}
		}
	}
	
	if (acp_status == ACP_SENDACK)
	{
		acp_sendack();
		acp_status=ACP_MSGREADY;
	}
	else if (acp_status == ACP_WAITACK)
	{
		acp_reset(); // HU does not seem to return an ACK? So just listen for next msg.
		
		/*
		acp_timeout++;
		if(!acp_timeout)
		{
			if(++acp_retries<5)
			{		
				acp_sendmsg(); // try again
			} else
			{
				acp_retries=0;
				acp_reset();
			}
		} */
	}
	
	if (acp_status == ACP_MSGREADY)
	{
#ifdef ACP_DEBUG
		u08 i;
		
		for (i=0; i < acp_rxindex;i++) usb_hex(acp_rx[i]);
		usb_writebyte(0x0d);
		usb_writebyte(0x0a);
#endif
		acp_status = ACP_SENDING;
		acp_process(); // Process message		
	}
	else if (acp_status == ACP_SENDING)
	{
		acp_timeout++;
		if(!acp_timeout)
		{
#ifdef ACP_DEBUG
			usb_string("TIMEOUT",7);
#endif
			acp_reset();
			acp_txenable(FALSE);
		}		
	}
}

void acp_process(void)
{	
	acp_timeout = 0;
	acp_tx[0] = 0x71;		// medium/low priority
	acp_tx[1] = 0x9b;
	acp_tx[2] = 0x82; 		// Message from CD Changer (yampp3)
	acp_tx[3] = acp_rx[3];
	
	if (acp_rx[2] == 0x80)  // Message from Head Unit
	{
		if(acp_rx[1]==0x9a || acp_rx[1]==0x9b) // CD Changer functional address 
		{
			switch (acp_rx[3])
			{
				case 0xc8:		// Handshake 3 - CD Changer now recognised
					acp_tx[4] = acp_rx[4];
					acp_chksum_send(5);
					break;
			
				case 0xfc:		// Handshake 2
					acp_tx[4] = acp_rx[4];
					acp_chksum_send(5);
					break;
					
				case 0xe0:		// Handshake 1
					acp_tx[4] = 0x04;
					acp_chksum_send(5);
					break;
				
				case 0xff:		// Current disc status request - responses are
					acp_tx[4]= 0x00;
								// 00 - Disc OK
								// 01 - No disc in current slot
								// 02 - No discs
								// 03 - Check disc in current slot
								// 04 - Check all discs!
					acp_chksum_send(5);
					break;
					
				case 0xc2:		// Current disc number
				case 0xd0:
					if (acp_rx[1] == 0x9a)	// Command to change disc
					{
						u08 disc = plist_change(acp_rx[4]);
						acp_tx[4] = disc & 0x7f; 
						acp_chksum_send(5);
						if(disc & 0x80) acp_nodisc();
						break;
					} else				// Request current disc
					{
						acp_tx[4] = get_disc();
					}
					if (acp_rx[3]!=0xd0) acp_chksum_send(5);
					break;
				
				case 0xc1:		// Command
	
					acp_mode = acp_rx[4];
					if((acp_mode & 0x40) && !isPlaying) set_event(EV_PLAY); 
					if(!(acp_mode & 0x40) && isPlaying) set_event(EV_STOP);
					if((acp_mode & 0x10) && !bRandom) set_event(EV_RANDOM);
					if(!(acp_mode & 0x10) && bRandom) set_event(EV_RANDOM);
					if((acp_mode & 0x20) && !bLoudness) set_event(EV_LDS);
					if(!(acp_mode & 0x20) && bLoudness) set_event(EV_LDS);
					if(acp_mode & 0x01) // Fast search mode
					{
						bFRSearch = acp_mode & 0x07;
					} else bFRSearch=0;
					
					
					acp_tx[4] = acp_mode;
					acp_chksum_send(5);
					break;
					
				case 0xc3:		// Next Track
					next_song(1);
					acp_tx[4] = BCD(getIndex()+1);
					acp_chksum_send(5);
					break;
					
				case 0x43:		// Prev Track
					next_song(2);
					acp_tx[4] = BCD(getIndex()+1);
					acp_chksum_send(5);
					break;
					
				default:
					// unknown - ignore
					acp_reset();
			}
		}
		else
		{	// Ignore all other acp messages
			acp_reset();
		}
			
	}
}

void acp_displaytime(u08 curDisc, u16 curIndex, u16 wPlayTime)
{
	acp_tx[0] = 0x71 ;    
	acp_tx[1] = 0x9b ;
	acp_tx[2] = 0x82 ;
	acp_tx[3] = 0xd0 ;
	acp_tx[4] = BCD(curDisc);
	acp_tx[5] = BCD((u08) curIndex) ; //Track
	acp_tx[6] = BCD(wPlayTime/60); 
	acp_tx[7] = _BV(7) | BCD (wPlayTime % 60); 
	acp_chksum_send(8);
}

void acp_nodisc(void)
{
	acp_tx[0] = 0x71 ;    
	acp_tx[1] = 0x9b ;
	acp_tx[2] = 0x82 ;
	acp_tx[3] = 0xff ;
	acp_tx[4] = 0x01 ;
	acp_chksum_send(5);
}

void acp_chksum_send(u08 buffercount)
{
	u08 i;
	u08 checksum = 0;

	for(i=0;i<buffercount;i++)
	{
		checksum += acp_tx[i];
	}
	acp_txsize = buffercount;
	acp_tx[acp_txsize] = checksum;
	acp_sendmsg();
}

u08 BCD(u08 val)
{
    return ((val/10)*16) + (val % 10) ;
}

#ifdef ACP_DEBUG
void usb_string(u08 str[],u08 len)
{
	u08 i;

	for(i=0;i<len;i++)
		usb_writebyte(str[i]);
	usb_writebyte(0x0d);
	usb_writebyte(0x0a);
}

void usb_hex(u08 ch)
{
	u08 i;
	i=(ch>>4) + '0';
	if(i>'9') i+=7;
	usb_writebyte(i);
	i=(ch & 0x0f) + '0';
	if(i>'9') i+=7;
	usb_writebyte(i);
}
#endif
#endif // ENABLE_FORD_ACP
