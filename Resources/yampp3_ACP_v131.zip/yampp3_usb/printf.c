/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> 
**
**
**  Yampp-3/USB - output formating routines
**
**  File printf.c
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS      initial public release
**  2003-04-05   1.1   MIS      many changes for reduce code size
**
*********************************************************************** */

#define _SFR_ASM_COMPAT 1
#include "yampp3_usb.h"

//extern void putchar(u08);

#ifdef ENABLE_UART		
void uart_progputs(char const *p)
{
	u08 b;
	while (p && (b = PRG_RDB(p++)))
	{
		uart_putchar(b);
		if(b == '\n')
			uart_putchar('\r');
	}
}

void both_progputs(char const *p)
{
	Vlcd_progputs((u08*)p);
	uart_progputs((u08*)p);
}

void both_putchar(u08 c)
{
	uart_putchar(c);
	Vlcd_putchar(c);
}

void both_puts(char *p)
{
	while(*p)
		both_putchar(*p++);
}

void uart_EOL(void)
{
	uart_putchar('\n');
}
#endif

int _p_vprintf(char const *format, va_list ap, void (*putchar)(u08 c))
{
  u08 	scratch[16];
  u08 	format_flag;
  u32 	u_val=0;
  u08	base;
  u08	*ptr;
  u08	width;
  u08 	fill;

  while(1)
  {
  	width = 0;
  	fill = ' ';
    while ((format_flag = PRG_RDB(format++)) != '%')
	{  
      if (!format_flag)
	  {
		  va_end (ap); 
		  return (0);
	  }
      putchar(format_flag);
    }


	// check for zero pad
	format_flag = PRG_RDB(format) - '0'; 
	if (format_flag == 0)	// zero pad
	{
		fill = '0';
		format++;
	}
	
	// check for width spec
	format_flag = PRG_RDB(format) - '0'; 
	if (format_flag > 0 && format_flag <= 9)	// width set
	{
		width = format_flag;
		format++;	
	}
	
	// check modifier
	
    switch (format_flag = PRG_RDB(format++))
	{
		case 'c':
		  format_flag = va_arg(ap,int);

		  //fall through
		  
		default:
		  putchar(format_flag);
		  continue;
		  
		case 'S':
		case 's':
		  ptr = va_arg(ap,char *);
		  while (*ptr)
			putchar(*ptr++);
		  continue;

		case 'u':
		  base = 10;
		  goto CONVERSION_LOOP;
		  
		case 'x':
		  base = 16;

CONVERSION_LOOP:
	  	  u_val = va_arg(ap,unsigned int);
		  ptr = scratch + 16;
		  *--ptr = 0;
		  do
		  {
			char ch = u_val % base + '0';
			if (ch > '9')
			  ch += 'a' - '9' - 1;
			*--ptr = ch;
			u_val /= base;

			if (width)
				if(--width == 0) break;
		
		  } while (u_val);

		  while (width--)
		  	*--ptr = fill; 		      
	      
		  while (*ptr)
			putchar(*ptr++);
    }
  }

}

void p_lprintf(char const *format, ... )
{
  	va_list ap;
  	va_start (ap, format);
#ifndef SATTELITE
#ifdef GRAPH_LCD
  	_p_vprintf(format,ap,Vlcd_putchar);
#else
  	_p_vprintf(format,ap,lcd_putchar);
#endif
#else //SATTELITE
  	_p_vprintf(format,ap,uart_putchar);
#endif //SATTELITE
}

#ifdef ENABLE_UART		
void p_uprintf(char const *format, ...)
{
  	va_list ap;
  	va_start (ap, format);
  	_p_vprintf(format,ap,uart_putchar);
}
#endif
