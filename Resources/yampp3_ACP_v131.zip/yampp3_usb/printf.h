/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> 
**
**
**  Yampp-3/USB - output formating routines
**
**  File printf.h
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS	initial public release
**
*********************************************************************** */


extern void p_uprintf(char const *fmt0, ... );
extern void p_lprintf(char const *fmt0, ...);
#define uprintf(format, args...)   p_uprintf(PSTR(format) , ## args )
#define lprintf(format, args...)   p_lprintf(PSTR(format) , ## args )

#if defined(ENABLE_UART) || defined(SATTELITE)
 void uart_progputs(char const *p);
 void both_progputs(char const *p);
 void both_puts(char *p);
 void both_putchar(u08 c);
 void uart_EOL(void);
#else
 #define uart_progputs(p);
 #define uart_EOL();
 #define both_progputs(p)	Vlcd_progputs(p)
 #define both_puts(p)		Vlcd_puts(p)
 #define both_putchar(c)	Vlcd_putchar(c);
#endif
