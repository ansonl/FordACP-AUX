/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> and 
**			Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - usb communication routines
**
**  File usb.c
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS      initial public release
**
*********************************************************************** */



#define _SFR_ASM_COMPAT 1
#include "yampp3_usb.h"

extern u32 filesize;
extern u32 fileplayed;
extern u08 *artistname;
extern u08 *titlename;
extern u08 usb_link;

extern void setvolume(u08 v);

void usb_response(u08 err)
{
//	if (err)
//		usb_writebyte(NAK);		// send NAK
//	else
//		usb_writebyte(ACK);		// send ACK

	usb_writebyte((err)? NAK : ACK);	// send ACK or NAK
	usb_writebyte(0);	
}


void identify(usb_cmd_block *ucb)
{
	register u08 err;
	err = IdentifyDrive(SectorBuffer);
	usb_writeblock(SectorBuffer,512);
	usb_response(err);	
}

void sectorread(usb_cmd_block *ucb)
{
	register u08 err;
	err = ATA_Read_USB(ucb->data.sector_rw.sector, ucb->data.sector_rw.nsectors);
	usb_response(err);	
}

void sectorfill(usb_cmd_block *ucb)
{
	register u08 err;
	memset(SectorBuffer,ucb->data.sector_fill.data,SECTORSIZE);
	err = ATA_Write(ucb->data.sector_rw.sector, 1, SectorBuffer);
	usb_response(err);	
}

void sectorwrite(usb_cmd_block *ucb)
{
	register u08 err;
	err = ATA_Write_USB(ucb->data.sector_rw.sector, ucb->data.sector_rw.nsectors);
	usb_response(err);								
}

#ifdef ENABLE_USB_PLAYING

void bufferfill(usb_cmd_block *ucb)
{
	usb_readblock(updbuf,ucb->data.general.parm1);
}


void songdata(usb_cmd_block *ucb)
{
	usb_readblock(SectorBuffer,ucb->data.general.parm1);
	usb_readblock(updbuf,ucb->data.general.parm2);
	filesize = ucb->data.general.parm3 / 32;
	fileplayed = 0;
	strcpy(artistname,SectorBuffer);	
	strcpy(titlename,SectorBuffer+40);	
}


void usb_volume(usb_cmd_block *ucb)
{
	setvolume(ucb->data.volume.left);	
}

void bufferinfo(usb_cmd_block *ucb)
{
	ucb->data.buffer_info.buffersize = BUFFERSIZE;
	usb_writeblock((u08*)ucb,sizeof(usb_cmd_block));
}

#endif

void eeread(usb_cmd_block *ucb)
{
	eeprom_read_block(SectorBuffer, (u08*)(u16)ucb->data.general.parm1, ucb->data.general.parm2);
	usb_writeblock(SectorBuffer,ucb->data.general.parm2);
}

void eewrite(usb_cmd_block *ucb)
{
	u16 adr;
	usb_readblock(SectorBuffer,ucb->data.general.parm2);
	usb_response(0);	
#ifdef SATTELITE
	uart_pc1(SAT_CMD_MARKER);
	uart_pc1(SAT_EEPROM_WR);
	uart_pc1((u16)ucb->data.general.parm1 / 256);		// start address H
	uart_pc1((u16)ucb->data.general.parm1 % 256);		// start address L
	uart_pc1((u16)ucb->data.general.parm2 / 256);		// data length H
	uart_pc1((u16)ucb->data.general.parm2 % 256);		// data length L
#endif
	for (adr=0; adr < ucb->data.general.parm2; adr++)
	{
#ifdef SATTELITE
		uart_pc1(SectorBuffer[adr]);			// send byte of data
		delayms(10);					// wait for write complete
#else
		eeprom_wb((u16)ucb->data.general.parm1 + adr, SectorBuffer[adr]);
#endif
		wdt_reset();
	}
}

void (*bootloader)(void) =  (void*) 0x1E10;

void usb_handler(void)
{
	usb_cmd_block ucb;
	event_e event = EV_IDLE;
	
	if (usb_rxready)
	{
		usb_readblock((char*)&ucb,sizeof(usb_cmd_block));
		switch ((u16)ucb.command)
		{
			case USB_TEST_POLL :		// Test command
				usb_response(0);	// echo OK
				break;
				
			case USB_ENTER_BOOT :		 // Boot Load
				bootloader();
				break;				

			case USB_EEPROM_READ :		 // EEPROM Read
				eeread(&ucb);
				break;				

			case USB_EEPROM_WRITE :		 // EEPROM Write
				eewrite(&ucb);
				break;				
				
			case USB_SECTOR_READ :		 // Sector Read
				sectorread(&ucb);
				break;

			case USB_SECTOR_WRITE :		 // Sector Write
				sectorwrite(&ucb);
				break;
				
			case USB_SECTOR_FILL : 		// Sector Fill
				sectorfill(&ucb);
				break;

			case USB_IDENTIFY : 		// Identify drive
				identify(&ucb);
				break;
#ifdef ENABLE_USB_PLAYING
			case USB_PLAY :			 // Start USB Play
				event = EV_PLAY_USB; 
				updbuf = buffer1;
				songdata(&ucb);
				usb_response(0);
				break;

			case USB_BUFFER :		// Incoming USB Play buffer
				bufferfill(&ucb);				
				break;

			case USB_STOP :			// Stop USB Play
				event = EV_STOP; 
				usb_response(0);	// send ACK
				break;

			case USB_SETVOLUME : 		// Set Playback Volume
				usb_volume(&ucb);
				break;
				
			case USB_BUFFERINFO :	
				bufferinfo(&ucb);
				break;
#endif
			case USB_ENTER_LINK :
				usb_link = 1;
				event = EV_STOP;
				break;

			case USB_EXIT_LINK :
				usb_response(0);
				wdt_enable(0x01);
				while(1);		// reset player by watchdog
				break;
				
			default : 
				usb_writebyte(UNK);	
				usb_writebyte(0);	
				break;
		}
	}
	if (event != EV_IDLE)
		set_event(event);
}
