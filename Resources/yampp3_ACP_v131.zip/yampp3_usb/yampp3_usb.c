/* ***********************************************************************
**
**  Copyright (C) 2002  Jesper Hansen <jesperh@telia.com> and 
**			Romuald Bialy (MIS) <romek_b@o2.pl>.
**
**
**  Yampp-3/USB - main file
**
**  File yampp3_usb.c
**
*************************************************************************
**
**   This file is part of the yampp system.
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software Foundation, 
**  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
*************************************************************************
**
**  Revision History
**
**  when         what  who	why
**
**  2002-09-01   1.0   MIS    	-initial public release
**  2002-09-25   1.10  Jesper	-solved problems with some IR remotes standard detection
**  2002-09-27   1.11  MIS	-improved visualisation on 4 lines LCD's
**  2002-09-28   1.12  MIS	-next visualisation improvements (see Constants.h)
**  2002-10-10   1.13  MIS	-visualisation changes in MENU function
				-added numeric volume level (in dB) on LCD longer than 16 chars.
				-fixed sound breaking after exit from PAUSE state.
				-added prevous playlist if mode=1 and you press PREVOUS key
**  2002-10-20   1.14  MIS	-bugfix in playlist name displaying on 4 lines LCD
**  2002-10-21   1.15  MIS	-added total song time displaying
**  2002-10-26   1.16  MIS	-bugfix in volume indicator clearing
**  2002-11-02   1.17  MIS	-added support for vs1001 equalizer running and settings
**  2002-11-08   1.20  MIS	-added suport for graphics LCD display from Nokia GSM phones
**  2002-11-10   1.21  MIS	-added bitrate displaying on graphisc LCD.
**				-posibility to use bigger logo (84x40 pixels)
**				-two versions of progresspar on graphisc LCD.
**				-invert mode (negative image) on graphisc LCD.
**				-some minor bugfixes.
**  2002-11-14   1.22  MIS	-added national characters conversion in standard alphanumeric LCD's.
**  2002-12-18   1.23  MIS	-added storing time mode into EEPROM.
**  2002-12-22   1.24  MIS	-added support for older than K versions of VS1001.
**  2003-02-23   1.25  MIS	-added support for new version of VS1001 equalizer library with 12 presets
**  2003-04-10   1.26  MIS	-added balance control
				-added quick equalizer ON/OFF function (from remote or local keyboard),
				 filter number is selectable from Menu and Remote.
				-added Info about current song in EV_INFO event
				-added auto accept selected song - during song browse, if current song ends.
				-fixed progressbar flicker during fast rewind
				-if 8 keys control is used -> removed not needed functions from Menu
				-fixed bug in setup remote procedures
				-code optimalisation
**  2003-06-15   1.27  MIS	-added storing current position inside song after PAUSE and power-off
				-added direct Playlist and Song number select in "Playlist" menu (numerical keys at remote).
				-added volume ramp-up after startup the player with the autoplay.
				-added new optional "PREVOUS" key functionality (work like in normal CD players).
				-added compatibility for some extended RC-5 remotes.
				-added volume level dB displaying on 16 chars line length LCD's.
				-little ata procedures speed-up.
				-fixed volume bug during fast forward and rewind.
				-disable songbase and playlist caching for code space recovery (not needed anyway)
				-some first attempt to Remote Yampp Sattelite Display support. Not finished yet.

**  2003-07-10   1.30b1  MIS	-Sources changed for compilation with AVR-GCC 3.3 !!!
				-fixed progressbar bug during fast forward and rewind after volume change.
				-fixed uart info formating
				-improved IR remote codes learning
				-better IR remote autorepeat function
				-finished full Remote Yampp Sattelite Display support.
				-added support for Graphics 128x64 display.
				-added support for Rottary Switch control.

**  2003-08-10   1.30b2  MIS	-New autorepeat function not work on REC80 remotes. Revert to old and working.
				-Fixed small displaying bug on 128x64 graphics LCD.
				-Fixed volume bar on nokia LCD's.

**  2003-10-06	 1.31    andyh	- Added Ford ACP support functions

*********************************************************************** */

#define YAMPP_FIRMWARE_VERSION_MAJOR	1
#define YAMPP_FIRMWARE_VERSION_MINOR	31

#define DISK_LAYOUT_VERSION_MAJOR	1
#define DISK_LAYOUT_VERSION_MINOR	0

static char firmware_scan_tag[] __attribute__ ((progmem)) = "yfwTAG";
static char model_txt[]         __attribute__ ((progmem)) = "yampp-3/ACP";
static char date_txt[]          __attribute__ ((progmem)) = __DATE__" / "__TIME__;
static char version_txt[]       __attribute__ ((progmem)) = "1.31";


/*
	PIN assignements on the yampp3/USB board
	
	PA0-PA7		data bus 0..7 + Address 0..7
	
	PB0		T0	DIOW
	PB1		T1	DIOR
	PB2		AIN0	DREQ
	PB3		AIN1	BSYNC		
	PB4		SS	MP3
	PB5		MOSI	SO
	PB6		MISO 	SI
	PB7		SCK	SCK
	
	PC0-=C7		address 8..15	

	PD0		RxD	RS-232/RS-485 RX
	PD1		TxD	RS-232/RS-485 TX
	PD2		INT0	TX_ENABLE (alternatively KEY_INPUT2 or graphisc LCD C/D output)
	PD3		INT1	KEY_INPUT
	PD4		T0	TXE
	PD5		T1	RXE
	PD6		WR	RD
	PD7		RD	WR	

	PE0		ICP	IR-IN
	PE1		ALE	ALE
	PE2		OC1B	LCD_ENABLE


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	The CPU is running with a 7.3728 MHz clock
*/

#define _SFR_ASM_COMPAT 1
#include "yampp3_usb.h"

//------------------------------------------------------------------------------------------

// Amount of small steps in LCD play position bar
#define LCD_STEPS ((LCD_LINE_LENGTH - 6) * 5)

//------------------------------------------------------------------------------------------

void idle(void);


event_e menu_event;
u08 cur_disc;

u08 isPlaying;				// playing status
u08 bLoudness;				// loudness modificator
u08 bRandom;				// random modificator
#ifdef ENABLE_USB_PLAYING
 u08 usb_play;				// usb playing status
#else
 #define usb_play 0
#endif
u08 Repeat;				// repeat modificator
u08 info_flag;				// 0=enable display, 1,2=only scroll enabled, 3,4=disable update
u08 timemode;				// normal or remain time displaying modificator
u08 volume;				// volume level
s08 balance;

u08 vol_decrease;			// modificator for fast forward and fast rewind functions
u16 BackStepPos;			// Actual position in backstep tabele
u08 OldSteps;				// For progressbar displaying

u08 *outptr;				// pointer for sending data to vs1001
u08 *buffer1;				// first play buffer begin pointer
u08 *buffer2;				// second play buffer begin pointer
u08 *buffer3;				// second play buffer end pointer
u08 *updbuf;				// pointer for buffer updating
u32 filesize;				// size of file to play (divided by 32)
u32 fileplayed;				// amount of played data (divided by 32)
u16 songtime;				// time of current song in seconds
u16 addtime;				// time calculation helper for fast forward and fast rewind functions
u16 bitrate;				// bitrate of current song
u16 ListQty;				// numbers of songs inside playlist

u16 vs1001_fw;				// VS1001 firmware address

u08 *artistname = (u08*)ARTISTNAME_BUF;	// pointer to artistname buffer
u08 *titlename = (u08*)SONGNAME_BUF;	// pointer to songname buffer
u08 *scroll_line = (u08*)SCROLL_LINE;	// pointer to scroll line buffer
u08 scroll_length;			// size of scroll data
u08 scroll_pos;				// current position in scroll string

#ifdef ALTERNATE_SCROLL
 u08 scroll_dir;
#endif

#ifdef VOL_UP_RAMP
 u08 volume_ramp;			// volume level multiplier at volume startup ramp
#endif

#if (LCD_LINES != 2)
 u08 scroll_length_2;			// size of scroll data 2
 u08 scroll_pos_2;			// current position in scroll string 2
 #ifdef ALTERNATE_SCROLL
  u08 scroll_dir_2;
 #endif
#endif

#ifdef OLD_VS1001
 u16 wPlayT;
 #define playtime	(wPlayT/10)
#else
 #define playtime 	vs1001_read(VS1001_PLAYTIME)
#endif

u16 OldPlayTime;

//---------------------------------------------------------------------------

void ATA_SW_Reset2(void)					// ATA Reset
{
	WriteBYTE(ATAPI_DevCtrl, 0x06);				// SRST and nIEN bits
	delay10();						// 10uS delay
	WriteBYTE(ATAPI_DevCtrl, 0x02);				// nIEN bit
	delay10();						// 10 uS delay
	while ( (ATA_WaitBusy() & SR_DRDY) != SR_DRDY ); 	// Wait for DRDY
  	ATA_ReadStat();
}

void ATA_Standby(u08 time)
{
	WriteBYTE(ATA_SectorCount, time);			// time * 5 second (0=disable)
	WriteBYTE(ATAPI_Cmd, 0xE3);				// set standby timer and execute IDLE
	ATA_WaitBusy();
}

//----------------------------------------------------------------------------

#define EVENT_QUEUE_SIZE	8
volatile event_e event_queue[EVENT_QUEUE_SIZE];
volatile u08 event_queue_head = 0;
volatile u08 event_queue_tail = 0;

void set_event(event_e e)
{
	event_queue[event_queue_head] = e;
	event_queue_head = (event_queue_head + 1) % EVENT_QUEUE_SIZE; 
}

event_e get_event(void)
{
	event_e tmp = EV_IDLE;
	
	//
	// let the system have it's time
	//
	idle();
	
	//
	// check queue
	//
	if (event_queue_head != event_queue_tail)
	{
		tmp = event_queue[event_queue_tail];
		event_queue_tail = (event_queue_tail + 1) % EVENT_QUEUE_SIZE; 
	}
	return tmp;
}

//--------------------------------------------------------------------------

// prescaler set to 34.72 uS
// 2880 ticks = 100 mS

#define TI1_H	(((u16)-(F_CPU / 2560)) >> 8)
#define TI1_L	(((u16)-(F_CPU / 2560)) & 0xff )

volatile u08 time_flag;			// counter for display refresh
volatile u08 scroll_time;		// counter for scrolling refresh

SIGNAL(SIG_OVERFLOW1)			// timer 1 overflow every 100 mS
{
	time_flag++;
	nKeyTime++;			// counter for keyboard and IR functions
	scroll_time++;
#ifdef OLD_VS1001
	wPlayT++;			// playing time counter for older than K versions of VS1001
#endif
	outp(TI1_H, TCNT1H);		// reload timer 
	outp(TI1_L, TCNT1L);
}

//--------------------------------------------------------------------------
#ifdef PWR_BEEPS

void send_sinewave_beeps(void)
{
	u08 i,j=3;
static	u08 buf[8] = {	0x53, 0xEF, 0x6E, 0x30,		// sine on
			0x45, 0x78, 0x69, 0x74};	// sine off
	vs1001_nulls(4);
	while(j--)
	{
		for (i=0;i<4;i++)
			vs1001_send_data(buf[i]);
		vs1001_nulls(4);
		delayms(100);
		
		for (i=4;i<8;i++)
			vs1001_send_data(buf[i]);
		vs1001_nulls(4);
		delayms(100);
	}	
}

#endif
//--------------------------------------------------------------------------

#if !defined(SATTELITE) && (LCD_TYPE != 8)
void lcd_clrline(u08 line)		// clear single line of LCD
{
	register u08 i=LCD_LINE_LENGTH;
	Vlcd_gotoxy(0,line);

	while(i--)
		Vlcd_putchar(' ');

	Vlcd_gotoxy(0,line);		// goto begin of line
}
#endif

//--------------------------------------------------------------------------

void LoudSet(void)					// Equalizer mode setting
{
	if (vs1001_fw)					// If Equalizer loaded
	{
		if(bLoudness && bLoudness<128)		
		{
			vs1001_write(0x0A,vs1001_fw);	// Enable user code
			vs1001_write(0x0D,0);		// Reset EQ
			vs1001_write(0x0D,bLoudness);	// Set EQ characteristic
		}
		else
		{
			vs1001_write(0x0D,0);		// Reset EQ
			vs1001_write(0x0A,0);		// Disable user code
		}
	}
	else
		vs1001_write(VS1001_MODE, 0x0080 * (bLoudness != 0));	// write bit SM_BASS to VS1001K

#ifdef VOL_UP_RAMP
	vs1001_setvolume(volume + 2*volume_ramp, balance);
#else
	vs1001_setvolume(volume,balance);
#endif
}

//--------------------------------------------------------------------------

#ifdef GRAPH_LCD

void Vlcd_wrdata0(void)
{
	Vlcd_wrdata(0);
}

void status_display(void)
{
	u08 i = 0;
#if(LCD_TYPE == 7)
	Vlcd_gotoxy(0,LCD_LINES+1);
#else
	Vlcd_gotoxy(13,LCD_LINES+1);
#endif	
	if (bRandom)
	{
		i=127;
		Vlcd_invert();
	}
	Vlcd_wrdata(i);
	Vlcd_progputs(PSTR("\x16\x17"));				// Random signs
	Vlcd_normal();
	Vlcd_wrdata(i);
	Vlcd_wrdata0();

	Vlcd_putchar(Repeat + 0x18 - 1*(Repeat > 0));			// Repeat sign L
	Vlcd_putchar(Repeat + 0x1b - 1*(Repeat > 1));			// Repeat sign R	
#if(LCD_TYPE == 8)
	Vlcd_gotoxy(19,7);
#else
	Vlcd_wrdata0();
	Vlcd_wrdata0();
#endif
	Vlcd_putchar('L');						// EQ mode
	if (bLoudness < 128)
		Vlcd_putchar((bLoudness > 9) ? bLoudness + ('A'-10) : bLoudness + '0');
	else
		Vlcd_putchar('0');

#ifdef VOL_UP_RAMP
	u08 v = volume+2*volume_ramp;
#else
	u08v = volume;	
#endif

#ifndef SATTELITE
 #if(LCD_TYPE == 8)
	Vlcd_gotoxy(13,6);
 #endif
	if (v <  MIN_VOLUME)
	{
		for (i=0; i<((LCD_TYPE == 7) ? 16 : 23); i++)		// Volume Bar
		{
			if(MIN_VOLUME - v >= i * VOL_STEP * NUM_VOL_STEPS / ((LCD_TYPE == 7) ? 16 : 22))
#if(LCD_TYPE == 7)
				Vlcd_wrdata(0xff << (8 - (i+1)/2));
#else
				Vlcd_wrdata((u08)(0xff << (8 - (i+1)/3)) >> 1);
#endif
			else
				Vlcd_wrdata0();
		}

	}
	else
	{
		Vlcd_wrdata0();
		Vlcd_putchar(0x1e);			// speaker
		Vlcd_wrdata0();
		Vlcd_wrdata0();
		Vlcd_putchar('x');
		Vlcd_wrdata0();
		Vlcd_wrdata0();
	}

#else //SATTELITE
	uart_pc1(SAT_CMD_MARKER);
	uart_pc1(SAT_VOLUME);
	uart_pc1(v);
	uart_pc1(MIN_VOLUME);
	uart_pc1(NUM_VOL_STEPS);
#endif

	if (isPlaying && !info_flag)
	{
		i = (v > 19);
	
#if(LCD_TYPE == 7)
		Vlcd_gotoxy(10-i,LCD_LINES+1);
#else
		Vlcd_gotoxy(17-i,LCD_LINES);
#endif
		if(i)
			Vlcd_putchar(' ');

		lprintf("%3uk",bitrate);
	}	
}


#else // Alphanumerics LCD's

void lcd_data00(void)
{
	Vlcd_data(0x00);
}

void lcd_data1f(void)
{
	Vlcd_data(0x1F);
}

#endif //GRAPH_LCD

//--------------------------------------------------------------------------

void setvolume(u08 v)
{
#ifdef VOL_UP_RAMP
	v = v+2*volume_ramp;
#endif
	vs1001_setvolume(v,balance);

#ifdef SATTELITE
	uart_pc1(SAT_CMD_MARKER);
	uart_pc1(SAT_VOLUME);
	uart_pc1(v);
	uart_pc1(MIN_VOLUME);
	uart_pc1(NUM_VOL_STEPS);
#else

 #ifndef GRAPH_LCD
	u08 i,j;					// volume indicator on alphanumeric LCD's

	if(!usb_play)
	{
		Vlcd_command(0x40);			// define of volume bar characters
		j=8;
		while(j--)
		{
			for (i = 0; i < 8; i++)
			{
				if (i >= j)
					lcd_data1f();
				else
					lcd_data00();
			}
		}

//		if(!info_flag)
//			lcd_clrline(LCD_LINES - 1);
//		else
			Vlcd_gotoxy(0, LCD_LINES - 1);

  #if (LCD_LINE_LENGTH > 16)
		Vlcd_progputs(PSTR("Volume "));
  #else
		Vlcd_progputs(PSTR("Vol"));
  #endif
		for (i=0; i < 8; i++)			// write volume bar
		{
			if(MIN_VOLUME - v >= i * (VOL_STEP*(NUM_VOL_STEPS/8)))
				Vlcd_putchar(i);
			else
				Vlcd_putchar(' ');
		}
		if (v < 20) Vlcd_putchar(' ');
		if (v > 1)
			Vlcd_putchar('-');
		else
			Vlcd_putchar(' ');
		lprintf("%udB",v/2);
	}

 #else //GRAPH_LCD

	status_display();				// update status bar on Graphisc LCD

	Vlcd_gotoxy(10+7*(LCD_TYPE == 8)-1*(v>19),LCD_TYPE-2);
	if (v > 1)
		Vlcd_putchar('-');
	else
		Vlcd_putchar(' ');
	lprintf("%udB",v/2);			// Volume Level

 #endif // GRAPH_LCD
#endif // SATTELITE


#ifdef VOL_UP_RAMP
	if(!volume_ramp)
#endif
		eeprom_wb(EEPROM_VOLUME,v);		// only after ramp ends (EEPROM write cycles save)

	time_flag = 5;					// prevent display overvriting for 2 second
	info_flag = 1;					// allow scroll data
}


//--------------------------------------------------------------------------


void setbalance(s08 b)
{
	vs1001_setvolume(volume,b);
	eeprom_wb(EEPROM_BALANCE,b);
#ifdef GRAPH_LCD
	status_display();				// update status bar on Graphisc LCD
	u08 i = b;
#if(LCD_TYPE == 7)
	Vlcd_gotoxy(10,5);
#else
	Vlcd_gotoxy(17,6);
#endif
	Vlcd_putchar(' ');
	if(b <= 0)
	{
		Vlcd_putchar('<');
		i = 0-b;
	}
	else
		Vlcd_putchar('-');

	lprintf("%u",i/4);
	Vlcd_putchar( (b >= 0) ? '>':'-');

#else  //GRAPH_LCD

	u08 i = b;
	lcd_clrline(LCD_LINES - 1);
	Vlcd_progputs(PSTR("Balance "));
	if(b <= 0)
	{
		Vlcd_putchar(0x7f);
		i = 0-b;
	}
	else
		Vlcd_putchar('-');

	lprintf("-%u-",i/4);
	Vlcd_putchar( (b >= 0) ? 0x7e:'-');

#endif //GRAPH_LCD

	info_flag = 2;					// allow scroll data, balance mode
	time_flag = 5;					// prevent display overvriting for 2 second

}

//--------------------------------------------------------------------------

void eeprom_ww(u16 address, u16 value)			// write word to eeprom
{
	asm volatile("call eeprom_write_byte");
	asm volatile("subi r24,lo8(-(1))");
	asm volatile("sbci r25,hi8(-(1))");
	asm volatile("mov r22,r23");
	asm volatile("call eeprom_write_byte");
}


/************************************************************************
*				RANDOM STUFF				*
************************************************************************/

// Random stuff, maximum 32768 songs on the disk!

static u32 seed = 1;

// Init randomize table
void InitRnd(void)
{
	memset(RANDOM_TAB,0,4096);		// clear random table
}

u16 randcalc(u16 max)							// assembler optimized randomizer function
{
//  return ((seed = seed * 1103515245L + 12345) % max);	// get new song number

	asm volatile ("push r24");
	asm volatile ("push r25");
	asm volatile ("lds r22,seed");
	asm volatile ("lds r23,(seed)+1");
	asm volatile ("lds r24,(seed)+2");
	asm volatile ("lds r25,(seed)+3");
	asm volatile ("ldi r18,lo8(1103515245)");
	asm volatile ("ldi r19,hi8(1103515245)");
	asm volatile ("ldi r20,hlo8(1103515245)");
	asm volatile ("ldi r21,hhi8(1103515245)");
	asm volatile ("call __mulsi3");
	asm volatile ("subi r22,lo8(-(12345))");
	asm volatile ("sbci r23,hi8(-(12345))");
	asm volatile ("sbci r24,hlo8(-(12345))");
	asm volatile ("sbci r25,hhi8(-(12345))");
	asm volatile ("sts seed,r22");
	asm volatile ("sts (seed)+1,r23");
	asm volatile ("sts (seed)+2,r24");
	asm volatile ("sts (seed)+3,r25");
	asm volatile ("pop r19");
	asm volatile ("pop r18");
	asm volatile ("clr r20");
	asm volatile ("clr r21");
	asm volatile ("call __udivmodsi4");
	asm volatile ("mov r25,r23");
	asm volatile ("mov r24,r22");
	return max;						// return result from R24:R25
}

u08 tabval(u16 num, u08 fn)					// check random tabele for song status
{								// and mark as played if necessary
	u16 index = num >> 3;
	u08 offset = 1 << (num % 8);
	if(fn)
		RANDOM_TAB[index] |= offset;			// if fn=1 mark as played

	return (RANDOM_TAB[index] & offset);			// return status
}

// new random procedure
u16 do_rand(u16 max)						// returned random value from 0 to max - 1
{
u16 num;
	max &= 0x7fff;						// limit for lower RAM usage
	for(num = 0; num < max; num++)
		if(tabval(num,0) == 0)
			break;
	if (num == max)
		num = -1;
	else
	{
		do
		{
//			WDR;
			num = randcalc(max);
		} while (tabval(num,0) != 0);			// check this song not be played piervously
		tabval(num,1);					// mark as just played
	}
	return num;
}


/************************************************************************
*				FORMAT NEW DISK				*
*************************************************************************/

u08 format_new_disk(void)
{
	YADL_ROOT_SECTOR *pBoot;					// Boot Sector struct
	IDENTIFY_DATA *pID;	
	u08 i,c;
	u32 sectors;

	i = firmware_scan_tag[0];					// for compiler warning supression
	
	// first get some drive data
	IdentifyDrive(buffer1);
	
	// flip and save the ModelNumber data
	pID = (IDENTIFY_DATA *) buffer1;
	strncpy(buffer1,(u08*)pID->ModelNumber,sizeof(pID->ModelNumber));
	for (i=0;i<sizeof(pID->ModelNumber);i+=2)
	{
		c = buffer1[i];
		buffer1[i] = buffer1[i+1];
		buffer1[i+1] = c;
	}
	buffer1[sizeof(pID->ModelNumber)] = 0;				// terminate entry
	
	// get max sectors (disk size)
	sectors = pID->UserAddressableSectors;
	
	// clear buffer
	pBoot = (YADL_ROOT_SECTOR *) buffer2;				// use temp buffer for room
	memset(pBoot,0,512);

// section 1
	strncpy(pBoot->id,"YADL",4);

	pBoot->disk_size = sectors;
	
	pBoot->unmount_state = YADL_STATE_NEW;
	pBoot->media_type = YADL_MEDIA_DISK;

	pBoot->disk_version_major = DISK_LAYOUT_VERSION_MAJOR;
	pBoot->disk_version_minor = DISK_LAYOUT_VERSION_MINOR;

	strncpy_P(pBoot->model,model_txt, YADL_LEN_MODEL);		// yampp model name

	// copy the ModelNumber result from Identify Drive
	strncpy(pBoot->disk_info, buffer1, YADL_LEN_DISK_INFO);	

// section 2
	
	strncpy_P(pBoot->build_timestamp, date_txt, YADL_LEN_BUILD_TIMESTAMP);
	pBoot->firmware_version_major = YAMPP_FIRMWARE_VERSION_MAJOR;
	pBoot->firmware_version_minor = YAMPP_FIRMWARE_VERSION_MINOR;
	
// section 3	
// section 4
// section 5

	// write the sector
	// and return result
	
	return (ATA_Write(0,1,(u08*) pBoot));
}


/****************************************************************************************/


u32 songbase_start;			// first songbase sector
u16 songbase_qty;			// number of songs
u32 fat_start;				// first fat sector
u32 sector_cluster_offset;		// add to cluster -> sector conversions
u32 playlist_start;			// first playlist sector
u16 playlist_qty;			// number of playlists

u32 MyCluster;				// current cluster number
u32 MySector;				// current sector number
u16 SectorsLd;				// sectors in cluster counter

/****************************************************************************************/


//
// return the next FAT in a chain
//
u32 next_fat(u32 current_fat)
{
	u16 fat_offset;
	u32 fat_sector;
	static u32 fat_in_cache = -1;
	
	fat_sector = fat_start + current_fat / (SECTORSIZE / sizeof(CLUSTER));
	fat_offset = current_fat % (SECTORSIZE / sizeof(CLUSTER));
	
	if (fat_sector != fat_in_cache)
	{
		while(ATA_Read(fat_sector,1,(u08*)FAT_CACHE))
		    	ATA_SW_Reset2();
		fat_in_cache = fat_sector;
	}
	if(BackStepPos < MAX_REV_STEPS)
		Rev_Table[++BackStepPos] = ((CLUSTER*)FAT_CACHE)[fat_offset];
	return ((CLUSTER*)FAT_CACHE)[fat_offset];
}

void init_load_sectors(u32 cluster)
{
	MyCluster = cluster;
	MySector = sector_cluster_offset + YADL_SECTORS_PER_CLUSTER * MyCluster;
	SectorsLd = 0;
}


//
// load a bufferfull of data
//
void load_sectors(u08 *buffer)
{
	while(ATA_Read( MySector, BUFFERSIZE / SECTORSIZE, buffer))
	    	ATA_SW_Reset2();
	MySector += BUFFERSIZE / SECTORSIZE;
	SectorsLd += BUFFERSIZE / SECTORSIZE;
	if (SectorsLd == YADL_SECTORS_PER_CLUSTER)
		init_load_sectors(next_fat(MyCluster));
}

/****************************************************************************************/

static char firmver_txt[] __attribute__ ((progmem)) = "Firmware version";

void init_stuff(void)
{
	u08 update = 0;
	YADL_ROOT_SECTOR *pRoot;				// Boot Sector struct
	pRoot = (YADL_ROOT_SECTOR *) buffer1;			// Allocate room from the temp buffer
	while(ATA_Read(0,1,buffer1))				// read root sector
		ATA_SW_Reset2();

	if(pRoot->id[0] != 'Y' || pRoot->id[1] != 'A' || 
	   pRoot->id[2] != 'D' || pRoot->id[3] != 'L')		// YADL signature not found
	{
		event_e event = EV_IDLE;
		Vlcd_clrscr();
		both_progputs(PSTR("Found not YADL\nor new disk !!\n"));
#if (LCD_LINES == 2)
		delayms(5000);
		Vlcd_clrscr();
#endif
		both_progputs(PSTR("Press PLAY to\nformat the disk."));
		uart_EOL();
		while((event = get_event()) != EV_PLAY);	// wait for PLAY key
		Vlcd_clrscr();
		both_progputs(PSTR("All data be lost\nAre you sure ?\n"));

		while((event = get_event()) == EV_PLAY);	// wait for release key

		while((event = get_event()) != EV_PLAY);	// wait for accept by PLAY key

#if (LCD_LINES == 2)
		Vlcd_clrscr();
#endif
		both_progputs(PSTR("Format"));
		register u08 i = format_new_disk();
		both_progputs((i) ? PSTR(" ERROR !") : PSTR("ing OK."));

		wdt_enable(0x07);
		while(1);					// reset player by watchdog
	}

	if(pRoot->firmware_version_major != YAMPP_FIRMWARE_VERSION_MAJOR)
	{
		pRoot->firmware_version_major = YAMPP_FIRMWARE_VERSION_MAJOR;
		update = 1;
	}
	if(pRoot->firmware_version_minor != YAMPP_FIRMWARE_VERSION_MINOR)
	{
		pRoot->firmware_version_minor = YAMPP_FIRMWARE_VERSION_MINOR;
		update = 1;
	}
	if(strcmp_P(pRoot->build_timestamp, date_txt))
	{
		strcpy_P(pRoot->build_timestamp, date_txt);
		update = 1;
	}
	if (update)
	{
		while(ATA_Write(0,1,(u08*) pRoot))
		    	ATA_SW_Reset2();
		Vlcd_clrscr();
		both_progputs((u08*)&firmver_txt);
		both_progputs(PSTR("\ninfo updated.\n"));
		delayms(4000);
	}

	sector_cluster_offset = pRoot->sector_cluster_offset;
	songbase_start 	= pRoot->songbase_start;			// SECTOR !!
	songbase_qty	= pRoot->songbase_qty;
	playlist_start 	= sector_cluster_offset + YADL_SECTORS_PER_CLUSTER * pRoot->playlist_start;	// SECTOR !!!
	playlist_qty 	= pRoot->playlist_qty;		
	fat_start 	= pRoot->fat_start;


	// VS1001 User Software Loader
	//
	u32 app_start = pRoot->wasteland_start;
	vs1001_fw = 0;
	u16 *pData;
	pData = (u16*) buffer1;
	while(ATA_Read(app_start,1,buffer1))			// read first free sector
		ATA_SW_Reset2();

	if(*pData++ != 0x4679 || *pData++ != 0x776D)		// Firmware signature ('yFmw') not found
		return;						// exit

	u16 DataLen = *pData++;					// length of firmware in words (firmware only)
	vs1001_fw = *pData++;					// address to enter into VS1001 register A1ADDR
								// for application running.
	vs1001_write(7,vs1001_fw + 0x4000);			// write to VS1001 register WRAMADDR
	while(DataLen--)					// data length in words
	{
		if (pData == (u16*)(buffer1+512))
		{
			app_start++;
			while(ATA_Read(app_start,1,buffer1)) 	// read next sector with application datas
				ATA_SW_Reset2();
			pData = (u16*) buffer1;			// new start address
		}
		vs1001_write(6,*pData++);			// write firmware word to vs1001
	}
}


/****************************************************************************************/


u16 curPlaylist = 0;
u16 curIndex = 0;
u16 selected_Playlist;


#ifdef SATTELITE

/****************************************************************************************/

YADL_PLAY_LIST_ENTRY *get_pl_entry(u16 index)
{
	static u32 nLastSector = -1;
	u32 nCurSector;
	
	//
	// find (and load) correct playlist sector
	//

	nCurSector =  playlist_start + (index >> 3);	// 64 bytes per one playlist entry
	if (nCurSector != nLastSector)
	{
		while(ATA_Read(nCurSector,1,(u08*)PL_CACHE))
			ATA_SW_Reset2();
		nLastSector = nCurSector;	
	}
	return &((YADL_PLAY_LIST_ENTRY *)PL_CACHE)[index % 8];
}

/****************************************************************************************/

YADL_SONG_BASE_ENTRY *get_song_entry(u16 index)
{
	static u32 nLastSector = -1;
	u32 nCurSector;
	
	nCurSector = songbase_start + (index >> 2);
	if (nCurSector != nLastSector)
	{
		while(ATA_Read(nCurSector,1,(u08*)SE_CACHE))
			ATA_SW_Reset2();
		nLastSector = nCurSector;
	}
	return &((YADL_SONG_BASE_ENTRY *)SE_CACHE)[index % 4];
}

/****************************************************************************************/

u16 get_offset_entry(u16 index, u16 Playlist)
{
	static u32 nLastSector = -1;
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(Playlist);
	FOFFSET offset = pListEntry->offset;

	// first compute desired start sector
	u32 nCurSector = playlist_start + (offset / SECTORSIZE) + (index * sizeof(u16) / SECTORSIZE);

	offset = offset % SECTORSIZE;		 // cut offset to rest inside one sector

	if (nCurSector != nLastSector)
	{
		while(ATA_Read(nCurSector,2,(u08*)LO_CACHE))
			ATA_SW_Reset2();
		nLastSector = nCurSector;
	}

	u16 *pList = (u16*) ( (u08*)LO_CACHE + offset);  // again put offset here as it needs not to begin on sector boundary
	index = index % (SECTORSIZE/sizeof(u16));        // cut off rest of index that already is in other sectors
	return pList[index];
}

/****************************************************************************************/

#else // Not Sattelite

/****************************************************************************************/

YADL_PLAY_LIST_ENTRY *get_pl_entry(u16 index)
{
	u32 nCurSector;
	
	//
	// find (and load) correct playlist sector
	//

	nCurSector =  playlist_start + (index >> 3);	// 64 bytes per one playlist entry
	while(ATA_Read(nCurSector,1,(u08*)PL_CACHE))
		ATA_SW_Reset2();
	return &((YADL_PLAY_LIST_ENTRY *)PL_CACHE)[index % 8];
}

/****************************************************************************************/

YADL_SONG_BASE_ENTRY *get_song_entry(u16 index)
{
	u32 nCurSector;
	
	nCurSector = songbase_start + (index >> 2);
	while(ATA_Read(nCurSector,1,(u08*)SE_CACHE))
		ATA_SW_Reset2();
	return &((YADL_SONG_BASE_ENTRY *)SE_CACHE)[index % 4];
}

/****************************************************************************************/

u16 get_offset_entry(u16 index, u16 Playlist)
{
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(Playlist);
	FOFFSET offset = pListEntry->offset;

	// first compute desired start sector
	u32 nCurSector = playlist_start + (offset / SECTORSIZE) + (index * sizeof(u16) / SECTORSIZE);

	offset = offset % SECTORSIZE;		 // cut offset to rest inside one sector

	while(ATA_Read(nCurSector,2,(u08*)LO_CACHE))
		ATA_SW_Reset2();

	u16 *pList = (u16*) ( (u08*)LO_CACHE + offset);  // again put offset here as it needs not to begin on sector boundary
	index = index % (SECTORSIZE/sizeof(u16));        // cut off rest of index that already is in other sectors
	return pList[index];
}

#endif //Sattelite
/****************************************************************************************/

void pl_disp(u16 index, u08 sel)
{
	YADL_PLAY_LIST_ENTRY *pEntry = get_pl_entry(index);
	if (index < playlist_qty)
	{
		Vlcd_puts(pEntry->name);					// print on LCD
#ifdef ENABLE_UART
		if(sel)								// if current index
			uprintf("\rPlaylist: %s     ",pEntry->name);		// print on terminal
#endif
	}
}

/****************************************************************************************/

void se_disp(u16 index, u08 sel)
{
	YADL_SONG_BASE_ENTRY *pEntry = get_song_entry(index);
	if (index < songbase_qty)
	{
		Vlcd_puts(pEntry->artist);
		Vlcd_putchar('\n');
#ifdef GRAPH_LCD
		Vlcd_putchar((sel) ? 0x1f : ' ');
#else
		Vlcd_putchar((sel) ? '~' : ' ');
#endif
		Vlcd_puts(pEntry->title);			// print title
#ifdef ENABLE_UART
		if (sel)
			uprintf("\rSong: %s / %s     ",pEntry->artist,pEntry->title);
#endif
	}
}

/****************************************************************************************/

void lo_disp(u16 index, u08 sel)
{
	se_disp(get_offset_entry(index,selected_Playlist),sel);
}

/****************************************************************************************/

void menu_disp(u16 index, u08 sel)
{
	extern u08 *function_name[];
	Vlcd_progputs(function_name[index]);		// print on LCD
}

/****************************************************************************************/

u16 browse_list(u16 index, u16 min, u16 max, void (*disp)(u16, u08))
{
	u08 i,j = 0;
	event_e event = 0;
#ifdef NUMERICAL_KEYS
	extern u08 number_key;
	u16 number = 0;
#endif
#if(LCD_TYPE == 8)
	lcd_clrline(7);
#endif
	u08 k = (*disp == lo_disp) ? LCD_LINES/2 : LCD_LINES;
	while (1)
	{
		for (i=0; i < k; i++)
		{
			idle();
#ifdef GRAPH_LCD
			if (k == LCD_LINES/2)
				lcd_clrline(i*2 + 2);
			lcd_clrline(i * (1+(*disp == lo_disp))+1);
			Vlcd_putchar((i==j) ? 0x1f : ' ');
#else
			if (k == LCD_LINES/2)
				lcd_clrline(i*2 + 1);
			lcd_clrline(i * (1+(*disp == lo_disp)));
			Vlcd_putchar((i==j) ? '~' : ' ');
#endif
			disp(index+i,(i==j));
		}							// is current and valid

#ifdef NUMERICAL_KEYS
 #ifdef GRAPH_LCD
		Vlcd_gotoxy(LCD_LINE_LENGTH-5,LCD_LINES+1);		// Number print position
		if (number)						// if valid number
			lprintf("%5u", number);				// Print actual number value
		else
			Vlcd_progputs(PSTR("     "));			// Clear printed value if error or timeout
 #else
		Vlcd_gotoxy(LCD_LINE_LENGTH-5,LCD_LINES-1);		// Number print position
		if (number)						// if valid number
			lprintf("%5u", number);				// Print actual number value
 #endif
#endif // NUMERICAL_KEYS						// but if number is valid, selected item

		do 
		{
			time_flag = 0;
			event = get_event();
			switch (event)
			{
#ifdef ROTTARY_CONTROL
				case EV_DOWN:
#else
				case EV_NEXT:
				case EV_FFWD:
				case EV_UP:
#endif
					if ( index+j > min )
					{
						if(j)
							 j--;
						else
							index--;
					}
					else event = EV_IDLE;
					break;
#ifdef ROTTARY_CONTROL
				case EV_UP:
#else
				case EV_PREV:
				case EV_FREW:
				case EV_DOWN:
#endif
					if ( index+j+1 < max )
					{
						if(j < k - 1)
							j++;
						else
							index++;
					}
					else event = EV_IDLE;
					break;
				case EV_PLAY:
					return index+j;

				case EV_STOP:
					return -1;
#ifdef NUMERICAL_KEYS
				case EV_NUMBER:
					number = ((number*10)+number_key);	// Calculate new number
					if (number <= max)			// If valid
					{
						if (number > min)		// Validation for minimum
						{
							j=0;
							index = number-1;	// select and display selected item
						}
					}
					else 	number = 0;			// clear bad number

					nKeyTime = 0;
					break;
#endif
			}
#ifdef NUMERICAL_KEYS
			if (nKeyTime > 15 && number)		// number entering timeout (1.5 sec)
			{
				number = 0;
				event = EV_LASTEVENT; 		// for display update
			}
#endif
		}
		while (event == EV_IDLE);
	}
}


/****************************************************************************************/

void lcd_centerprint(u08 y, u08 *data, u08 mode)
{
	u08 i,j;
#ifdef GRAPH_LCD
	if(mode%2 == 0)
		Vlcd_invert();
#endif
	Vlcd_gotoxy(0,y);
	i = (mode<2) ? strlen_P(data) : strlen(data);
	if(i < LCD_LINE_LENGTH)
	{
		j = (LCD_LINE_LENGTH-i);
#ifdef GRAPH_LCD
		if (j%2 == 1)
		{
			i = 3;
			while(i--)
				Vlcd_wrdata((mode%2 == 0) ? 127 : 0);
		}
#endif
		j /= 2;
		for(i=0; i<j; i++)
#ifdef GRAPH_LCD
			Vlcd_putchar(' ');
#else
			Vlcd_putchar('-');
#endif
	}
	else j=0;

	if (mode<2)
		Vlcd_progputs(data);
	else
		Vlcd_puts(data);

	for(i=0; i<=j; i++)
#ifdef GRAPH_LCD
		Vlcd_putchar(' ');
		Vlcd_normal();
#else
		Vlcd_putchar('-');
#endif
}


u08 browse_playlist(void)
{
	Send_state(STATE_PL_SELECT);
#ifdef GRAPH_LCD
	lcd_centerprint(0, PSTR("SELECT LIST"),0);
#endif
	if (curPlaylist == 0xffff)
		curPlaylist = 0;
	selected_Playlist = browse_list(curPlaylist, 0, playlist_qty, pl_disp);
	if (selected_Playlist != 0xffff)
		return 0;
	return 1;
}


/****************************************************************************************/

u16 browse_songs(void)
{
	Send_state(STATE_SO_SELECT);
#ifdef GRAPH_LCD
	lcd_centerprint(0, PSTR("SELECT SONG"),0);
#endif
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(selected_Playlist);
	u16 entry_qty = pListEntry->entry_qty;
	return (browse_list((curPlaylist == selected_Playlist) ? curIndex : 0, 0, entry_qty, lo_disp));
}


/****************************************************************************************/

u16 browse_menu(void)
{
	Send_state(STATE_MENU);
#ifdef GRAPH_LCD
	lcd_centerprint(0, PSTR("- M E N U -"),0);
#endif


#ifdef FOUR_KEYS_CONTROL
	return (browse_list((menu_event) ? menu_event-1 : 2, 2, 14, menu_disp));
#else
	return (browse_list((menu_event) ? menu_event-1 : 8, 8, 14, menu_disp));
#endif
}


/****************************************************************************************/


void lcd_frame(void)				// show song info and progressbar frame
{
#ifdef GRAPH_LCD
	if(isPlaying && info_flag < 3)
	{
		Vlcd_clrscr();
		lcd_centerprint(0,scroll_line,2);
#if(LCD_TYPE == 7)
		lprintf("\n%s    \n%s\n#%u/%u", artistname, titlename, curIndex+1, ListQty);
#else
		Vlcd_putchar('\n');
		if(scroll_length <= LCD_LINE_LENGTH)
		{
			Vlcd_progputs(PSTR("Now playing:\n"));
			Vlcd_puts(artistname);
		}
		else
		{
			Vlcd_puts(artistname);
			Vlcd_putchar('\n');
			Vlcd_puts(artistname + LCD_LINE_LENGTH);
		}
		Vlcd_putchar('\n');
		Vlcd_puts(titlename);
		if(scroll_length_2 > LCD_LINE_LENGTH)
		{
			Vlcd_putchar('\n');
			Vlcd_puts(titlename + LCD_LINE_LENGTH);
		}
		Vlcd_gotoxy(0,6);
		lprintf("PL:%u/%u\nSO:%u/%u", curPlaylist+1, playlist_qty, curIndex+1, ListQty);
#endif
		status_display();
		time_flag = 5;				// provide fast display refresh
		OldSteps = -1;
		OldPlayTime = -1;
	}
	else
		set_event(EV_STOP);

#else // not GRAPH_LCD

#if (LCD_LINES != 2)
	if(isPlaying && info_flag < 3)
	{
		Vlcd_clrscr();
		lcd_centerprint(0,scroll_line,2);
		Vlcd_putchar('\n');
		Vlcd_puts(artistname);
		Vlcd_putchar('\n');
		Vlcd_puts(titlename);
	}

#endif //(LCD_LINES == 4)

	if(isPlaying && !info_flag)
	{
#ifndef SATTELITE
		u08 i;
		Vlcd_command(0x48);			// start definition of CG-RAM from char code 1

		for (i = 0; i < 7; i++)
			lcd_data1f();			// value for full bar char (1)
		lcd_data00();				// cursor line

		lcd_data1f();				// empty bar definition (2) (frame)
		for (i = 0; i < 5; i++)
			lcd_data00();
		lcd_data1f();
		lcd_data00();				// cursor line

		lcd_data1f();				// empty ended bar definition (3) (frame end)
		for (i = 0; i < 5; i++)
			Vlcd_data(0x01);
		lcd_data1f();
		lcd_data00();				// cursor line

		Vlcd_gotoxy(0, LCD_LINES -1);		// progressbar position

		for (i=0; i< (LCD_STEPS / 5) - 1; i++)	// display progress bar outline
			Vlcd_putchar(2);	
		
		Vlcd_putchar(3);			// end of progressbar

#endif // SATTELITE
		time_flag = 5;				// provide fast display refresh
		OldSteps = -1;
		OldPlayTime = -1;
	}
#endif // GRAPH_LCD
	Send_state(STATE_RETURN);
}


//
// Run this as often as possible
// preferably every time around the main loop
//
void idle(void)
{
	usb_handler();
	if(usb_link == 0)					// usb link disables other control
		control_handler();
#ifdef SATTELITE
	else if(scroll_time >= 30)
	{
		uart_pc1(SAT_CMD_MARKER);
		uart_pc1(SAT_LINKHOLDER);
		scroll_time = 0;
	}
#endif

#ifdef ENABLE_FORD_ACP
	acp_handler(isPlaying,bLoudness,bRandom);
#endif

	//	
	//
	//
	if (isPlaying)
	{

#ifdef VOL_UP_RAMP
		volatile u08 otim;
		if (volume_ramp != 0 && scroll_time != otim)
		{
			if(otim%2 == 1)
			{
				volume_ramp--;			// increase volume
				setvolume(volume);		// update volume
			}
			otim = scroll_time;
		}
#endif

		//
		// time to update a buffer ?
		//
		if (updbuf && (!usb_play))
		{
			load_sectors(updbuf);
			updbuf = (u08 *) 0;				// mark as done
		}
#ifdef FAST_IDLE_DISK
		else
		{	
			if (isPlaying)
				ATA_Read(MySector, 1, (u08*) BBK_MEMORY);
		}
#endif	
		// pump some data to the decoder
		
		while (bit_is_set(PINB, PB2) && (!updbuf))		// while DREQ is hi 
		{							// and buffer no need reload
			//send data on SPI bus
			vs1001_send32(outptr);
			outptr += 32;

			// check for buffer wrap
			if (outptr == buffer2)				// buffer 1 empty
			{
				updbuf = buffer1;			// buffer 1 need reload
				if (usb_play)
					usb_response(0);
			}
			else if (outptr == buffer3)			// buffer 2 empty
			{
				updbuf = buffer2;			// buffer 2 need reload
				if (usb_play)
					usb_response(0);
				outptr = buffer1;			// play from buffer 1
			}

			fileplayed++;

			// check if we're done
			if (fileplayed >= filesize)
			{
				if (!usb_play)
				{
					isPlaying = 0;			// the end is near 
					if (info_flag == 4)		// if select song menu active
						set_event(EV_PLAY);	// exit the menu and play selected song
					else				// at normal condition
						next_song(0);		// play next song from current playlist
				}
				break;
			}
		}

		if (vol_decrease && (time_flag == 4 || time_flag == 8))	// If fast forward volume downed
		{
			vs1001_setvolume(volume,balance);		// Restore volume
			vol_decrease = 0;
		}

#ifndef GRAPH_LCD

// *****************************************************************************
//			 SCROLLING ON 2 LINES LCD's
// *****************************************************************************

#if (LCD_LINES == 2)

		// scrolling functions
		if ((scroll_time >= SCROLL_SPEED) && (info_flag < 3))
		{
			scroll_time = 0;
			u08 nTemp;

			//
			// scrolling playlist name, artist and song name on 2 lines LCD

			Vlcd_gotoxy(0, 0);
			for (nTemp = 0; nTemp < LCD_LINE_LENGTH; nTemp++)
#ifdef ALTERNATE_SCROLL
				Vlcd_putchar(scroll_line[scroll_pos + nTemp]);

			if (scroll_pos + LCD_LINE_LENGTH == scroll_length)
				scroll_dir -= 2;
			if (scroll_pos == 0)
				scroll_dir++;
			scroll_pos += (signed char)scroll_dir / 4;

#else //ALTERNATE_SCROLL
				Vlcd_putchar(scroll_line[(scroll_pos + nTemp) % scroll_length]);
			scroll_pos++;
#endif //ALTERNATE_SCROLL
		}

#endif //LCD_LINES == 2

// *****************************************************************************
//			 SCROLLING ON 4 LINES LCD's
// *****************************************************************************

#if (LCD_LINES == 4)

		// scrolling functions
		if ((scroll_time >= SCROLL_SPEED) && (info_flag < 3))
		{
			scroll_time = 0;
			u08 nTemp;

			// scrolling artist and name on 4 lines LCD

			if (scroll_length > LCD_LINE_LENGTH)
			{
				Vlcd_gotoxy(0, 1);
				for (nTemp = 0; nTemp <  LCD_LINE_LENGTH; nTemp++)
#ifdef ALTERNATE_SCROLL
					Vlcd_putchar(artistname[scroll_pos + nTemp]);

				if (scroll_pos + LCD_LINE_LENGTH == scroll_length)
					scroll_dir -= 2;

				if (scroll_pos == 0)
					scroll_dir++;

				scroll_pos += (signed char)scroll_dir / 4;

#else //ALTERNATE_SCROLL
					Vlcd_putchar(artistname[(scroll_pos + nTemp) % scroll_length]);

				scroll_pos++;
#endif //ALTERNATE_SCROLL
			}
			if (scroll_length_2 > LCD_LINE_LENGTH)
			{
				Vlcd_gotoxy(0, 2);
				for (nTemp = 0; nTemp < LCD_LINE_LENGTH; nTemp++)
#ifdef ALTERNATE_SCROLL
					Vlcd_putchar(titlename[scroll_pos_2 + nTemp]);

				if (scroll_pos_2 + LCD_LINE_LENGTH == scroll_length_2)
					scroll_dir_2 -= 2;

				if (scroll_pos_2 == 0)
					scroll_dir_2++;

				scroll_pos_2 += (signed char)scroll_dir_2 / 4;

#else //ALTERNATE_SCROLL
					Vlcd_putchar(titlename[(scroll_pos_2 + nTemp) % scroll_length_2]);

				scroll_pos_2++;
#endif //ALTERNATE_SCROLL

			}
		}

#endif //LCD_LINES == 4

// *****************************************************************************
//		 DISPLAY BAR AND TIME ON ALPHANUMERIC LCD's
// *****************************************************************************

		//
		// display bar function
		if ((s08)time_flag >= 5 && !info_flag)
		{
			u08 nSteps = (u08)((fileplayed * (LCD_STEPS-1)) / filesize);
			if(nSteps != OldSteps)					// progressbar need update ?
			{							// this check is for for CPU time saving
#ifdef SATTELITE
				Vlcd_bar(nSteps,LCD_STEPS);
#else
				static u08 data[] = { 0x10, 0x18, 0x1C, 0x1E, 0x1F };
				u08 i;
				u08 a = nSteps / 5;					// # of full bars
				Vlcd_command(0x40);

				lcd_data1f();					// full top line (frame outline)
				for (i = 0; i < 5; i++)				// value for current progress char (0)
				{
					Vlcd_data(data[nSteps % 5] | (a == (LCD_STEPS / 5) - 1));
				}
				lcd_data1f();					// full bottom line (frame outline)
				lcd_data00();					// cursor line

				Vlcd_gotoxy(0,LCD_LINES - 1);
	
				for (i = 0; i < a; i++)
					Vlcd_putchar(1);			// print full bars

				if (a <= (LCD_STEPS / 5) - 1)			// jman to fix display overwrite
				{
					Vlcd_putchar(0);	
					i++;
					for (; i< (LCD_STEPS / 5) - 1; i++)	// display progress bar outline
						Vlcd_putchar(2);	
					if(i < LCD_STEPS / 5)	
						Vlcd_putchar(3);		// end of progressbar
				}

#ifdef UART_PROGRESSBAR
				uart_progputs(PSTR("\r["));			// uart progressbar function
				for (i=0; i < LCD_STEPS - 2; i+=2)
					uart_putchar((i<nSteps) ? '*' : ' ');
				uart_putchar(']');
#endif
#endif // SATTELITE
				OldSteps = nSteps;
			}


			//
			// printing song time 

			u16 wPlayTime = playtime + addtime; 

			if(wPlayTime != OldPlayTime)
			{
				OldPlayTime = wPlayTime;
				Vlcd_gotoxy(LCD_LINE_LENGTH - 6, LCD_LINES - 1);	// time display position
#ifdef UART_SONGTIME
				uprintf("%3u:%02u\b\b\b\b\b\b", wPlayTime / 60, wPlayTime % 60); // print time on UART
#endif

				if (timemode == 1)
				{
					wPlayTime = songtime - wPlayTime + 1;	// calculate time remain
					if ((s16)wPlayTime < 0)
						wPlayTime = 0;
				}
				lprintf("%3u:%02u", wPlayTime / 60, wPlayTime % 60); // print time on LCD

#ifdef ENABLE_FORD_ACP
				acp_displaytime(cur_disc, curIndex+1, wPlayTime);
#endif
				if (timemode == 1)				// add a '-' sign to time remain
				{
					Vlcd_gotoxy(LCD_LINE_LENGTH - 6 + (wPlayTime < 600), LCD_LINES - 1);
					Vlcd_putchar('-');
				}

				if (bLoudness < 128 && vs1001_fw)
					vs1001_write(0x0D,bLoudness);		// Rewrite loudness settings
			}							// if VS1001 do selfreset

			if (menu_event == EV_IDLE && !info_flag)
				time_flag = 0;
		}

#endif // not GRAPH_LCD

// *****************************************************************************
//		 VISUALISATION ON GRAPHIC LCD
// *****************************************************************************

#ifdef GRAPH_LCD

		if ((scroll_time >= SCROLL_SPEED) && (info_flag < 3))
		{
			scroll_time = 0;
#if(LCD_TYPE == 7)
			u08 nTemp;
			if (scroll_length > LCD_LINE_LENGTH)
			{
				Vlcd_gotoxy(0, 1 + 1*(LCD_TYPE==8));
				for (nTemp = 0; nTemp <  LCD_LINE_LENGTH; nTemp++)
 #ifdef ALTERNATE_SCROLL
					Vlcd_putchar(artistname[scroll_pos + nTemp]);

				if (scroll_pos + LCD_LINE_LENGTH == scroll_length)
					scroll_dir -= 2;

				if (scroll_pos == 0)
					scroll_dir++;

				scroll_pos += (signed char)scroll_dir / 4;

 #else //ALTERNATE_SCROLL
					Vlcd_putchar(artistname[(scroll_pos + nTemp) % scroll_length]);

				scroll_pos++;
 #endif //ALTERNATE_SCROLL
			}
			if (scroll_length_2 > LCD_LINE_LENGTH)
			{
				Vlcd_gotoxy(0, 2 + 1*(LCD_TYPE==8));
				for (nTemp = 0; nTemp < LCD_LINE_LENGTH; nTemp++)
 #ifdef ALTERNATE_SCROLL
					Vlcd_putchar(titlename[scroll_pos_2 + nTemp]);

				if (scroll_pos_2 + LCD_LINE_LENGTH == scroll_length_2)
					scroll_dir_2 -= 2;

				if (scroll_pos_2 == 0)
					scroll_dir_2++;

				scroll_pos_2 += (signed char)scroll_dir_2 / 4;

 #else //ALTERNATE_SCROLL
					Vlcd_putchar(titlename[(scroll_pos_2 + nTemp) % scroll_length_2]);

				scroll_pos_2++;
 #endif //ALTERNATE_SCROLL
			}
#endif //(LCD_TYPE == 7)
		}

// *****************************************************************************
//		 DISPLAY BAR AND TIME ON GRAPHIC LCD
// *****************************************************************************

		if ((s08)time_flag >= 5 && info_flag < 3)
		{
#if(LCD_TYPE == 7)
 #define BARLEN (LCD_LINE_LENGTH*6)
#else
 #define BARLEN ((LCD_LINE_LENGTH-6)*6 - 2)
#endif
			u08 nSteps = (u08)((fileplayed * (BARLEN - 1)) / filesize);
			if(nSteps != OldSteps)					// progressbar need update ?
			{							// this check is for for CPU time saving
				Vlcd_gotoxy(0,4 + 1*(LCD_TYPE==8));
				Vlcd_bar(nSteps,BARLEN - 2);

				if(!info_flag)
					status_display();
#ifdef UART_PROGRESSBAR
				register u08 i;
				uart_progputs(PSTR("\r["));			// uart progressbar function
				for (i=0; i < BARLEN - 2; i+=3)
					uart_putchar((i<nSteps) ? '*' : ' ');
				uart_putchar(']');
#endif
				OldSteps = nSteps;
			}

			//
			// printing song time 
			u16 wPlayTime = playtime + addtime;

			if(wPlayTime != OldPlayTime)
			{
				OldPlayTime = wPlayTime;
				Vlcd_gotoxy(LCD_LINE_LENGTH - 6, LCD_LINES - 1);	// time display position
#ifdef UART_SONGTIME
				uprintf("%3u:%02u\b\b\b\b\b\b", wPlayTime / 60, wPlayTime % 60); // print time on UART
#endif

				if (timemode == 1)
				{
					wPlayTime = songtime - wPlayTime + 1;	// calculate time remain
					if ((s16)wPlayTime < 0)
						wPlayTime = 0;
				}
				lprintf("%3u:%02u", wPlayTime / 60, wPlayTime % 60); // print time on LCD

				if (timemode == 1)				// add a '-' sign to time remain
				{
					Vlcd_gotoxy(LCD_LINE_LENGTH - 6 + (wPlayTime < 600), LCD_LINES - 1);
					Vlcd_putchar('-');
				}

				if (bLoudness < 128 && vs1001_fw)
					vs1001_write(0x0D,bLoudness);		// Rewrite loudness settings
			}
									// if VS1001 do selfreset
			if (menu_event == EV_IDLE && !info_flag)
				time_flag = 0;
		}

#endif //GRAPH_LCD 

// ******************************   VISUALIZATION END   *********************************


	}//if (isPlaying)

	if(((s08)time_flag > 30) && (info_flag || menu_event))		// display overvrite timer ends
	{
		info_flag = 0;						// enable status updating
		lcd_frame();						// show progress bar and other data on 4 lines lcd
		menu_event = EV_IDLE;
		if(!isPlaying)
			set_event(EV_STOP);
	}

}

void start_playing(void)
{
	outptr = buffer1;
	isPlaying = 1;
	OldSteps = -1;
	updbuf = 0;
	vs1001_reset(0);
	LoudSet();
#ifdef OLD_VS1001
	wPlayT = 0;
#endif
}


void create_scroll_data(void)
{

#if (LCD_LINES == 2)
	strcat(scroll_line, " -> ");			// playlist name separator
	strcat(scroll_line, artistname);
	strcat(scroll_line, " - ");			// add artist separator
	strcat(scroll_line, titlename);
#ifndef ALTERNATE_SCROLL
	strcat(scroll_line, " >> ");			// add ' >> ' sign
#else
	scroll_dir = 0;
#endif
	scroll_pos = 0;
	scroll_length = 0;				// Calculate scroll length
	u08* src = scroll_line;
	while (*src++)
		scroll_length++;

#else // LCD_LINES == 4
	scroll_length = strlen(artistname);
	scroll_length_2 = strlen(titlename);

#if(LCD_TYPE != 8)
 #ifdef ALTERNATE_SCROLL
	scroll_dir = scroll_dir_2 = 0;
 #else
	if (scroll_length > LCD_LINE_LENGTH)
	{
		strcat(artistname, " >> ");		// add ' >> ' sign
		scroll_length += 4;		
	}
	if (scroll_length_2 > LCD_LINE_LENGTH)
	{
		strcat(titlename, " >> ");		// add ' >> ' sign
		scroll_length_2 += 4;
	}
 #endif // ifdef ALTERNATE_SCROLL

	scroll_pos = scroll_pos_2 = 0;
#endif // (LCD_TYPE != 8)
#endif // LCD_LINES 
}


void play_song(void)
{
	u08 *src;
	udiv_t divt;
	if(!info_flag)
	{
		Vlcd_clrscr();
		Vlcd_progputs(PSTR("Loading..."));
	}

	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(curPlaylist);
	ListQty = pListEntry->entry_qty;
	if(curIndex >= ListQty)
		curIndex = 0;

	strcpy(scroll_line, pListEntry->name);			// playlist name
	u16 curSong = get_offset_entry(curIndex,curPlaylist);
	YADL_SONG_BASE_ENTRY *pEntry = get_song_entry(curSong);

	if(pEntry->state != YADL_STATE_READY)			// check for valid song entry
	{
		Vlcd_gotoxy(0,0);
		both_progputs(PSTR("\nSongBase Error !"));
		Send_state(STATE_ERROR);
		delayms(1000);
		set_event(EV_STOP);
		return;
	}

	Send_state(STATE_PLAYING);
	strcpy(artistname, pEntry->artist);
	strcpy(titlename, pEntry->title);

	src = titlename + strlen(titlename);
	*src++ = ' ';
	*src++ = '(';
	divt = udiv(pEntry->play_time, 600);
	u08 s = (u08)divt.quot % 10;
	if (s)
		*src++ = '0' + s;				// song time up to 99 min
	divt = udiv(divt.rem, 60);
	*src++ = '0' + (u08)divt.quot;
	*src++ = ':';
	divt = udiv(divt.rem, 10);
	*src++ = '0' + (u08)divt.quot;
	*src++ = '0' + (u08)divt.rem;			
	*src++ = ')';
	*src = 0;

	songtime = pEntry->play_time;				// get playing time of current song
	u16 br = pEntry->bitrate;				// get bitrate
	
	//
	// calc number of VS1001 blocks
	//
	filesize = pEntry->length / 32;				// calculation number of blocks
	fileplayed = 0;
	addtime = 0;						// for search time calculations

	//
	// preload buffers
	//
	init_load_sectors(pEntry->start);
	BackStepPos = 0;					// init cluster tabele counter
	Rev_Table[BackStepPos] = pEntry->start;			// save first cluster number of song to be played
	bitrate = (br & BITRATE_MASK);				// mask OPTIONS in bitrate

#ifdef SONGPOS_RESTORE

	union u32convert FatData;
	if ((curSong = eeprom_rw(EEPROM_STARTPOS)) != 0xffff)	// if eeprom has saved offset from begin of song
	{
		while(curSong--)
		{
			FatData.value = next_fat(MyCluster);	// skip number of clusters saved in EEPROM_STARTPOS
			if(FatData.bytes.byte4 != 0) break;	// protect for bad value in eeprom
			init_load_sectors(FatData.value);	// update cluster value
		}

		eeprom_ww(EEPROM_STARTPOS, 0xffff);		// clear offset in eeprom
	}

	// calculate new size of played data
	fileplayed = BackStepPos * (YADL_CLUSTERSIZE / 32);

	// calculation of playing time
	addtime = (u16)(fileplayed*32 / (bitrate * 125));


#endif
	load_sectors(buffer1);
	load_sectors(buffer2);

#ifdef ENABLE_UART
	u08 *brstr = (br > OPTION_BR_VBR) ? "VBR, average " : "";	// test VBR signature
	uprintf("\n\nSong: %u ,  %s - %s\nPlaying Time %u:%02u,  Bitrate %s%ukbps\n",
		 curIndex+1, artistname, titlename, songtime / 60, songtime % 60, brstr, bitrate);
#endif
	create_scroll_data();					// create scroll line data

	//
	// start playing the song
	//
#ifdef ENABLE_FORD_ACP
	eeprom_ww(EEPROM_PLAYLIST+(cur_disc*2),curPlaylist);			// save playlist number
	eeprom_ww(EEPROM_SONGPOS+(cur_disc*2),curIndex);			// save song number within current playlist
#else
	eeprom_ww(EEPROM_PLAYLIST,curPlaylist);			// save playlist number
	eeprom_ww(EEPROM_SONGPOS,curIndex);			// save song number within current playlist
#endif
	start_playing();					
	lcd_frame();						// display song info on 4 lines lcd and progress bar outline
}

void plist_info(YADL_PLAY_LIST_ENTRY * pListEntry)		// print info about playlist on terminal
{
#ifdef ENABLE_UART
	uprintf("\n\nPlaylist: %s ,  Playlist Time %u:%02u:%02u\n",
		pListEntry->name, pListEntry->length_hours, 
		pListEntry->length_minutes, pListEntry->length_seconds);
#endif
}

#ifdef ENABLE_FORD_ACP
u08 plist_change(u08 changedisc)	// CD Changer disc number 1 - 6
{	
	u08 old_disc = cur_disc;
	u16 oldIndex = curIndex;
	u16 oldPlaylist;
	
	if(cur_disc != changedisc)
	{
		oldPlaylist = curPlaylist;
		curPlaylist = eeprom_rw(EEPROM_PLAYLIST+(changedisc*2));
		cur_disc = changedisc;
		
		YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(curPlaylist);
		if((pListEntry->name[0] - '0') != changedisc)
		{
			next_playlist();
			if(cur_disc!=changedisc)
			{
				cur_disc=old_disc;
				curIndex=oldIndex;
				curPlaylist = oldPlaylist;
				return(changedisc | 0x80); // Flag as failed disc change
			}
		}
		cur_disc = changedisc;
		curIndex = eeprom_rw(EEPROM_SONGPOS+(changedisc*2));
		eeprom_wb(EEPROM_DISC, cur_disc);
	} else
	{
		next_playlist();
	}
	
	play_song();
	
	return (cur_disc);
}

u08 get_disc(void)
{	
	return(cur_disc);
}

u08 set_disc(YADL_PLAY_LIST_ENTRY *pListEntry)
{	
	cur_disc = pListEntry->name[0] - '0';
	
	if(cur_disc<1 || cur_disc>6) cur_disc=0;
	
	return(cur_disc);
}

#endif
void next_playlist(void)
{
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(curPlaylist);
	u16 oldPlaylist;
	
	oldPlaylist=curPlaylist;
	
AGAIN:
	if(pListEntry->next_playlist != 0xffff)				// check for next playlist number
		curPlaylist = pListEntry->next_playlist;
	else
		curPlaylist++;

	if((curPlaylist == 0xffff) || (curPlaylist >= playlist_qty))
		curPlaylist = 0;
	
	pListEntry = get_pl_entry(curPlaylist);

#ifdef ENABLE_FORD_ACP
	if (curPlaylist!=oldPlaylist && oldPlaylist!=0xffff)
	{
		if ((pListEntry->name[0] - '0') != cur_disc) goto AGAIN;
	}
	set_disc(pListEntry);
#endif

	plist_info(pListEntry);						// print pl info
	InitRnd();						// init randomizer table
	if (bRandom)
		curIndex = do_rand(pListEntry->entry_qty);
	else
		curIndex = 0;
}

void prev_playlist(void)
{
	if(--curPlaylist == 0xffff)					// playlist down
		curPlaylist = playlist_qty - 1;			// go to last playlist
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(curPlaylist);	// update playlist data
	plist_info(pListEntry);						// print pl info
	InitRnd();						// init randomizer table
	if (bRandom)
		curIndex = do_rand(pListEntry->entry_qty);
	else
		curIndex = pListEntry->entry_qty-1;
	
#ifdef ENABLE_FORD_ACP
	set_disc(pListEntry);
#endif
		
}

void next_song(u08 mode)
{
	YADL_PLAY_LIST_ENTRY *pListEntry = get_pl_entry(curPlaylist);

	if (Repeat == 3 && mode == 0)			// repeat one song
		goto GO_PLAY;

	if (mode == 2)
	{
#ifdef NEW_PREW
		if(BackStepPos)
			goto GO_PLAY;
		else
#endif
			curIndex = (bRandom) ? do_rand(pListEntry->entry_qty) : curIndex-1;
	}
	else
		curIndex = (bRandom) ? do_rand(pListEntry->entry_qty) : curIndex+1;


	if (curIndex < (pListEntry->entry_qty))	// if End of playlist
		goto GO_PLAY;
	else
	{
		InitRnd();

		if(Repeat == 2)				// repeat playlist
		{
			if (bRandom)
				curIndex = do_rand(pListEntry->entry_qty);
			else
				curIndex = 0;
			goto GO_PLAY;
		}

		if(Repeat == 0)
		{
			set_event(EV_STOP);		// normal play, stop after end of playlist
			return;
		}

		if(Repeat == 1)				// normal play, next playlist after end of playlist
		{
			if (mode == 2)
				prev_playlist();
			else
				next_playlist();

GO_PLAY:		play_song();
		}
	}
}



void disp_mod(u08 mod)					// display ON/OFF information
{
#ifdef GRAPH_LCD
	status_display();
#else
	Vlcd_progputs((mod) ? PSTR("N ") : PSTR("FF"));
	time_flag = 0;					// prevent display overvrite
	info_flag = 1;					// allow scroll
#endif
}

//----------------------------------------------------------------------------
// Main part
//----------------------------------------------------------------------------
int main(void) 
{
 
 //------------------------------
 // Initialize 
 //------------------------------

//////////////////////////////////////////////////////////////////
// B - Port
//////////////////////////////////////////////////////////////////
/*
	sbi(PORTB, 0);	// DIOW- hi
	sbi(DDRB, 0);	// pin PB0 is output, DIOW- 
	sbi(PORTB, 1);	// DIOR- hi
	sbi(DDRB, 1);	// pin PB1 is output, DIOR- 
	cbi(DDRB, 2);	// pin PB2 is input, DEMAND
	sbi(PORTB, 2);	// activate pullup
	
	// PB3 and PB4 is used for BSYNC and MP3 signals to VS1001

	// PB5 (MOSI) is used for SPI
	// PB6 (MISO) is used for SPI
	// PB7 (SCK) is used for SPI
*/	
	outp(0x07, PORTB);
	outp(0x03, DDRB);


//////////////////////////////////////////////////////////////////
// D - Port
//////////////////////////////////////////////////////////////////

	// PD0 and PD1 are TX and RX signals
/*
	sbi(PORTD,PD3);		// pin PD3 is keyboard input, enable pullup
	sbi(PORTD,PD4);		// PD4 is available but need a pullup to avoid noise
	sbi(PORTD,PD5);		// PD5
	
	// PD6 and PD7 are RD and WR signals
	// but we need to set their default states used
	// when the external memory interface is disabled
	// they should then both be high to avoid disturbing
	// RAM contents
	
	sbi(DDRD, 6);		// as outputs
	sbi(DDRD, 7);

	sbi(PORTD, 6);		// and both hi
	sbi(PORTD, 7);
*/

#ifndef ENABLE_FORD_ACP
	outp(0xff, PORTD);
	outp(0xC0, DDRD);
#else
	outp(0xc4, DDRD);  // PD2 is used as the TX_ENABLE for RS485
	outp(0xfb, PORTD); // Default to disabled.  0xfb
#endif

	// PORTE need setup of ALE in idle mode

	outp(0x01, PORTE);
	outp(0x06, DDRE);
/*
	cbi(DDRE, PE0);		// PE0 is IR input
	sbi(PORTE, PE0);	// activate pullup
	sbi(DDRE, PE1);		// set ALE pin as output
	cbi(PORTE, PE1);	// and set it low (inactive)
*/
//////////////////////////////////////////////////////////////////
// USB
//////////////////////////////////////////////////////////////////

	usb_init();


//////////////////////////////////////////////////////////////////
// Timer 1
//////////////////////////////////////////////////////////////////

	//
	// setup timer1 for a 100mS periodic interrupt
	//	
	
	outp(0, TCCR1A);
	outp(4, TCCR1B);	// prescaler /256  tPeriod = 32 uS
	outp(TI1_H, TCNT1H);	// load counter value hi
	outp(TI1_L, TCNT1L);	// load counter value lo


 //----------------------------------------------------------------------------
 // 
 //----------------------------------------------------------------------------

	
    // enable external SRAM and wait states 

	outp((1<<SRE)|(1<<SRW10), MCUCR);

#if defined(ENABLE_UART) || defined(SATTELITE)
	uart_init(UART_BAUD_SELECT);		// init RS-232 link
#endif

#ifdef ENABLE_FORD_ACP
	acp_uart_init(UART_BAUD_SELECT);	// init RS-485 link
#endif

	delayms(100);

#ifdef SATTELITE
	u08 i = 10;
	while(Sattelite_init() && i--);
#else
	Vlcd_init(0, LCD_FUNCTION_DEFAULT, (LCD_LINES<<8)+LCD_LINE_LENGTH); 	// does clrscr too
#endif
	delayms(20);

#ifdef GRAPH_LCD
	Vlcd_contrast(GRAPHICS_LCD_CONTRAST);
	if (Vlcd_logo())
		Vlcd_progputs(PSTR("Hi, MP3 world!\n yampp-3/USB\n   Alive !"));

#else //GRAPH_LCD

 #if (LCD_LINE_LENGTH == 16)
	both_progputs(PSTR(" Hi, MP3 world!\nyampp3/USB Alive\n"));
 #else //(LCD_LINE_LENGTH == 16)
	both_progputs(PSTR("   Hi, MP3 world!\n yampp-3/USB  Alive\n"));
 #endif //(LCD_LINE_LENGTH == 16)

#endif //GRAPH_LCD

	// setup some buffers
	extern u08 ata_sbuf[512];
	SectorBuffer = ata_sbuf;
	buffer1 = (u08 *) BUFFERSTART;			// 8 k
	buffer2 = (u08 *) buffer1 + BUFFERSIZE;		// 8 k
	buffer3 = (u08 *) buffer2 + BUFFERSIZE;		// end pointer

#ifdef ENABLE_UART
	// say hello
	uart_progputs(firmver_txt);
	uart_putchar(':');
	uart_progputs(version_txt);
	uart_progputs(PSTR(" - "));
	uart_progputs(date_txt);
	uart_EOL();
#endif

#if defined(ROTTARY_CONTROL) && !defined(SATTELITE)
	rotary_init();
#endif

	// init VS1001
	vs1001_init_io();						// init VS1001
	vs1001_setcomp(F_VS1001);

	bLoudness = eeprom_rb(EEPROM_LOUDNESS) & 0x8f;
	bRandom = eeprom_rb(EEPROM_RANDOM);
	
#ifndef ENABLE_FORD_ACP
	Repeat = eeprom_rb(EEPROM_REPEAT) % 4;
	timemode = eeprom_rb(EEPROM_TIME);
	balance = eeprom_rb(EEPROM_BALANCE) & 0xfe;
#else
	Repeat = 1;
	timemode = 0;
	balance = 0;
#endif
	
	vs1001_reset(0);

	// Init and wait for drive
#ifdef ENABLE_UART
  	uart_progputs(PSTR("Disk Init... "));
#endif
	ATA_SetDrive(0);
	ATA_SW_Reset2();
#ifdef ENABLE_UART
   	uart_progputs(PSTR("Ready!\n"));
#endif
	// init randomizer from timer
	seed = 1 + inp(TCNT1L);

#ifndef ENABLE_FORD_ACP
	if ((volume = eeprom_rb(EEPROM_VOLUME)) == 255)
		volume = 12;					// -6 dB
#else
		volume = 0;
#endif

// Send three sinewave beeps to indicate we're starting up okay
#ifdef PWR_BEEPS
	LoudSet();
	send_sinewave_beeps();
#endif


#ifdef VOL_UP_RAMP
	volume_ramp = (eeprom_rb(EEPROM_AUTOPLAY)) ? (MIN_VOLUME-volume)>>1 : 0;
#endif
	ir_standard = eeprom_rb(EEPROM_IRSTAND) % STANDARDS_COUNT;	// get remote controller standard

	// enable timer1 interrupt
	sbi(TIMSK, TOIE1);	 	

	init_stuff();
	LoudSet();

#ifndef SATTELITE
	ATA_Read(4, 1, (u08*)BBK_MEMORY);			// Load user chars into temp buffer
	memcpy((u08*)LANGTAB_MEMORY, (u08*)BBK_MEMORY, 180);	// store chars to LANGTAB

	// check for pressing local "PLAY" key to enter remote IR setup procedure
	ramdisable();
	outp(0xff, DDRA);				// set port as output
	outp(0xff, PORTA);
	asm volatile("nop");				// allow time for port to activate
	if(bit_is_set(PIND, PD3))			// if not permanent short to GND
	{
		outp(0xfe, PORTA);			// set D0 pin to 0
		asm volatile("nop");			// allow time for port to activate
		if(bit_is_clear(PIND, PD3))		// if KEY 0 (PLAY) pressed
			setup_rem();			// go to remote IR setup procedure
	}
	ramenable();
#endif

	InitRnd();

	// load autoplay and position settings
	if(eeprom_rb(EEPROM_AUTOPLAY) == 1)
		set_event(EV_PLAY);
	else
		set_event(EV_STOP);
		
#ifdef ENABLE_FORD_ACP
	cur_disc = eeprom_rb(EEPROM_DISC);
	if (cur_disc>6) cur_disc=0;
	curIndex = eeprom_rw(EEPROM_SONGPOS+(cur_disc*2));
	curPlaylist = eeprom_rw(EEPROM_PLAYLIST+(cur_disc*2));
#else
	curIndex = eeprom_rw(EEPROM_SONGPOS);
	curPlaylist = eeprom_rw(EEPROM_PLAYLIST);
#endif

	if (curPlaylist >= playlist_qty)
		curPlaylist = curIndex = 0;

	ATA_Standby(HDD_STANDBY_TIME / 5);	// set automatic standby timer


///////////////////////////////////////////////////////////////////////////////
// start things rolling
///////////////////////////////////////////////////////////////////////////////

	event_e event = EV_IDLE;
	YADL_PLAY_LIST_ENTRY *pListEntry;
#ifdef ENABLE_USB_PLAYING				
	static char usb_txt[] __attribute__ ((progmem)) = "Playing via USB";
#endif
	//
	// main loop
	//
  	while (1) 
  	{
		event = get_event();

		switch (event)
		{
			default:
			case EV_IDLE: 
				break;

			case EV_PLAYLIST:
				event = EV_IDLE;
				info_flag = 3;					// disable displaying
				if (browse_playlist())				// browse playlist
					goto BROWSE_BREAK;

				uart_EOL();
				info_flag = 4;					// enable auto song change
				u16 Index = browse_songs();			// browse songs within playlist
				uart_EOL();
				if (Index == 0xffff)
				{						// browse terminate
BROWSE_BREAK:				pListEntry = get_pl_entry(curPlaylist);	// reload playlist cache
					info_flag = 0;				// enable displaying
					Vlcd_clrscr();
					if (isPlaying)
						lcd_frame();
					else
						set_event(EV_STOP);
					break;
				}
				curPlaylist = selected_Playlist;
				curIndex = Index;
				InitRnd();
				isPlaying = 0;
				
			case EV_PLAY:
				if (menu_event)
				{
					set_event(menu_event);
					time_flag = 0;
					continue;
				}
#ifndef ENABLE_FORD_ACP
				if (isPlaying)						// Pause function
				{
#ifdef OLD_VS1001
					u16 oldPlayT = wPlayT;
#endif
					while(get_event() != EV_IDLE);		// Wait for release key
					Send_state(STATE_PAUSED);
					ATA_Standby(0);				// disable automatic standby timer
					Vlcd_gotoxy(LCD_LINE_LENGTH - 6, LCD_LINES - 1);
					Vlcd_progputs(PSTR("Paused"));
#ifdef SONGPOS_RESTORE
					eeprom_ww(EEPROM_STARTPOS, BackStepPos);
#endif
					do 
					{
						control_handler();
					} while(event_queue_head == event_queue_tail);
					get_event();
					ATA_Standby(HDD_STANDBY_TIME / 5);		// enable automatic standby timer
					ATA_Read(1,1,(u08*) BBK_MEMORY);
					Send_state(STATE_PLAYING);
#ifdef SONGPOS_RESTORE
					eeprom_ww(EEPROM_STARTPOS, 0xffff);
#endif
#ifdef OLD_VS1001
					wPlayT = oldPlayT;
#endif
					break;
				}
				else								// Play function
#endif // ENABLE_FORD_ACP
				{
					if(curPlaylist < playlist_qty && playlist_qty > 0)
					{
#ifdef ENABLE_UART
						plist_info(get_pl_entry(curPlaylist));
#endif
						info_flag = 0;
						play_song();
						eeprom_wb(EEPROM_AUTOPLAY,1);			// store autoplay flag
					}
					break;
				}
#ifdef ENABLE_USB_PLAYING				
			case EV_PLAY_USB:
#ifdef ENABLE_UART
				uart_EOL();
				uart_progputs(usb_txt);
				uart_EOL();
#endif
				strcpy_P(scroll_line,usb_txt);
				usb_play = 1;
				create_scroll_data();
#ifdef ENABLE_UART
				uprintf("Song: %s - %s\r\n",artistname, titlename);
#endif
				start_playing();
				lcd_frame();
				updbuf = buffer2;	
				break;
#endif
			case EV_STOP:
				if (isPlaying)
					eeprom_wb(EEPROM_AUTOPLAY,0);		// store autoplay flag
#ifdef ENABLE_FORD_ACP
				eeprom_ww(EEPROM_STARTPOS, BackStepPos); // allow track to resume if switching to radio and back
#endif
				isPlaying = 0;
#ifdef ENABLE_USB_PLAYING
				usb_play = 0;
#endif
#ifdef VOL_UP_RAMP
				volume_ramp = 0;
#endif
				Send_state(STATE_STOP);
				vs1001_reset(0);
				vs1001_write(0x0A,0);
				Vlcd_clrscr();
#ifdef GRAPH_LCD
				if(Vlcd_logo())
					lcd_centerprint(2, (u08*)&model_txt[0], 1);

				status_display();
 #if(LCD_TYPE == 7)
				Vlcd_gotoxy(10,5);
 #else
				Vlcd_gotoxy(0,7);
 #endif
				Vlcd_progputs(PSTR("STOP"));			// Clear bitrate
#else // not GRAPH_LCD
				Vlcd_progputs((u08*)&model_txt[0]);
#if (LCD_LINE_LENGTH == 16)
				Vlcd_progputs(PSTR(" STOP"));
#else
				Vlcd_progputs(PSTR(" - STOP"));
#endif

#endif // GRAPH_LCD
				if(usb_link)
				{
					ATA_Standby(0);
#if(LCD_TYPE == 8)
					lcd_clrline(6);
					lcd_clrline(7);
#endif
					lcd_centerprint(LCD_LINES-1,PSTR("PC Link Active."),1);
					usb_response(0);
				}
				break;				

			case EV_BALANCE:
				setbalance(balance);
				break;

			case EV_DOWN:	
#ifdef ROTTARY_CONTROL
				if(menu_event == EV_FFWD || menu_event == EV_FREW)
				{
					set_event(EV_FREW);
					continue;
				}
				if(menu_event == EV_NEXT || menu_event == EV_PREV)
				{
					set_event(EV_PREV);
					continue;
				}
				if(menu_event == EV_NEXTPL || menu_event == EV_PREVPL)
				{
					set_event(EV_PREVPL);
					continue;
				}
				if(menu_event == EV_MBASS && vs1001_fw)
				{
					if(--bLoudness == 255)
					{
						if (vs1001_fw == 0x4020)
							bLoudness = 8;
						else if (vs1001_fw == 0x4200)
							bLoudness = 12;
					}
					time_flag = 0;
					goto LDSS;
				}
#endif
				if(info_flag == 2)			// volume down (or balance left)
				{
					if (balance > -38)
						balance -=2;
					setbalance(balance);
				}
				else
				{
					volume += VOL_STEP * (nKeyTime > 0x80) ? 4 : 1;
					if (volume > MIN_VOLUME) 
						volume = MIN_VOLUME;
#ifdef VOL_UP_RAMP
					if (volume_ramp)
						volume = volume + 2*volume_ramp;
					volume_ramp = 0;
#endif
					setvolume(volume);
				}
				break;

			case EV_UP: 					// volume up (or balance right)
#ifdef ROTTARY_CONTROL
				if(menu_event == EV_FFWD || menu_event == EV_FREW)
				{
					set_event(EV_FFWD);
					continue;
				}
				if(menu_event == EV_NEXT || menu_event == EV_PREV)
				{
					set_event(EV_NEXT);
					continue;
				}
				if(menu_event == EV_NEXTPL || menu_event == EV_PREVPL)
				{
					set_event(EV_NEXTPL);
					continue;
				}
				if(menu_event == EV_MBASS && vs1001_fw)
				{
					set_event(EV_MBASS);
					time_flag = 0;
					continue;
				}
#endif
				if(info_flag == 2)
				{
					if (balance < 38)
						balance +=2;
					setbalance(balance);
				}
				else
				{
					volume -= VOL_STEP * (nKeyTime > 0x80) ? 4 : 1;
					if ((s08)volume < 0) 
						volume = 0;
#ifdef VOL_UP_RAMP
					volume_ramp = 0;
#endif
					setvolume(volume);
				}
				break;

			case EV_NEXT:
				if (isPlaying)
					next_song(1);
				break;

			case EV_PREV:
				if (isPlaying)
					next_song(2);
				break;

			case EV_NEXTPL:
				if (isPlaying)
				{
					next_playlist();
					play_song();
				}
				break;

			case EV_PREVPL:
				if (isPlaying)
				{
					prev_playlist();
					if (!bRandom)
						curIndex = 0;			
					play_song();
				}
				break;

			case EV_FFWD:
				if (isPlaying && !usb_play)
				{
					init_load_sectors(next_fat(MyCluster));		// skip to next cluster

					// calculate new size of played data
SEARCHGO:				fileplayed = BackStepPos * (YADL_CLUSTERSIZE / 32);

					// calculation of playing time - small hazard :-)
					addtime = (u16)(fileplayed*32 / (bitrate * 125)) - playtime;

					outptr = buffer1;				// play from buffer 1
					updbuf = buffer2;				// and next update buffer 2
					load_sectors(buffer1);
					vs1001_setvolume(volume+40,balance);		// volume down during search
					time_flag = 5;					// show information immedialy
					if(info_flag)
					{
						info_flag = 0;
						lcd_frame();
					}
					vol_decrease = 1;				// setting of volume downed flag
				}
				break;

			case EV_FREW:
				if (isPlaying && !usb_play && BackStepPos > 0)
				{
					init_load_sectors(Rev_Table[--BackStepPos]);
					goto SEARCHGO;
				}
				break;

			case EV_LDS:
				if (vs1001_fw)
				{
					bLoudness ^= 128;
					goto LDSS;
				}

			case EV_MBASS:
				if (vs1001_fw == 0x4020)
					bLoudness = (bLoudness+1) % 9;
				else if (vs1001_fw == 0x4200)
					bLoudness = (bLoudness+1) % 13;
LDSS:
				if (vs1001_fw)
				{
#ifdef GRAPH_LCD
					status_display();
#else
					lcd_clrline(LCD_LINES - 1);		// clear status line
					Vlcd_progputs(PSTR("Loudness: "));

					if (bLoudness < 128)
						Vlcd_putchar((bLoudness > 9) ? bLoudness + ('A'-10) : bLoudness + '0');
					else
						Vlcd_putchar('0');

					time_flag = 0;				// prevent display overvrite
					info_flag = 1;				// allow scroll
#endif
				}
				else
				{
					bLoudness = !bLoudness;
#ifndef GRAPH_LCD
					lcd_clrline(LCD_LINES - 1);		// clear status line
					Vlcd_progputs(PSTR("Loudness O"));
#endif
					disp_mod(bLoudness);			// show "FF" or "N "
				}
				LoudSet();
				eeprom_wb(EEPROM_LOUDNESS, bLoudness);		// store actual Mbass to eeprom
				break;

			case EV_RANDOM:
				bRandom = !bRandom;
#ifndef GRAPH_LCD
				lcd_clrline(LCD_LINES - 1);		// clear status line
				Vlcd_progputs(PSTR("Random O"));
#endif
				disp_mod(bRandom);			// show "FF" or "N "
				eeprom_wb(EEPROM_RANDOM,bRandom);
				break;

			case EV_REPEAT:
				Repeat = (Repeat + 1) % 4;
#ifdef GRAPH_LCD
				status_display();
#else
				Vlcd_clrscr();
				Vlcd_progputs(PSTR("Play Mode: "));
				Vlcd_putchar(Repeat + '1');
				Vlcd_putchar('\n');
				time_flag = 0;				// prevent display overvrite
				info_flag = 3;				// denny scrolling

				switch(Repeat)
				{
					case 0:	Vlcd_progputs(PSTR("Single Playlist"));
							break;
					case 1:	Vlcd_progputs(PSTR("All Playlists"));
							break;
					case 2:	Vlcd_progputs(PSTR("Repeat Playlist"));
							break;
					case 3:	Vlcd_progputs(PSTR("Repeat One Song"));
							break;
				}

#endif
				eeprom_wb(EEPROM_REPEAT,Repeat);
				break;

			case EV_TIME:
				timemode = !timemode;			// change mode of time displaying (normal<->remain)
#ifndef GRAPH_LCD
				if(menu_event)
				{
					lcd_clrline(LCD_LINES - 1);	// clear status line
					if(timemode)
						Vlcd_progputs(PSTR("Time: REMAIN"));
					else
						Vlcd_progputs(PSTR("Time: NORMAL"));
					info_flag = 1;
				}
#else
				time_flag = 5;
#endif
				eeprom_wb(EEPROM_TIME,timemode);
				break;

			case EV_MENU:
				info_flag = 3;				// disable displaying
				menu_event = browse_menu() + 1;
				info_flag = 0;				// enable displaying
				if (isPlaying)
					lcd_frame();			// show data on LCD
				if(menu_event)
					set_event(menu_event);
				else
				{
					menu_event = EV_IDLE;
					if (!isPlaying)
						set_event(EV_STOP);
				}
				break;

#ifdef ENABLE_INFO
static u16 Sampling[] = {0,44100,48000,32000,22050,24000,16000,11025,12000,8000};

			case EV_INFO:
				if(!info_flag)
				{
					pListEntry = get_pl_entry(curPlaylist);
					u08 fr = vs1001_read(VS1001_AUDATA) >> 9;
					u08 st_mo = fr>>6;
					fr &= 15;
					Vlcd_clrscr();
#ifdef GRAPH_LCD
					lcd_centerprint(0,PSTR("- I N F O -"),0);
					Vlcd_putchar('\n');
#endif
#if (LCD_LINES == 2)
					lprintf("PL:%u/%u %u:%02u:%02u\nSO:%u/%u %uk %u",
						curPlaylist+1, playlist_qty, pListEntry->length_hours, 
						pListEntry->length_minutes, pListEntry->length_seconds,
						curIndex+1, pListEntry->entry_qty, bitrate, Sampling[fr]);
						Vlcd_putchar((st_mo) ? 's':'m');
#else
					lprintf("Playlist:%u/%u\nTime:%u:%02u:%02u\nSong:%u/%u %ukbps \n%uHz ",
						curPlaylist+1, playlist_qty, pListEntry->length_hours, 
						pListEntry->length_minutes, pListEntry->length_seconds,
						curIndex+1, pListEntry->entry_qty, bitrate, Sampling[fr]);
						Vlcd_progputs((st_mo)? PSTR("Stereo"):PSTR("Mono"));
#endif
					time_flag = -100;			// prevent display overvrite
					info_flag = 3;				// denny scrolling
					Send_state(STATE_INFO);
				}
				else
					time_flag = 31;				// restore display
				break;
#endif //ENABLE_INFO

			case EV_REMOTE_CFG:
				if(!isPlaying)
					setup_rem();			// go to setup remote codes procedure
				break;
		}
		event = EV_IDLE;

  	} // while (1)    
  	
}

u08 getIndex(void)
{
	return(curIndex);
}
